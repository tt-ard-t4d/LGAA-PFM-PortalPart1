﻿namespace PFMPortal.Domain.Entities
{
    public class UserGroup : SysEntity
    {
        public short UserGroupID { get; set; }
        public string Name { get; set; }
        public virtual ICollection<UserGroupUserRel> UserGroupUsers { get; set; }
        public virtual ICollection<UserGroupActionRel> UserGroupActions { get; set; }
    }
}
