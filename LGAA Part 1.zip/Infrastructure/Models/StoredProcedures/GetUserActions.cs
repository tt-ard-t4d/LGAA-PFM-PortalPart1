﻿namespace PFMPortal.Infrastructure.Models.StoredProcedures
{
    public class GetUserActions
    {
        public int ActionID { get; set; }
        public string ActionName { get; set; }
        public string ActionEnumerationName { get; set; }
    }
}
