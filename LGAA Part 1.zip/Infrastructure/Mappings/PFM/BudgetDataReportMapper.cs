﻿using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.BudgetData;

namespace PFMPortal.Infrastructure.Mappings.PFM
{
    public class BudgetDataReportMapper
    {
        public BudgetDataReportDTO Map(BudgetData entity)
        {
            return new BudgetDataReportDTO()
            {
                MunicipalityName = entity.Municipality.MunicipalityName,
                AccountCategoryID = entity.BudgetPosition?.AccountCategoryID ?? 0,
                AccountCategoryName = entity.BudgetPosition?.AccountCategory?.AccountCategoryName ?? string.Empty,
                AccountTypeID = entity.BudgetPosition?.AccountCategory?.AccountTypeID ?? 0,
                BudgetPositionID = entity.BudgetPositionID,
                BudgetPositionName = entity.BudgetPosition?.BudgetPositionName ?? string.Empty,
                BudgetDataID = entity.BudgetDataID,
                Year = entity.Year,
                MunicipalityID = entity.MunicipalityID,
                PlannedValue = entity.PlannedValue,
                FinalValue = entity.FinalValue,
                Comment = entity.Comment
            };
        }
    }
}
