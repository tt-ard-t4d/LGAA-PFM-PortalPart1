﻿using PFMPortal.Domain.Contracts.Utils;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Mappings;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Mappings.Utils;
using Kendo.Mvc.Extensions;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.DTO.BudgetData;

namespace PFMPortal.Infrastructure.Core.Utils
{
    public class FileManagementService
    {
        private readonly IFileManagementRepository _fileRepository;
        private readonly IConfiguration _configuration;
        private readonly FileUploadService _fileUploadService;

        public FileManagementService(IFileManagementRepository fileRepository, IConfiguration configuration ,FileUploadService fileUploadService)
        {
            _fileRepository = fileRepository;
            _fileUploadService = fileUploadService;
            _configuration = configuration;
        }

        public GridDTO<FileGridDTO, SearchBudgetDataDTO> GetFileGrid(SearchBudgetDataDTO args, int pageNumber = Constants.DefaultPageNumber, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<FileGridDTO, SearchFileDTO>();
            (var retVal, var totalNumberOfRows) = _fileRepository.GetFileGrid(args);
            var pager = new PageDTO(totalNumberOfRows, args.Page, numberOfObjectsPerPage);

            var map = new FileManagementMapper();
            var paged = retVal.Page(numberOfObjectsPerPage, args.Page);
            var grid = paged.Select(c => map.MapGrid(c, totalNumberOfRows)).ToList();
            GetURLs(ref grid);

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        private void GetURLs(ref List<FileGridDTO> files)
        {
            string containerName = _configuration.GetValue<string>("FileContainerName") ?? string.Empty;
            files.ForEach(r => r.UrlAzure = _fileUploadService.GetBlob($"{r.FileGUID}_{r.FileName}{r.FileExtension}", containerName, $"{r.FileName}{r.FileExtension}"));
        }
    }
}
