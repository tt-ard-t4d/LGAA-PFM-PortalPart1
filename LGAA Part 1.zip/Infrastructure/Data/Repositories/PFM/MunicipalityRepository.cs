﻿using Infrastructure.Data;
using Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using PFMPortal.Domain.Contracts.PFM;
using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.Municipality;
using PFMPortal.Infrastructure.Models;

namespace PFMPortal.Infrastructure.Data.Repositories.PFM
{
    public class MunicipalityRepository : IMunicipalityRepository
    {
        private readonly DatabaseContext _dc;

        public MunicipalityRepository(DatabaseContext dc)
        {
            _dc = dc;
        }

        public (IQueryable<Municipality>, int) GetMunicipalitiesWithoutEntries(int year)
        {
            //sve JLS
            var allMunicipalities = GetAllMunicipalities();

            //JLS za koje postoje podaci
            var existingBudgetData = _dc.BudgetData.Include(r => r.Municipality).AsNoTracking().Where(r => r.Year == year && r.Retired == false);

            if (existingBudgetData.Count() > 0)
            {
                var existingMunicipalityIDs = existingBudgetData
                    .GroupBy(r => r.MunicipalityID)
                    .Select(r => r.First().Municipality.MunicipalityID);

                var res = allMunicipalities.Where(r => !existingMunicipalityIDs.Contains(r.MunicipalityID));

                return (res, res.Count());
            }

            return (allMunicipalities, allMunicipalities.Count());
        }

        public Municipality? GetMunicipalityById(int municipalityId)
        {
            return _dc.Municipalities
                .Include(r => r.LocalGovernmentUnit)
                .Include(r => r.Entity).AsNoTracking().FirstOrDefault(r => r.MunicipalityID == municipalityId && r.Retired == false);
        }

        public IQueryable<Municipality> GetAllMunicipalities()
        {
            return _dc.Municipalities.Include(r => r.LocalGovernmentUnit).Include(r => r.Entity).AsNoTracking().Where(r => r.Retired == false).OrderBy(r => r.MunicipalityName);
        }

        public (IQueryable<Municipality>, int) GetMunicipalityGrid(SearchMunicipalityDTO args)
        {
            var res = _dc.Municipalities
                .Include(r => r.LocalGovernmentUnit).Include(r => r.Entity).AsNoTracking().Where(r => r.Retired == false);

            if (!string.IsNullOrEmpty(args.MunicipalityName))
            {
                res = res.Where(r => r.MunicipalityName.ToLower().Contains(args.MunicipalityName.ToLower()));
            }

            if (args.EntityID > 0)
            {
                res = res.Where(r => r.EntityID == args.EntityID);
            }

            return (res.OrderBy(r => r.MunicipalityName), res.Count());
        }

        public List<int> GetYearsWithData(int municipalityId)
        {
            return _dc.BudgetData.AsNoTracking().Where(r => r.MunicipalityID == municipalityId)
                .GroupBy(r => r.Year)
                .Select(r => r.First().Year)
                .ToList();
        }

        public RetValue Save(Municipality entity)
        {
            _dc.Municipalities.Attach(entity);

            _dc.Entry(entity).Property(r => r.SysCreatedByUserID).IsModified = false;
            _dc.Entry(entity).Property(r => r.SysCreatedDate).IsModified = false;
            _dc.Entry(entity).Property(r => r.Retired).IsModified = true;

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Id = entity.MunicipalityID };
        }

        public Municipality? GetMunicipalityBySlug(string municipalityName)
        {
            return _dc.Municipalities
                .Include(r => r.LocalGovernmentUnit)
                .Include(r => r.Entity).AsNoTracking().FirstOrDefault(r => r.Slug == municipalityName);
        }

        public IQueryable<Municipality> GetMunicipalitiesForUser(Guid userId)
        {
            return _dc.Municipalities
                .Include(r => r.Entity)
                .Include(r => r.LocalGovernmentUnit)
                .Include(r => r.UserMunicipalities)
                .AsNoTracking().Where(r => r.Retired == false && r.UserMunicipalities.Any(r => r.UserID == userId))
                .OrderBy(r => r.MunicipalityName);
        }

        public IQueryable<Municipality> GetRetiredMunicipalities()
        {
            return _dc.Municipalities.AsNoTracking().Where(r => r.Retired == true).OrderBy(r => r.MunicipalityName); ;
        }

        public Municipality? GetRetiredMunicipality(int id)
        {
            return _dc.Municipalities.AsNoTracking()
                .Include(r => r.Entity)
                .Include(r => r.LocalGovernmentUnit)
                .FirstOrDefault(r => r.Retired == true && r.MunicipalityID == id);
        }

        public RetValue DeleteMunicipality(int id)
        {
            var entity = _dc.Municipalities.FirstOrDefault(r => r.Retired == false && r.MunicipalityID == id);

            if (entity == null) return new RetValue() { IsError = true, ErrorMessage = "JLS ne postoji u sistemu" };

            entity.Retired = true;

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Id = entity.MunicipalityID };

        }
    }
}
