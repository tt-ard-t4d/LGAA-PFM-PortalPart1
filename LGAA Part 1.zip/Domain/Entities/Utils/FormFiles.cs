﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PFMPortal.Domain.Entities.Utils
{
    public class FormFiles
    {
        public int FormFileID { get; set; }
        public int? FormID { get; set; }
        public Guid FileGuidID { get; set; }
        public string Name { get; set; }
        public string Extension { get; set; }
        public string Title { get; set; }
        public long? Size { get; set; }
        public short FileTypeID { get; set; }
        public Guid SysCreatedByUserID { get; set; }
        public bool Retired { get; set; }
    }
}
