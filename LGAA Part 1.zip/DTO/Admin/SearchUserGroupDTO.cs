﻿using PFMPortal.DTO.Utils;

namespace PFMPortal.DTO.Admin
{
    public class SearchUserGroupDTO : GridArgsDTO
    {
        public string? SearchTerm { get; set; }
    }
}
