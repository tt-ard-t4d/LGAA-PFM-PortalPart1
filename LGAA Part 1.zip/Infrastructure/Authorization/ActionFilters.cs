﻿

using Infrastructure.Helpers;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Globalization;
using Infrastructure.Helpers;
using Microsoft.AspNetCore.Mvc.Controllers;

namespace Authorization
{
    public class CustomActionFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var descriptor = filterContext.ActionDescriptor as ControllerActionDescriptor;
           
            if (descriptor.ControllerName != "Login")
            {
                if (LoginDataHelper.IsLogged)
                {
                    CultureInfo cultureInfo = new CultureInfo(LanguageDataHelper.ApplicationLanguage.LCID);
                    Thread.CurrentThread.CurrentCulture = cultureInfo;
                    Thread.CurrentThread.CurrentUICulture = cultureInfo;
                }
                else
                {
                    filterContext.HttpContext.SignOutAsync();
                    filterContext.HttpContext.Session.Clear();
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "action", "Login" }, { "controller", "Login" } });
                }

            }
            else
                base.OnActionExecuting(filterContext);
        }
    }
}