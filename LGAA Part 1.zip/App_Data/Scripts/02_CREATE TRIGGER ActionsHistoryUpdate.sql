USE [PFMPortalDB]
GO

/****** Object:  Trigger [dbo].[ActionsHistoryUpdate]    Script Date: 5/19/2023 11:00:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[ActionsHistoryUpdate] ON [dbo].[Actions]
  FOR update
  AS
  DECLARE @Now as DateTime = GetDate()
  SET NOCOUNT ON 

  IF 	UPDATE([ActionID])	
      OR  UPDATE([ActionName])
      OR UPDATE([ActionEnumerationName])
      OR UPDATE([Description])
      OR UPDATE([Retired])

BEGIN

  insert into ActionsHistory
    select *, 3, 'update-deleted', @Now
      from deleted
END




GO

ALTER TABLE [dbo].[Actions] ENABLE TRIGGER [ActionsHistoryUpdate]
GO

EXEC sp_settriggerorder @triggername=N'[dbo].[ActionsHistoryUpdate]', @order=N'Last', @stmttype=N'UPDATE'
GO


