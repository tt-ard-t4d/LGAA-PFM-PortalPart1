﻿namespace PFMPortal.DTO.BudgetData;

public class ChartBudgetTypeDonutDTO
{
    public int BudgetPositionID { get; set; }
    public string BudgetPositionName { get; set; } = string.Empty;
    public int AccountCategoryID { get; set; }
    public string Label { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public decimal? TotalAmount { get; set; } = 0;

}
