﻿var app = app || {};

app.grid = function () {

    var initialize = function (showClear) {
        // Making clickable row actually clickable
        $(".clickable-row").dblclick(function (e) {
            var targetClass = $(e.target).attr('class');
            var parentClass = $(e.target.parentElement).attr('class');
            if (targetClass !== 'btn btn-default btn-delete' && targetClass !== 'fa fa-pen' && targetClass !== 'fa fa-trash' && targetClass !== 'form-control inline-cell-edit'
                && parentClass !== 'clickable-row no-double' && parentClass !== 'input-group input-group-sm inline-cell-edit') {
                window.location = $(this).data("href");
            }
        });
    };

    return {
        initialize: initialize
    };
}();