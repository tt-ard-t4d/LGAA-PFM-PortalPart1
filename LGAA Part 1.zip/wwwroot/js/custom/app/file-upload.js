﻿var app = app || {};

app.fileUpload = function () {
    filelist = [];

    let addedFilesIds = '#SelectedFormFileID';
    let fileTableId = '#FileTable';
    let labelFileName = '#LabelFilename';

    $(function () {
        countNumberOfItems();
    });

    var upload = function (id, typeId) {

        var input = $('input[type=file][name=filedata]')[0];

        $.each(input.files, function (i, g) {

            app.utility.showLoader();
            data = {};
            data.NewFileName = input.files.item(i).name;
            data.Files = g;
            data.FileSize = input.files.item(i).size;

            addTempFilesToDB(data, id, typeId);
        });
    }

    var addTempFilesToDB = function (filedata, id, typeId) {
        var formData = new FormData();
        formData.append('id', id);
        formData.append('typeId', typeId);
        formData.append('file', filedata.Files);

        $.ajax({
            url: '/FileUpload/AddTempFileItems',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (data) {
                app.utility.hideLoader()
                if (data) {
                    // add array for insert and edit
                    const ff = [];
                    if ($(addedFilesIds).val().length > 0) {
                        $(addedFilesIds).val()
                            .split(",")
                            .forEach((item) => {
                                ff.push(item);
                            }
                        );
                    };
                    $.each(data, function (i, g) {

                        let html =
                        `<tr id=${g.formFileID}>
                            <td><a href="${g.urlAzure}" target="_self" /><i class="bi bi-download"></i></td>
                            <td>${g.fileName} (size ${g.fileLenght} KB)</td>
                            <td><i class="bi bi-trash" onclick="app.fileUpload.deleteFileFromList('${g.formFileID}', $(this).parent().parent())"></i></td>
                        </tr>`
                        $(fileTableId).append(html);
                        // ids for insert
                        ff.push(g.formFileID.toString())
                    });
                    $(addedFilesIds).val(ff);
                    countNumberOfItems();
                }
            },
            error: function () {
                toastr.error(app.resource.getByResourceGroupAndKey('MessageRes', 'Error'));
            }
        });
    };

    var countNumberOfItems = function () {
        var rowCount = $(`${fileTableId} tr`).length;
        $(labelFileName).text(`${rowCount} files`);
    }

    var deleteFileFromList = function (id, el) {
        app.resource.initSpecificResources(['ButtonRes', 'MessageRes'], function () {
            bootbox.confirm({
                closeButton: false,
                message: app.resource.getByResourceGroupAndKey('MessageRes', 'DeleteFile'),
                buttons: {
                    cancel: {
                        label: app.resource.getByResourceGroupAndKey('ButtonRes', 'Cancel'),
                        className: "btn-default pull-right"
                    },
                    confirm: {
                        label: app.resource.getByResourceGroupAndKey('ButtonRes', 'Yes'),
                        className: "btn-danger pull-left"
                    }
                },
                callback: function (result) {
                    if (result) {
                        if (id > 0) {
                            app.utility.showLoader()
                            $.ajax({
                                url: '/FileUpload/DeleteFormFile',
                                type: 'POST',
                                data: { id: id },
                                success: function (data) {
                                    app.utility.hideLoader()
                                    if (data.isError) {
                                        toastr.error(app.resource.getByResourceGroupAndKey('MessageRes', 'Error'));
                                    } else {
                                        $(el).remove();
                                        countNumberOfItems();
                                        toastr.success(app.resource.getByResourceGroupAndKey('MessageRes', 'DeleteSuccess'));
                                    }
                                }
                            });
                        }
                    }
                }
            });
        });
    }

    var downloadFile = function (guid) {
        app.utility.showLoader('body');
        window.location = baseurl + '/Form/DownloadFormFile?GUID=' + guid;
        app.utility.hideLoader('body');
    }

    return {
        upload: upload,
        deleteFileFromList: deleteFileFromList,
        downloadFile: downloadFile,
    }
}();