﻿namespace PFMPortal.Startup
{
    public static class LocalizationSettings
    {
        private static string[] _supportedCultures = new[]
        {
            "bs-Latn-BA"
        };

        private static RequestLocalizationOptions SetLocalizationOptions(this RequestLocalizationOptions options)
        {
            options.SetDefaultCulture(_supportedCultures[0])
                .AddSupportedCultures(_supportedCultures)
                .AddSupportedUICultures(_supportedCultures);

            return options;
        }
 

        public static WebApplication UseLocalization(this WebApplication app)
        {
            RequestLocalizationOptions localizationOptions = new RequestLocalizationOptions().SetLocalizationOptions();
            app.UseRequestLocalization(localizationOptions);

            return app;
        }

        public static IServiceCollection ConfigureLocalization(this IServiceCollection services)
        {
            services.Configure<RequestLocalizationOptions>(options =>
            {
                options.SetLocalizationOptions();
            });

            return services;
        }
    }
}
