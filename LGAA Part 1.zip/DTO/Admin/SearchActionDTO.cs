﻿using PFMPortal.DTO.Utils;

namespace PFMPortal.DTO.Admin
{
    public class SearchActionDTO : GridArgsDTO
    {
        public string? SearchTerm { get; set; }
        public string? ActionName { get; set; }
        public string? ActionEnumerationName { get; set; }
        public int ActionID { get; set; }
        public DateTime? DateModifiedFrom { get; set; }
        public DateTime? DateModifiedTo { get; set; }
    }
}
