﻿namespace PFMPortal.Infrastructure.Helpers
{
    public class PFMEnum
    {
        public enum AccountType
        {
            Income = 1,
            Expense = 2
        }

        public enum BudgetDataValueType
        {
            Planned = 1,
            Final = 2
        }

        public enum GraphType
        {
            PlannedBudgetPieChart = 1,
            ExecutedBudgetPieChart = 2,
            ActualBudgetBarChart = 3,
        }

        public enum BudgetDataIndexTab
        {
            Graphs,
            Table,
            Documents
        }

        public enum FileTypes
        {
            PFM_FileType = 1
        }
    }
}
