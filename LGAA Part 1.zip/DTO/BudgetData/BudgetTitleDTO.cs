﻿namespace PFMPortal.DTO.BudgetData
{
    public class BudgetTitleDTO
    {
        public Guid BudgetTitleGuid { get; set; }
        public int Year { get; set; }
        public int MunicipalityId { get; set; }
        public string Title { get; set; } = string.Empty;
    }
}
