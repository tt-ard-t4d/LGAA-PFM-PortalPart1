﻿

using Infrastructure.Helpers;
using Infrastructure.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;
using System.Security.Policy;

namespace Authorization
{
    // this attribute can be use in class and in methods
    // [AuthorizeRoles(GlobalEnum.UserTypes.Admin, GlobalEnum.UserTypes.Korisnici)]
    public class AuthorizeUserGroupsAttribute : Attribute, IAuthorizationFilter
    {
        private ActionManagementEnum.UserGroups[] _allowedUserGroups;
   
        public AuthorizeUserGroupsAttribute(params ActionManagementEnum.UserGroups[] allowedUserGroups)
        {
            _allowedUserGroups = allowedUserGroups;
        }

        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {
            if (!filterContext.HttpContext.Session.IsLoggedIn())
            {
                HandleUnauthorizedRequest(filterContext);
            }

            if (filterContext.HttpContext.Session.CheckIsInUserGroup(_allowedUserGroups)) return;
            
            HandleUnauthorizedRequest(filterContext);            
        }

        protected void HandleUnauthorizedRequest(AuthorizationFilterContext filterContext)
        {
            filterContext.HttpContext.SignOutAsync();
            filterContext.HttpContext.Session.Clear();

            var redirectUrl = filterContext.GetReturnUrl();

            filterContext.Result = new RedirectToActionResult("Login", "Login", new { returnUrl = redirectUrl });
        }
    }
}