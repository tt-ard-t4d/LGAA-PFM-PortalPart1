﻿using Microsoft.Build.Framework;

namespace PFMPortal.DTO.Admin
{
    public class ResetPasswordDTO
    {
        [Required]
        public string VerificationCode { get; set; } = string.Empty;
        [Required]
        public string Password { get; set; } = string.Empty;
        [Required]
        public string RepeatPassword { get; set; } = string.Empty;
    }
}
