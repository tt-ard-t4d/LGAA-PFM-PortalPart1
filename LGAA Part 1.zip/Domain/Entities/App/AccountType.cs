﻿using DocumentFormat.OpenXml.Office2010.PowerPoint;
using Microsoft.CodeAnalysis.CodeActions;

namespace PFMPortal.Domain.Entities.App
{
    public class AccountType
    {
        public byte AccountTypeID { get; set; }
        public string AccountTypeName { get; set; } = string.Empty;
        public virtual ICollection<AccountCategory> AccountCategories { get; set; }
        public bool Retired { get; set; }
    }
}
