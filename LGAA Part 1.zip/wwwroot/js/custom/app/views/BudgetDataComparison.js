﻿var app = app || {};

app.BudgetDataComparison = function () {
    var revenueChart = null;
    var expenditureChart = null;

    function getGraphData(callback, accountType) {
        var municipalityIDs = $("#MunicipalityIDs").val();
        var year = $("#Year").val();
        var graphType = $("#GraphType").val();

        var requestData = {
            MunicipalityIDs: municipalityIDs != null ? municipalityIDs.map(Number) : null,
            Year: parseInt(year),
            GraphType: graphType,
            AccountType: accountType
        };

        $.ajax({
            type: "GET",
            url: "/BudgetDataComparison/GetGraphData",
            contentType: "application/json",
            dataType: "json",
            data: requestData,
            traditional: true,
            success: function (data) {
                callback(data);
            },
            error: function (error) {
                console.error(error);
            }
        });

    }
    function drawGraphRevenues(data) {
        const title = "Budžetski prihodi";
        let options = app.graphSettings.getBarGraphOptions(title, "%");
        if (data.data.length != 0 && document.getElementById("revenues") && typeof ApexCharts !== 'undefined') {
            options.series = data.data;
            options.xaxis.categories = data.budgetLines;
            options.chart.height = data.budgetLines.length * data.data.length * 40;
            revenueChart = new ApexCharts(document.getElementById("revenues"), options);
            revenueChart.render();
        }
        data.emptyMunicipalities.forEach((id) => {
            if ($(`#municipality-${id}`).find('.error').length){
                return;
            }
            $(`#municipality-${id}`).removeClass('bg-white').addClass('bg-red-700 text-white').append($('<p class="error text-sm italic">Nema podataka za ovu JLS!</p>'));
            $(`#municipality-${id}`).find('.delete-icon').removeClass('hover:text-red-700');
        })
    }

    function drawGraphExpenditures(data) {
        const title = "Budžetski rashodi";
        let options = app.graphSettings.getBarGraphOptions(title, "%");
        if (data.data.length != 0 && document.getElementById("expenditures") && typeof ApexCharts !== 'undefined') {
            options.series = data.data;
            options.xaxis.categories = data.budgetLines;
            options.chart.height = data.budgetLines.length * data.data.length * 40;
            expenditureChart = new ApexCharts(document.getElementById("expenditures"), options);
            expenditureChart.render();
        }
        data.emptyMunicipalities.forEach((id) => {
            if ($(`#municipality-${id}`).find('.error').length) {
                return;
            }
            $(`#municipality-${id}`).removeClass('bg-white').addClass('bg-red-700 text-white').append($('<p class="error text-sm italic">Nema podataka za ovu JLS!</p>'));
            $(`#municipality-${id}`).find('.delete-icon').removeClass('hover:text-red-700');
        })
        if (data.emptyMunicipalities.length) {
            var alertDiv = $('<div class="p-4 mb-4 text-sm text-blue-800 rounded-lg bg-blue-50" id="alert-div">Odaberite JLS za poređenje koristeći meni s lijeve strane.</div>');
            $('#bar-charts').append(alertDiv);
        }
    }

    function drawComparisonRevenuesGraph(data) {
        data = filterMunicipalities(data);
        const title = "Budžetski prihodi";
        let options = app.graphSettings.getBarComparisonGraphOptions(data.filteredData, title);
        if (data.filteredData.length != 0 && document.getElementById("revenues") && typeof ApexCharts !== 'undefined') {
            revenueChart = new ApexCharts(document.getElementById("revenues"), options);
            revenueChart.render();
        }
        data.removedMunicipalitiesIDs.forEach((id) => {
            if ($(`#municipality-${id}`).find('.error').length) {
                return;
            }
            $(`#municipality-${id}`).removeClass('bg-white').addClass('bg-red-700 text-white').append($('<p class="error text-sm italic">Nema podataka za ovu JLS!</p>'));
            $(`#municipality-${id}`).find('.delete-icon').removeClass('hover:text-red-700');
        })
        if (!data.filteredData.length) {
            var alertDiv = $('<div class="p-4 mb-4 text-sm text-blue-800 rounded-lg bg-blue-50" id="alert-div">Odaberite JLS za poređenje koristeći meni s lijeve strane.</div>');
            $('#bar-charts').append(alertDiv);
        }
    }

    function drawComparisonExpendituresGraph(data) {
        data = filterMunicipalities(data);
        const title = "Budžetski rashodi";
        let options = app.graphSettings.getBarComparisonGraphOptions(data.filteredData, title);
        if (data.filteredData.length != 0 && document.getElementById("expenditures") && typeof ApexCharts !== 'undefined') {
            expenditureChart = new ApexCharts(document.getElementById("expenditures"), options);
            expenditureChart.render();
        }
        data.removedMunicipalitiesIDs.forEach((id) => {
            if ($(`#municipality-${id}`).find('.error').length) {
                return;
            }
            $(`#municipality-${id}`).removeClass('bg-white').addClass('bg-red-700 text-white').append($('<p class="error text-sm italic">Nema podataka za ovu JLS!</p>'));
            $(`#municipality-${id}`).find('.delete-icon').removeClass('hover:text-red-700');
        })
    }

    function filterMunicipalities(data) {
        const removedMunicipalitiesIDs = [];
        const filteredData = data.filter(municipality => {
            const hasZeroValues = municipality.data==null;
            if (hasZeroValues) {
                removedMunicipalitiesIDs.push(municipality.municipalityID); // Collect the ID
            }
            return !hasZeroValues;
        });
        return { filteredData, removedMunicipalitiesIDs };
    }

    function getComparisonData(requestData, callback){
        $.ajax({
            type: "GET",
            url: "/BudgetDataComparison/GetBudgetDataDifference",
            contentType: "application/json",
            dataType: "json",
            data: requestData,
            traditional: true,
            success: function (data) {
                callback(data);
            },
            error: function (error) {
                console.error(error);
            }
        });
    }

    function drawGraphsComparison() {
        var municipalityIDs = $("#MunicipalityIDs").val();
        var year = $("#Year").val();
        var requestData = {
            municipalityIds: municipalityIDs != null ? municipalityIDs.map(Number) : null,
            year: parseInt(year),
            accountTypeId: 1,
        };
        getComparisonData(requestData, drawComparisonRevenuesGraph);
        requestData.accountTypeId = 2;
        getComparisonData(requestData, drawComparisonExpendituresGraph);
    }

    function resetGraphs() {
        $('#empty-alert').remove();

        if (revenueChart)
            revenueChart.destroy();
        revenueChart = null;

        if (expenditureChart)
            expenditureChart.destroy();
        expenditureChart = null;
        $('#alert-div').remove();
        
    }
    function refreshGraphs() {
        app.utility.showLoader();
        resetGraphs();
        

        if ($('#MunicipalityIDs').val() == null) {
            var alertDiv = $('<div class="p-4 mb-4 text-sm text-blue-800 rounded-lg bg-blue-50" id="alert-div">Odaberite JLS za poređenje koristeći meni s lijeve strane.</div>');
            $('#bar-charts').append(alertDiv);
            app.utility.hideLoader();
            return;
        }

        if ($('#GraphType').val() == 3) {
            drawGraphsComparison();
            app.utility.hideLoader();
            return;
        }

        getGraphData(drawGraphRevenues, 1);
        getGraphData(drawGraphExpenditures, 2);

        $('#selectedMunicipalities').children().each(function () {
            $(this).removeClass('bg-red-700 text-white').addClass('bg-white');
            $(this).children('.error').remove();
        })
        
        app.utility.hideLoader();
    }

    function createNewMunicipalityBox(id, value) {
        const parent = $(`<div id="municipality-${id}" class="p-3 bg-white border border-gray-200 rounded-lg shadow-md text-gray-700 mb-2"></div>`)
        const wrapper = $(`<div class="flex justify-between "> </div>`);
        $(wrapper).append($(`<p class="font-normal">${value}</p>`));
        const deleteIcon = $(`<div data-id="${id}" id="remove-municipality-${id}" class="delete-icon hover:text-red-700 cursor-pointer"></div>`);
        $(deleteIcon).append($(`<i class="bi bi-trash"></i>`));
        $(wrapper).append($(deleteIcon));
        $(parent).append($(wrapper));

        return parent;
    }

    function addRemoveClickListener(id, value) {
        $(`#remove-municipality-${id}`).on('click', function () {
            processMunicipalityRemove(id, value)
        });
    }

    function processMunicipalityAdd() {
        const id = $("#Municipalities option:selected").val();
        const value = $("#Municipalities option:selected").text();
        $('#selectedMunicipalities').append(createNewMunicipalityBox(id, value));
        addRemoveClickListener(id, value);

        $("#Municipalities option:selected").remove();
        $('#Municipalities').val('')

        var vrijednosti = $('#MunicipalityIDs').val();
        if (vrijednosti == null)
            vrijednosti = [];
        vrijednosti.push(id);
        $('#MunicipalityIDs').val(vrijednosti);

        refreshGraphs();
    }

    function processMunicipalityRemove(id, value) {
        $(`#municipality-${id}`).remove();
        const listItem = `<option value="${id}">${value}</option>`;
        $("#Municipalities").append(listItem);

        var vrijednosti = $('#MunicipalityIDs').val();
        vrijednosti.splice(vrijednosti.indexOf(id), 1);
        if (vrijednosti == null)
            vrijednosti = '';
        $('#MunicipalityIDs').val(vrijednosti);

        refreshGraphs();
    }

    function processYearChange(newYear) {
        const currentYear = $('#Year').val();
        $(`#year-${currentYear}`).removeClass('text-blue-600 bg-gray-100 rounded-t-lg active').data('');
        $('#Year').val(newYear);
        $(`#year-${newYear}`).removeClass('hover:text-gray-600 hover:bg-gray-50').data('');
        $(`#year-${newYear}`).addClass('text-blue-600 bg-gray-100 rounded-t-lg active').data('');

        refreshGraphs();
    }

    function processGraphChange(name, value) {
        $(".text-white.bg-blue-us.active").removeClass("text-white bg-blue-us active").addClass("hover:text-gray-900 hover:bg-gray-100");
        $(`#graph-nav-${name}`).removeClass("hover:text-gray-900 hover:bg-gray-100").addClass("text-white bg-blue-us active");
        $('#GraphType').val(value);

        refreshGraphs();
    }

    return {
        processMunicipalityAdd: processMunicipalityAdd,
        processMunicipalityRemove: processMunicipalityRemove,
        processYearChange: processYearChange,
        processGraphChange: processGraphChange,
    };
}();