﻿using Microsoft.AspNetCore.Mvc;
using PFMPortal.DTO.Utils;
using System.ComponentModel.DataAnnotations;
using static PFMPortal.Infrastructure.Helpers.PFMEnum;

namespace PFMPortal.DTO.BudgetData
{
    public class SearchBudgetDataDTO : SearchFileDTO
    {
        public List<ItemDDL> Municipalities { get; set; } = new List<ItemDDL>();

        [Required]
        public int MunicipalityID { get; set; }
        public List<ItemDDL> Years { get; set; } = new List<ItemDDL>();

        [Required]
        public int Year { get; set; }
        public List<ItemDDL> ValueTypes { get; set; } = new List<ItemDDL>();
        public byte ValueTypeID { get; set; }
        public List<ItemDDL> AccountTypes { get; set; } = new List<ItemDDL>();
        public byte AccountTypeID { get; set; }
        public string MunicipalityName { get; set; }
        public BudgetDataIndexTab Tab { get; set; } = 0;
    }
}
