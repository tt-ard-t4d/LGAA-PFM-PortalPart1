﻿using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using PFMPortal.Domain.Contracts.Utils;
using PFMPortal.Domain.Entities.Utils;
using PFMPortal.DTO.BudgetData;
using PFMPortal.DTO.Utils;

namespace PFMPortal.Infrastructure.Data.Repositories.Utils
{
    public class FileManagementRepository : IFileManagementRepository
    {
        private readonly DatabaseContext _dc;

        public FileManagementRepository(DatabaseContext dc)
        {
            _dc = dc;
        }
        public (IQueryable<FormFiles>, int) GetFileGrid(SearchBudgetDataDTO args)
        {
            var res = _dc.FormFiles.AsNoTracking().Where(r => r.Retired == false && r.FormID == args.MunicipalityID);

            if (!string.IsNullOrEmpty(args.SearchTerm))
            {
                res = res.Where(r => r.Title.ToLower().Contains(args.SearchTerm.ToLower())
                || r.Name.ToLower().Contains(args.SearchTerm.ToLower()));
            }

            if (args.FileTypeID > 0)
            {
                res = res.Where(r => r.FileTypeID == args.FileTypeID);
            }

            res = res.OrderByDescending(r => r.FormFileID);

            return (res, res.Count());
        }
    }
}
