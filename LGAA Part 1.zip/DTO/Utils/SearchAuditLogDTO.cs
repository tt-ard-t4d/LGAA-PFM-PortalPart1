﻿namespace PFMPortal.DTO.Utils
{
    public class SearchAuditLogDTO : GridArgsDTO
    {
        public string SearchTerm { get; set; }
        public List<ItemDDL> AuditLogEnumerations { get; set; }
        public int? AuditLogEnumerationID { get; set; }
    }
}
