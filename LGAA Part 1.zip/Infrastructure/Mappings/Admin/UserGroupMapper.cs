﻿using Infrastructure.Helpers;
using PFMPortal.Domain.Entities;
using PFMPortal.DTO.Admin;

namespace PFMPortal.Infrastructure.Mappings.Admin
{
    public class UserGroupMapper
    {
        public UserGroupDTO Map(UserGroup? entity)
        {
            if (entity == null)
            {
                return new UserGroupDTO();
            }

            return new UserGroupDTO()
            {
                UserGroupID = entity.UserGroupID,
                Name = entity.Name
            };
        }

        public UserGroup Map(UserGroupDTO model, GlobalEnum.CrudOperation operation, Guid loggedUserId)
        {
            var entity = new UserGroup()
            {
                UserGroupID = model.UserGroupID,
                Name =model.Name,
                Retired = false
            };

            if (operation == GlobalEnum.CrudOperation.Add)
            {
                entity.SysCreatedByUserID = loggedUserId;
                entity.SysCreatedDate = DateTime.Now;
            }
            else if (operation == GlobalEnum.CrudOperation.Edit)
            {
                entity.SysLastModifiedByUserID = loggedUserId;
                entity.SysLastModifiedDate = DateTime.Now;
            }

            return entity;
        }

        public UserGroupGridDTO Map(UserGroup entity, int totalNumberOfRows)
        {
            if (entity == null)
            {
                return new UserGroupGridDTO();
            }

            var model = new UserGroupGridDTO()
            {
                UserGroupID = entity.UserGroupID,
                Name = entity.Name,
                Total = totalNumberOfRows
            };

            return model;
        }
    }
}
