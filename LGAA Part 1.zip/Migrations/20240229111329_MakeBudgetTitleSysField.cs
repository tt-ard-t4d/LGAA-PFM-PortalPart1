﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PFMPortal.Migrations
{
    /// <inheritdoc />
    public partial class MakeBudgetTitleSysField : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "Retired",
                schema: "pfm",
                table: "BudgetTitles",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<Guid>(
                name: "SysCreatedByUserID",
                schema: "pfm",
                table: "BudgetTitles",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<DateTime>(
                name: "SysCreatedDate",
                schema: "pfm",
                table: "BudgetTitles",
                type: "datetime",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<Guid>(
                name: "SysLastModifiedByUserID",
                schema: "pfm",
                table: "BudgetTitles",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "SysLastModifiedDate",
                schema: "pfm",
                table: "BudgetTitles",
                type: "datetime",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Retired",
                schema: "pfm",
                table: "BudgetTitles");

            migrationBuilder.DropColumn(
                name: "SysCreatedByUserID",
                schema: "pfm",
                table: "BudgetTitles");

            migrationBuilder.DropColumn(
                name: "SysCreatedDate",
                schema: "pfm",
                table: "BudgetTitles");

            migrationBuilder.DropColumn(
                name: "SysLastModifiedByUserID",
                schema: "pfm",
                table: "BudgetTitles");

            migrationBuilder.DropColumn(
                name: "SysLastModifiedDate",
                schema: "pfm",
                table: "BudgetTitles");
        }
    }
}
