﻿namespace PFMPortal.Domain.Entities
{
    public class UserActionRel
    {
        public int UserAndActionID { get; set; }
        public Guid UserID { get; set; }
        public User User { get; set; }
        public int ActionID { get; set; }
        public Action Action { get; set; }
        public bool Retired { get; set; }
    }
}
