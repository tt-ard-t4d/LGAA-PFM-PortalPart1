﻿namespace PFMPortal.DTO.BudgetData
{
    public class AccountCategoryDataGridDTO
    {
        public int AccountCategoryDataID { get; set; }
        public int AccountCategoryID { get; set; }
        public string AccountCategoryName { get; set; }
        public int MunicipalityID { get; set; }
        public string MunicipalityName { get; set; }
        public int Year { get; set; }
        public decimal? TotalPlannedValue { get; set; }
        public decimal? TotalFinalValue { get; set; }
    }
}
