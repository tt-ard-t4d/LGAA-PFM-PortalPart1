﻿using PFMPortal.Domain.Contracts.Utils;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Utility;

namespace PFMPortal.Infrastructure.Core.Utils
{
    public class DropDownService
    {
        private readonly IDropDownRepository _dropDownRepository;
        private readonly IConfiguration _configuration;

        public DropDownService(IDropDownRepository dropDownRepository, IConfiguration configuration)
        {
            _dropDownRepository = dropDownRepository;
            _configuration = configuration;
        }

        public List<ItemDDL> GetUserGroups()
        {
            return _dropDownRepository.GetUserGroups().Select(r => new ItemDDL() { Id = r.UserGroupID, Value = r.Name }).ToList();
        }

        public List<ItemDDL> GetActions()
        {
            return _dropDownRepository.GetActions().Select(r => new ItemDDL() { Id = r.ActionID, Value = $"{r.ActionName} ({r.ActionEnumerationName})" }).ToList();
        }

        public List<ItemDDL> GetUsers()
        {
            return _dropDownRepository.GetUsers()
                .Select(r => new ItemDDL() { Guid = r.UserID, Value = 
                $"{SEDManager.Unprotect(r.UserNameEnc, _configuration)} (" +
                $"{SEDManager.Unprotect(r.FirstNameEnc, _configuration)} " +
                $"{SEDManager.Unprotect(r.LastNameEnc, _configuration)})"})
                .ToList();
        }

        public List<ItemDDL> GetUserEmails()
        {
            return _dropDownRepository.GetUsers().Select(r => new ItemDDL() { Guid = r.UserID, Value = SEDManager.Unprotect(r.EmailEnc, _configuration) }).ToList();
        }

        public List<ItemDDL> GetAuditType()
        {
            return _dropDownRepository.GetAllAuditLogsEnumeration().Select(r => new ItemDDL { Id = r.AuditLogEnumerationID, Value = r.AuditLogEnumerationDescription }).ToList();
        }
    }
}
