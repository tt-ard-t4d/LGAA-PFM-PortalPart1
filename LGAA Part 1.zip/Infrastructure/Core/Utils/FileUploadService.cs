﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using PFMPortal.Domain.Contracts.Utils;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Mappings.Utils;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Infrastructure.Resources;

namespace PFMPortal.Infrastructure.Core.Utils
{
    public class FileUploadService
    {
        private IFileRepository _fileRepository;
        private IConfiguration _configuration;
        private BlobServiceClient _blobClient;

        public FileUploadService(IFileRepository fileRepository, BlobServiceClient blobClient, IConfiguration configuration)
        {
            _fileRepository = fileRepository;
            _blobClient = blobClient;
            _configuration = configuration;
        }

        public (List<FormFileDTO> Data, RetValue Ret) SaveFilesToDBAndAzure(short typeId, Guid loggedUserId, IFormFileCollection files, int formId)
        {
            var map = new FileUploadMapper();
            List<FormFileDTO> items = new();
            string containerName = _configuration.GetValue<String>("FileContainerName") ?? string.Empty;

            // multiple files we can select
            foreach (var item in files)
            {
                // check if file already exist
                //if (IsFileExist(caseId, typeId, name, item.Length)) { continue; }

                var uid = Guid.NewGuid();
                var fileName = uid + "_" + item.FileName;
                // upload file to blob
                var resUpload = UploadBlob(fileName, item, containerName);
                if (resUpload is true)
                {
                    // add file to DB
                    var entity = map.Map(item, uid, typeId, formId, loggedUserId);
                    var save = _fileRepository.Save(entity);
                    if (save.IsError) { return (new List<FormFileDTO>(), new RetValue() { IsError = true, ErrorMessage = FileUploadRes.DBError }); }
                    entity.FormFileID = save.Id;
                    items.Add(map.Map(entity));
                }
                else
                {
                    return (new List<FormFileDTO>(), new RetValue() { IsError = true, ErrorMessage = FileUploadRes.ServerNotFound });
                }
            }
            // add link to azure
            items.ForEach(r => r.UrlAzure = GetBlob($"{r.FileGUID}_{r.FileName}{r.FileExtension}", containerName, $"{r.FileName}{r.FileExtension}"));

            return (items, new RetValue());
        }

        public RetValue UpdateFilesInDB(int caseId, int loggedUserId, string selectedFormFileIds)
        {
            var ids = selectedFormFileIds.Split('\u002C').Select(r => int.Parse(r));
            var ret = new RetValue();
            if (ids.Count() > 0)
            {
                return _fileRepository.UpdateFilesFromDB(ids, caseId);
            }
            return ret;
        }

        public List<FormFileDTO> GetUploadedFiles(int id, short typeId)
        {
            var map = new FileUploadMapper();
            var files = _fileRepository.GetFilesFromDB(id, typeId).Select(r => map.Map(r)).ToList();

            if (files.Count() > 0)
            {
                var count = files.Count();
            }
            return GetURLs(files);
        }

        public List<FormFileDTO> GetURLs(List<FormFileDTO> files)
        {
            string containerName = _configuration.GetValue<string>("FileContainerName") ?? string.Empty;
            files.ForEach(r => r.UrlAzure = GetBlob($"{r.FileGUID}_{r.FileName}{r.FileExtension}", containerName, $"{r.FileName}{r.FileExtension}"));
            return files;
        }

        public List<FormFileDTO> GetURLsWithoutExtension(List<FormFileDTO> files)
        {
            string containterName = _configuration.GetValue<string>("FileContainerName") ?? string.Empty;
            files.ForEach(r => r.UrlAzure = GetBlob($"{r.FileGUID}_{r.FileName}", containterName, $"{r.FileName}{r.FileExtension}"));
            return files;
        }

        public RetValue DeleteFile(int id)
        {
            return _fileRepository.DeleteFile(id);
        }

        /// <summary>
        /// Return all files in blob
        /// </summary>
        /// <param name="containerName"></param>
        /// <returns></returns>
        public async Task<IEnumerable<string>> AllBlobs(string containerName)
        {
            // allow us to access the data inside the container
            var containerClient = _blobClient.GetBlobContainerClient(containerName);

            var files = new List<string>();

            var blobs = containerClient.GetBlobsAsync();

            await foreach (var item in blobs)
            {
                files.Add(item.Name);
            }

            return files;
        }

        /// <summary>
        /// Get one BLOB
        /// </summary>
        /// <param name="name"></param>
        /// <param name="containerName"></param>
        /// <returns></returns>
        public string GetBlob(string name, string containerName, string friendlyName)
        {
            // this will allow us access to the storage container
            var containerClient = _blobClient.GetBlobContainerClient(containerName);

            // this will allow us access to the file inside the container via the file name
            var blobClient = containerClient.GetBlobClient(name);

            var httpHeaders = new BlobHttpHeaders()
            {
                ContentDisposition = $"attachment; filename={friendlyName}"
            };

            return blobClient.Uri.AbsoluteUri;
        }

        public async Task<bool> DeleteBlob(string name, string containerName)
        {
            var containerClient = _blobClient.GetBlobContainerClient(containerName);
            var blobClient = containerClient.GetBlobClient(name);
            return await blobClient.DeleteIfExistsAsync();
        }

        private bool UploadBlob(string fileName, IFormFile file, string containerName)
        {
            var containerClient = _blobClient.GetBlobContainerClient(containerName);
            var blobClient = containerClient.GetBlobClient(fileName);
            var httpHeaders = new BlobHttpHeaders()
            {
                ContentType = file.ContentType,
            };
            try
            {
                var res = blobClient.Upload(file.OpenReadStream(), httpHeaders);

                if (res != null)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }

            return false;
        }

        private bool IsFileExist(int fileId, short typeId, string fileName, long length)
        {
            var res = _fileRepository.GetFileFromDB(fileId, typeId, fileName);
            var strict = res.Where(r => r.Size == length).FirstOrDefault();
            if (strict is not null) { return true; }

            return false;
        }
    }
}
