﻿using Infrastructure.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;

namespace PFMPortal.Infrastructure.Authorization
{
    public class AuthorizeActionsAttribute : Attribute, IAuthorizationFilter
    {
        private ActionManagementEnum.ActionEnumeration[] _allowedActions;

        public AuthorizeActionsAttribute(params ActionManagementEnum.ActionEnumeration[] allowedActions)
        {
            _allowedActions = allowedActions;
        }

        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {
            if (!filterContext.HttpContext.Session.IsLoggedIn())
            {
                HandleUnauthorizedRequest(filterContext);
            }

            if(filterContext.HttpContext.Session.CheckIsInAction(_allowedActions)) return;

            HandleUnauthorizedRequest(filterContext);
        }

        protected void HandleUnauthorizedRequest(AuthorizationFilterContext filterContext)
        {
            filterContext.HttpContext.SignOutAsync();
            filterContext.HttpContext.Session.Clear();

            var redirectUrl = filterContext.GetReturnUrl();

            filterContext.Result = new RedirectToActionResult("Login", "Login", new { returnUrl = redirectUrl });
        }
    }
}
