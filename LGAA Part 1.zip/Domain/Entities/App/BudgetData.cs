﻿namespace PFMPortal.Domain.Entities.App
{
    public class BudgetData : SysEntity
    {
        public int BudgetDataID { get; set; }
        public int Year { get; set; }
        public int MunicipalityID { get; set; }
        public virtual Municipality Municipality { get; set; }
        public int BudgetPositionID { get; set; }
        public virtual BudgetPosition BudgetPosition { get; set; }
        public decimal? PlannedValue { get; set; }
        public decimal? FinalValue { get; set; }
        public string? Comment { get; set; }
    }
}
