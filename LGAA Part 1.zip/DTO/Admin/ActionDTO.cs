﻿namespace PFMPortal.DTO.Admin
{
    public class ActionDTO
    {
        public int ActionID { get; set; }
        public string ActionName { get; set; }
        public string ActionEnumerationName { get; set; }
        public string? Description { get; set; }
        public bool Retired { get; set; }
    }
}
