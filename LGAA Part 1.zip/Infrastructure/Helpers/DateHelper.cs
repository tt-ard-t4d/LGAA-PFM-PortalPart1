﻿using System.Globalization;

namespace PFMPortal.Infrastructure.Helpers
{
    public static class DateHelper
    {
        public static string GetDateFormat()
        {
            return CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
        }
    }
}
