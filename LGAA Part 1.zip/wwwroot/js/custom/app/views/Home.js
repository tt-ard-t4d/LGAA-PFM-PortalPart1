﻿var app = app || {};

app.home = function () {
    var color = "";
    var changeMapSvgBackground = function (el, color) {
        $(el).css('fill', color);
    }
    var addMapClickListeners = function (el){
        $(el).css('fill', '#002F6C').on('click', function () {
            const svgId = $(this).attr('id');
            console.log($(`#link-${svgId}`))
            $(`#link-${svgId}`)[0].click();
        })
    }

    var addMapHoverListeners = function (el) {
        $(el).hover(
            function () {
                color = $(this).css('fill');
                $(this).css('fill', '#BA0C2F');
                $(this).css('cursor', 'pointer');
                const svgId = $(this).attr('id');
                $(`#link-${svgId}`).addClass('hover-tile')
            },
            function () {
                $(this).css('fill', color);
                const svgId = $(this).attr('id');
                $(`#link-${svgId}`).removeClass('hover-tile')
            }
        )
    }
    var addLinkHoverListeners = function (link, el) {
        $(link).hover(function () {
            changeMapSvgBackground(el, "#BA0C2F")
        }, function () {
            changeMapSvgBackground(el, "#002F6C")
        })
    }

    var initialize = function () {
        $(function () {
            //Init map and links
            $('#municipality-links > div > a').each(
                function () {
                    const el = $(`#${$(this).attr('id').replace(/^link-/, '')}`);

                    changeMapSvgBackground(el, '#002F6C');
                    addMapClickListeners(el);
                    addMapHoverListeners(el);
                    addLinkHoverListeners($(this), el);
                }
            );
            //Init search
            $("#default-search").on("keyup", filterMunicipalities);
        });
    }

    function filterMunicipalities() {
        var query = $("#default-search").val().toLowerCase();
        $("#municipality-links div").each(function () {
            var municipalityName = $(this).find(".font-normal").text().toLowerCase();
            var div = $(this);
            if (municipalityName.includes(query)) {
                div.show();
            } else {
                div.hide();
            }
        });
    }

    return {
        initialize: initialize
    };
}();