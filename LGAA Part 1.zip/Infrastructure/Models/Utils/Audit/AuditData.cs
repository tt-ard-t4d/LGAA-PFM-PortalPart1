﻿namespace Infrastructure.Models.Utils.Audit
{
    public class AuditData
    {
        public Dictionary<string, string> ItemData = new Dictionary<string, string>();
    }
}
