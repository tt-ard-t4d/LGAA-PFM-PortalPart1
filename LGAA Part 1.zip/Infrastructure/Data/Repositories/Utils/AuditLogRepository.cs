﻿
using DocumentFormat.OpenXml.Presentation;
using Domain.Contracts;
using Domain.Entities.Utils;
using DTO.Utils;
using Infrastructure.Mappings.Utils;
using Microsoft.EntityFrameworkCore;
using PFMPortal.Domain.Entities;
using PFMPortal.DTO.Admin;
using PFMPortal.DTO.Utils;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Data.Repositories
{
    public class AuditLogRepository : IAuditLogRepository
    {
        private DatabaseContext dc;
        public AuditLogRepository(DatabaseContext ctx)
        {
            dc = ctx;

        }

        /// <summary>
        /// Get item from AuditLog
        /// </summary>
        /// <returns>Mapped List AuditLog items</returns>
        public List<AuditLogDTO> GetAllAuditLog()
        {
            List<AuditLogDTO> auditLogNew = new List<AuditLogDTO>();
            var auditLogMapper = new AuditLogMapper();

            List<AuditLog> auditLog = dc.AuditLogs.AsNoTracking().ToList();

            if (auditLog != null)
            {
                foreach (var item in auditLog)
                {
                    auditLogNew.Add(auditLogMapper.MapAuditLog(item));
                }
            }

            return auditLogNew;

        }

        /// <summary>
        /// Get item AuditLog by id 
        /// </summary>
        /// <param name="id">ID AuditLog</param>
        /// <returns>Mapped AuditLog item</returns>
        public AuditLogDTO GetAuditLogItem(int? id)
        {
            var auditLogMapper = new AuditLogMapper();
            AuditLog auditLog = dc.AuditLogs.AsNoTracking().FirstOrDefault(s => s.AuditLogID == id);

            if (auditLog != null)
                return auditLogMapper.MapAuditLog(auditLog);
            else
                return auditLogMapper.MapAuditLog();
        }

        public void SaveAuditLog(AuditLogDTO auditLog)
        {
            var auditLogMapper = new AuditLogMapper();
            AuditLog _auditLog = auditLogMapper.MapAuditLog(auditLog);

            if (_auditLog.AuditLogID > 0)
            {
                _auditLog.SysLastModifiedDate = DateTime.Now;
                //_auditLog.SysLastModifiedByUserID = loggedUserId;
                _auditLog.SysLastModifiedByUserID = 1;
                dc.AuditLogs.Attach(_auditLog);
                dc.Entry(_auditLog).State = EntityState.Modified;
            }
            else
            {
                dc.AuditLogs.Add(_auditLog);
            }

            dc.SaveChanges();
        }

        public (IQueryable<AuditLog>, int) GetAuditLogGrid(SearchAuditLogDTO args)
        {
            var res = dc.AuditLogs
                .AsNoTracking();

            if(!String.IsNullOrEmpty(args.SearchTerm))
            {
                res = res.Where(r => r.AuditLogText.Contains(args.SearchTerm));
            }

            if (args.AuditLogEnumerationID.HasValue)
            {
                res = res.Where(r => r.AuditLogEnumerationID == args.AuditLogEnumerationID);
            }

            return (res, res.Count());
        }

    }
}
