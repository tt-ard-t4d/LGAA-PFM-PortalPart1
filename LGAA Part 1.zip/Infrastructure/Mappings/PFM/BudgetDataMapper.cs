﻿using DocumentFormat.OpenXml.Bibliography;
using Infrastructure.Helpers;
using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.BudgetData;
using PFMPortal.Infrastructure.Helpers;

namespace PFMPortal.Infrastructure.Mappings.PFM
{
    public class BudgetDataMapper
    {
        private string AddReadModeSpan(int? accountCategoryId, string? accountCategoryName, string? information)
        {
            if (accountCategoryId == null || string.IsNullOrEmpty(accountCategoryName) || string.IsNullOrEmpty(information)) return string.Empty;

            var accountCategoryString = accountCategoryId.ToString();

            if (accountCategoryId < 10)
            {
                accountCategoryString = "0" + accountCategoryString;
            }

            return $"<i class='bi bi-question-circle mr-2' data-tooltip-target='tooltip-account-category-{accountCategoryString}'></i>" +
                $"<span class='hidden'>{accountCategoryString}</span>{accountCategoryName}" +
                $"<div id='tooltip-account-category-{accountCategoryString}' role='tooltip' class='absolute z-10 invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip'>" +
                $"{information}" +
                $"<div class='tooltip-arrow' data-popper-arrow></div>" +
                $"</div>";

            //return $"<span class='hidden'>{accountCategoryId}</span>{accountCategoryName}";
        }

        private string AddEditModeSpan(int? accountCategoryId, string? accountCategoryName)
        {
            if (accountCategoryId == null || string.IsNullOrEmpty(accountCategoryName)) return string.Empty;

            var accountCategoryString = accountCategoryId.ToString();

            if (accountCategoryId < 10)
            {
                accountCategoryString = "0" + accountCategoryString;
            }

            return $"<span class='hidden'>{accountCategoryString}</span>{accountCategoryName}";
        }

        public BudgetDataGridDTO MapGrid(BudgetData entity, bool isEdit)
        {
            var model = new BudgetDataGridDTO()
            {
                MunicipalityName = entity.Municipality.MunicipalityName,
                LGUStatus = LGUHelper.GetLGUType(entity.Municipality.EntityID, entity.Municipality.LocalGovernmentUnitID),
                AccountCategoryID = entity.BudgetPosition?.AccountCategoryID ?? 0,
                AccountCategoryName = entity.BudgetPosition?.AccountCategory?.AccountCategoryName ?? string.Empty,
                AccountTypeID = entity.BudgetPosition?.AccountCategory?.AccountTypeID ?? 0,
                BudgetPositionID = entity.BudgetPositionID,
                BudgetPositionName = entity.BudgetPosition?.BudgetPositionName ?? string.Empty,
                BudgetDataID = entity.BudgetDataID,
                Year = entity.Year,
                MunicipalityID = entity.MunicipalityID,
                PlannedValue = entity.PlannedValue,
                FinalValue = entity.FinalValue,
                Comment = entity.Comment,
                Information = entity.BudgetPosition?.AccountCategory?.Information ?? string.Empty,
            };

            if (isEdit)
            {
                model.AccountCategoryHelperName = AddEditModeSpan(entity.BudgetPosition?.AccountCategoryID, entity.BudgetPosition?.AccountCategory?.AccountCategoryName);
            }
            else
            {
                model.AccountCategoryHelperName =
                    AddReadModeSpan(entity.BudgetPosition?.AccountCategoryID, entity.BudgetPosition?.AccountCategory?.AccountCategoryName, entity.BudgetPosition?.AccountCategory?.Information);
            }

            return model;
        }

        public BudgetData MapGrid(BudgetDataGridDTO model, GlobalEnum.CrudOperation operation, Guid loggedUserId)
        {
            var entity = new BudgetData()
            {
                BudgetDataID = model.BudgetDataID,
                Year = model.Year,
                MunicipalityID = model.MunicipalityID,
                BudgetPositionID = model.BudgetPositionID,
                PlannedValue = model.PlannedValue,
                FinalValue = model.FinalValue,
                Retired = false,
                Comment = model.Comment,
            };

            if (operation == GlobalEnum.CrudOperation.Add)
            {
                entity.PlannedValue = 0;
                entity.FinalValue = 0;
                entity.SysCreatedByUserID = loggedUserId;
                entity.SysCreatedDate = DateTime.Now;
            }
            else if (operation == GlobalEnum.CrudOperation.Edit)
            {
                entity.SysLastModifiedByUserID = loggedUserId;
                entity.SysLastModifiedDate = DateTime.Now;
            }

            return entity;
        }

        public BudgetDataDTO Map(BudgetData? entity)
        {
            if (entity == null)
            {
                return new BudgetDataDTO();
            }

            return new BudgetDataDTO()
            {
                BudgetDataID = entity.BudgetDataID,
                Year = entity.Year,
                MunicipalityID = entity.MunicipalityID,
                BudgetPositionID = entity.BudgetPositionID,
                PlannedValue = entity.PlannedValue,
                FinalValue = entity.FinalValue,
                Comment = entity.Comment,
            };
        }

        public BudgetData Map(BudgetDataDTO model, GlobalEnum.CrudOperation operation, Guid loggedUserId)
        {
            var entity = new BudgetData()
            {
                BudgetDataID = model.BudgetDataID,
                Year = model.Year,
                MunicipalityID = model.MunicipalityID,
                BudgetPositionID = model.BudgetPositionID,
                PlannedValue = model.PlannedValue,
                FinalValue = model.FinalValue,
                Comment = model.Comment,
                Retired = false
            };

            if (operation == GlobalEnum.CrudOperation.Add)
            {
                entity.PlannedValue = 0;
                entity.FinalValue = 0;
                entity.SysCreatedByUserID = loggedUserId;
                entity.SysCreatedDate = DateTime.Now;
            }
            else if (operation == GlobalEnum.CrudOperation.Edit)
            {
                entity.SysLastModifiedByUserID = loggedUserId;
                entity.SysLastModifiedDate = DateTime.Now;
            }

            return entity;
        }


        public BudgetTitleDTO Map(BudgetTitle? model, int year, int municipality)
        {
            if (model == null)
            {
                return new BudgetTitleDTO()
                {
                    Year = year,
                    MunicipalityId = municipality
                };
            }

            var entity = new BudgetTitleDTO()
            {
                BudgetTitleGuid = model.BudgetTitleGuid,
                Title = model.Title,
                Year = year,
                MunicipalityId = municipality
            };

            return entity;
        }

        public BudgetTitle Map(BudgetTitleDTO model, GlobalEnum.CrudOperation operation, Guid loggedUserId)
        {
            var entity = new BudgetTitle()
            {
                BudgetTitleGuid = model.BudgetTitleGuid,
                Year = model.Year,
                MunicipalityId = model.MunicipalityId,
                Title = model.Title,
                Retired = false
            };

            if (operation == GlobalEnum.CrudOperation.Add)
            {
                entity.SysCreatedByUserID = loggedUserId;
                entity.SysCreatedDate = DateTime.Now;
            }
            else if (operation == GlobalEnum.CrudOperation.Edit)
            {
                entity.SysLastModifiedByUserID = loggedUserId;
                entity.SysLastModifiedDate = DateTime.Now;
            }

            return entity;
        }
    }
}
