﻿namespace PFMPortal.DTO.BudgetDataComparison
{
    public class MunicipalityBudgetDataDTO
    {
        public string Name { get; set; }
        public List<decimal>? Data { get; set; }
        public List<decimal>? AditionalData { get; set; }
    }
}
