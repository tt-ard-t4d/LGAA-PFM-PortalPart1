﻿using PFMPortal.Domain.Entities.Utils;
using PFMPortal.Infrastructure.Models;

namespace PFMPortal.Domain.Contracts.Utils
{
    public interface IFileRepository
    {
        List<FormFiles> GetFilesFromDB(int id, short typeId);
        List<FormFiles> GetFileFromDB(int id, short typeId, string fileName);
        RetValue UpdateFilesFromDB(IEnumerable<int> ids, int id);
        RetValue Save(FormFiles entity);
        RetValue DeleteFile(int id);
    }
}
