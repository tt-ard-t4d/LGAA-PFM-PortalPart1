﻿namespace PFMPortal.DTO.Admin
{
    public class UserGroupGridDTO
    {
        public short UserGroupID { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Total { get; set; } 
    }
}
