﻿using Infrastructure.Helpers;
using Infrastructure.Models;
using Microsoft.AspNetCore.Mvc.Filters;
using Org.BouncyCastle.Tls;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;
using System.Linq.Expressions;
using System.Security.Claims;

namespace PFMPortal.Infrastructure.Extensions
{
    public static class ClaimsExtension
    {
        public static int GetUserLanguageId(this ClaimsPrincipal principal)
        {
            Claim? claim = principal?.FindFirst(CustomClaimTypes.LanguageId);

            return claim != null ? int.Parse(claim.Value) : 0;
        }

        public static List<Claim> GetClaims(this ClaimsPrincipal principal, string claimType)
        {
            var claims = principal?.FindAll(claimType);

            return claims != null ? claims.ToList() : new List<Claim>();
        }

        public static Claim? GetClaim(this ClaimsPrincipal principal, string claimType)
        {
            return principal?.FindFirst(claimType);
        }
    }
}
