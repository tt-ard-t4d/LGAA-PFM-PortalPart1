﻿using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.BudgetData;
using PFMPortal.Infrastructure.Models;
using static PFMPortal.Infrastructure.Helpers.PFMEnum;

namespace PFMPortal.Domain.Contracts.PFM
{
    public interface IAccountCategoryDataRepository
    {
        public IQueryable<AccountCategoryData> GetAccountCategoryDataGrid(SearchBudgetDataDTO args);
        public RetValue Save(IEnumerable<AccountCategoryData> items, BudgetDataValueType dataValueType);
    }
}
