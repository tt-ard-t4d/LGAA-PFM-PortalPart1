﻿using Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.Municipality;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion.Internal;

namespace PFMPortal.Domain.Contracts.PFM
{
    public interface IMunicipalityRepository
    {
        public Municipality? GetMunicipalityById(int municipalityId);
        public Municipality? GetMunicipalityBySlug(string municipalityName);
        public IQueryable<Municipality> GetAllMunicipalities();
        public RetValue Save(Municipality entity);
        public (IQueryable<Municipality>, int) GetMunicipalityGrid(SearchMunicipalityDTO args);
        public (IQueryable<Municipality>, int) GetMunicipalitiesWithoutEntries(int year);
        public List<int> GetYearsWithData(int municipalityId);
        public IQueryable<Municipality> GetMunicipalitiesForUser(Guid userId);
        public IQueryable<Municipality> GetRetiredMunicipalities();
        public Municipality? GetRetiredMunicipality(int id);
        public RetValue DeleteMunicipality(int id);
    }
}
