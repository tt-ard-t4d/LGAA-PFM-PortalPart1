﻿using PFMPortal.DTO.Utils;
using static PFMPortal.Infrastructure.Helpers.PFMEnum;

namespace PFMPortal.DTO.BudgetDataComparison
{
    public class SearchBudgetDataComparisonDTO
    {
        public List<ItemDDL> Municipalities { get; set; } = new List<ItemDDL>();
        public List<int> MunicipalityIDs { get; set; } = new List<int>();
        public List<ItemDDL> Years { get; set; } = new List<ItemDDL>();
        public int Year { get; set; }
        public GraphType GraphType { get; set; } = GraphType.PlannedBudgetPieChart;
    }
}
