﻿
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Infrastructure.Helpers;
using PFMPortal.Infrastructure.Extensions;

namespace Authorization
{
    public class PowerAdminAuthorizeAttribute : Attribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext filterContext)
        
        {
            if (!filterContext.HttpContext.Session.IsLoggedIn())
            {
                HandleUnauthorizedRequest(filterContext);
            }

            if (!filterContext.HttpContext.User.IsPowerAdmin())
            {
                HandleUnauthorizedRequest(filterContext);
            }
        }

        protected void HandleUnauthorizedRequest(AuthorizationFilterContext filterContext)
        {
            filterContext.HttpContext.SignOutAsync();
            filterContext.HttpContext.Session.Clear();


            var redirectUrl = filterContext.GetReturnUrl();

            filterContext.Result = new RedirectToActionResult("Login", "Login", new { returnUrl = redirectUrl });
        }
    }
}