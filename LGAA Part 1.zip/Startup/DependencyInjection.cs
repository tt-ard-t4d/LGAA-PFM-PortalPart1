﻿using Domain.Contracts;
using FluentValidation;
using Infrastructure.Data.Repositories;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.DependencyInjection.Extensions;
using PFMPortal.Domain.Contracts.Admin;
using PFMPortal.Domain.Contracts.PFM;
using PFMPortal.Domain.Contracts.Utils;
using PFMPortal.DTO.Admin;
using PFMPortal.Infrastructure.Data.Repositories.Admin;
using PFMPortal.Infrastructure.Data.Repositories.PFM;
using PFMPortal.Infrastructure.Data.Repositories.Utils;
using PFMPortal.Infrastructure.Validators;

namespace PFMPortal.Startup
{
    public static class DependencyInjection
    {
        public static void RegisterRepositories(this IServiceCollection services)
        {
            //Admin
            services.AddScoped<IUserRepository, UserRepository>();

            //Utils
            services.AddScoped<IAuditLogEnumerationRepository, AuditLogEnumerationRepository>();
            services.AddScoped<IAuditLogRepository, AuditLogRepository>();
            services.AddScoped<IEmailNotificationRepository, EmailNotificationRepository>();
            services.AddScoped<IFileRepository, FileRepository>();
            services.AddScoped<IDropDownRepository, DropDownRepository>();
            services.AddScoped<IActionManagementRepository, ActionManagementRepository>();
            services.AddScoped<IFileManagementRepository, FileManagementRepository>();

            //HttpContext
            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();

            //PFM
            services.AddScoped<IPFMDropDownRepository, PFMDropdownRepository>();
            services.AddScoped<IBudgetDataRepository, BudgetDataRepository>();
            services.AddScoped<IMunicipalityRepository, MunicipalityRepository>();
            services.AddScoped<IAccountCategoryDataRepository, AccountCategoryDataRepository>();
        }

        public static void RegisterValidators(this IServiceCollection services)
        {
            services.AddScoped<IValidator<UserDTO>, UserDTOValidator>();
        }
    }
}
