﻿using Authorization;
using FluentValidation;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using PFMPortal.DTO.Admin;
using PFMPortal.Infrastructure.Core.Admin;
using PFMPortal.Infrastructure.Core.PFM;
using PFMPortal.Infrastructure.Core.Utils;
using PFMPortal.Infrastructure.Data.Repositories.PFM;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Infrastructure.Resources;

namespace PFMPortal.Controllers.Admin
{

    [AuthorizeUserGroups(ActionManagementEnum.UserGroups.SystemAdministrator)]
    public class UserController : Controller
    {
        private readonly UserService _userService;
        private readonly ReportingService _reportingService;
        private readonly DropDownService _ddl;
        private readonly PFMDropDownService _pfmDdl;
        private readonly SessionService _sessionService;
        private readonly IValidator<UserDTO> _validator;

        public UserController(UserService userService, DropDownService ddl, PFMDropDownService pfmDdl, ReportingService reportingService, SessionService sessionService, IValidator<UserDTO> validator)
        {
            _userService = userService;
            _ddl = ddl;
            _pfmDdl = pfmDdl;
            _reportingService = reportingService;
            _sessionService = sessionService;
            _validator = validator;
        }

        #region <!-- User -->

        public IActionResult Index(SearchUserDTO args)
        {
            CreateFilterDDL(ref args);

            return View(_userService.GetUserGrid(args));
        }

        public IActionResult Create()
        {
            var model = new UserDTO();
            CreateAddEditDDL(ref model);

            return View("Edit", model);
        }

        public IActionResult SaveFailed(UserDTO model)
        {
            CreateAddEditDDL(ref model);
            return View("Edit", model);
        }

        public IActionResult Edit(Guid userId)
        {
            var user = _userService.GetUser(userId);

            if (user.UserID != Guid.Empty)
            {
                CreateAddEditDDL(ref user);
                return View("Edit", user);
            }

            return View("Error");
        }

        [HttpPost]
        public IActionResult Save(UserDTO model)
        {
            var validate = _validator.Validate(model);

            if (!validate.IsValid)
            {
                validate.AddToModelState(this.ModelState);

                if (model.UserID != Guid.Empty)
                {
                    return RedirectToAction("Edit", "User", new { userId = model.UserID });
                }

                return RedirectToAction("Create", "User");
            }

            if (ModelState.IsValid)
            {
                var ddlCheck = model.UserGroupIDs.IsValidList(_ddl.GetUserGroups());

                if (!ddlCheck)
                {
                    CreateAddEditDDL(ref model);
                    return View("Edit", model);
                }

                var save = _userService.Save(model, User.Identity.GetLoggedUserId());

                if (!save.IsError)
                {
                    _sessionService.SessionUpdateOnUserUpdate(HttpContext, save.Guid);
                    TempData["success-message"] = MessageRes.Success;
                    return RedirectToAction("Index", "User");
                }

                TempData["error-message"] = save.ErrorMessage;
                CreateAddEditDDL(ref model);
                return View("Edit", model);
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            CreateAddEditDDL(ref model);
            return View("Edit", model);
        }

        [HttpPost]
        public IActionResult Delete(Guid id)
        {
            Guid loggedUserId = User.GetLoggedUserId();
            var res = _userService.Delete(id, loggedUserId);

            if (!res.IsError)
                TempData["success-message"] = MessageRes.Success;
            else
                TempData["error-message"] = MessageRes.Error;

            RetValue retValue = new()
            {
                ReturnUrl = Url.Action("Index", "User"),
            };

            return Json(retValue);
        }

        #endregion

        #region <!-- DDL -->

        private void CreateFilterDDL(ref SearchUserDTO args)
        {
            args.UserActions = _ddl.GetActions();
            args.UserGroups = _ddl.GetUserGroups();
        }

        private void CreateAddEditDDL(ref UserDTO args)
        {
            args.UserActions = _ddl.GetActions();
            args.UserGroups = _ddl.GetUserGroups();
            args.Municipalities = _pfmDdl.GetAllMunicipalities();
        }

        #endregion

        #region <!-- Reporting -->

        [HttpGet]
        public ActionResult RenderReport(SearchUserDTO args)
        {
            var data = _userService.GetUserGrid(args).Data.ToList();

            Tuple<MemoryStream, string> _excel = _reportingService.GenerateReport(data, "report1");
            return File(_excel.Item1.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", _excel.Item2);
        }

        #endregion

    }
}
