﻿using Microsoft.AspNetCore.Mvc;

namespace PFMPortal.Controllers.Utils
{
    public class EmailController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
