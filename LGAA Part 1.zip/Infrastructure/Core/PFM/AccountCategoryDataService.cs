﻿using PFMPortal.Domain.Contracts.PFM;
using PFMPortal.DTO.BudgetData;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Mappings.PFM;

namespace PFMPortal.Infrastructure.Core.PFM
{
    public class AccountCategoryDataService
    {
        private readonly IAccountCategoryDataRepository _repository;

        public AccountCategoryDataService(IAccountCategoryDataRepository repository)
        {
            _repository = repository;
        }

        public GridDTO<AccountCategoryDataGridDTO, SearchBudgetDataDTO> GetAccountCategoryDataEditGrid(SearchBudgetDataDTO args)
        {
            var ret = new GridDTO<AccountCategoryDataGridDTO, SearchBudgetDataDTO>();
            var retVal = _repository.GetAccountCategoryDataGrid(args);

            var map = new AccountCategoryDataMapper();
            var mappedData = retVal.Select(r => map.MapGrid(r, true)).ToList();

            if (args.AccountTypeID > 0)
            {
                //ovo skontati
            }

            ret.Data = mappedData;
            ret.Search = args;

            return ret;
        }
    }
}
