using Infrastructure.Helpers;
using PFMPortal.Startup;

var builder = WebApplication.CreateBuilder(args);


//Configure services
builder.Services.RegisterApplicationServices(builder.Configuration);

//Validators
builder.Services.RegisterValidators();

var app = builder.Build();

AppSettingsHelper.AppSettingsConfigure(app.Services.GetRequiredService<IConfiguration>(), app.Services.GetRequiredService<IHttpContextAccessor>());

//Middleware
app.ConfigureMiddleware();

//Endpoints
app.RegisterEndpoints();

var type = System.Net.ServicePointManager.SecurityProtocol;

app.Run();
