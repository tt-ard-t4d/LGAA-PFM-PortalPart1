﻿namespace PFMPortal.DTO.Utils
{
    public class FormFileDTO
    {
        public int FormFileID { get; set; } = 0;
        public Guid? FileGUID { get; set; }
        public string FileName { get; set; }
        public string FileExtension { get; set; }
        public long FileLenght { get; set; }
        public string UrlAzure { get; set; }
        public Guid SysCreatedByUserID { get; set; }
    }
}
