﻿using Infrastructure.Data;
using Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using NuGet.Packaging;
using PFMPortal.Domain.Contracts.Admin;
using PFMPortal.Domain.Entities;
using PFMPortal.DTO.Admin;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Infrastructure.Extensions;

namespace PFMPortal.Infrastructure.Data.Repositories.Admin
{
    using Action = Domain.Entities.Action;
    public class ActionManagementRepository : IActionManagementRepository
    {
        private readonly DatabaseContext _dc;

        public ActionManagementRepository(DatabaseContext dc)
        {
            _dc = dc;
        }

        public Action? GetAction(int actionId)
        {
            return _dc.Actions.AsNoTracking().FirstOrDefault(r => r.Retired == false && r.ActionID == actionId);
        }

        public (IQueryable<Action>, int) GetActionGrid(SearchActionDTO args)
        {
            var res = _dc.Actions.AsNoTracking().Where(r => r.Retired == false);

            if (!string.IsNullOrEmpty(args.SearchTerm))
            {
                res = res.Where(r => r.ActionName.ToLower().Contains(args.SearchTerm.ToLower()) 
                        || r.ActionEnumerationName.ToLower().Contains(args.SearchTerm.ToLower()));
            }

            (var columnName, var direction) = UtilsHelper.GetSortOrder(args.SortBy);
            res = res.SortRows(columnName, direction);

            return (res, res.Count());
        }

        public (IQueryable<ActionHistory>, int) GetTemporalActionGrid(SearchActionDTO args)
        {
            var res = _dc.ActionsHistory
                .AsNoTracking()
                .Where(r => r.ActionID == args.ActionID);

            if (!string.IsNullOrEmpty(args.SearchTerm))
            {
                res = res.Where(r => r.ActionEnumerationName.ToLower().Contains(args.SearchTerm.ToLower())
                || r.ActionName.ToLower().Contains(args.SearchTerm.ToLower()));
            }

            if (args.DateModifiedFrom.HasValue)
            {
                res = res.Where(r => r.SysLastModifiedDate >= args.DateModifiedFrom.Value);
            }
            if (args.DateModifiedTo.HasValue)
            {
                res = res.Where(r => r.SysLastModifiedDate <= args.DateModifiedTo.Value);
            }

            res = res.OrderByDescending(r => r.SysLastModifiedDate);

            return (res, res.Count());
        }


        public IQueryable<Action> GetActionsForUser(Guid userId)
        {
            return _dc.UserActions
                .Include(r => r.Action)
                .AsNoTracking()
                .Where(r => r.Retired == false && r.UserID == userId).Select(r => r.Action);
        }

        public IQueryable<Action> GetActionsForUserGroup(int userGroupId)
        {
            return _dc.UserGroupActions
                .Include(r => r.Action)
                .AsNoTracking()
                .Where(r => r.Retired == false && r.UserGroupID == userGroupId).Select(r => r.Action);
        }

        public RetValue SaveAction(Action entity, GlobalEnum.CrudOperation operation)
        {
            if (operation == GlobalEnum.CrudOperation.Edit)
            {
                _dc.Actions.Attach(entity);
                _dc.Entry(entity).State = EntityState.Modified;

                _dc.Entry(entity).Property(r => r.SysCreatedByUserID).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedDate).IsModified = false;
            }
            else if (operation == GlobalEnum.CrudOperation.Add)
            {
                _dc.Actions.Add(entity);
            }

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Id = entity.ActionID };
        }

        public RetValue SaveActionsForUser(User entity, ActionAssignmentDTO vm)
        {
            _dc.Users.Attach(entity);
            _dc.Entry(entity).State = EntityState.Modified;

            SaveUserActionRel(ref entity, vm);

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Guid = entity.UserID };
        }

        public RetValue SaveActionsForUserGroup(UserGroup entity, ActionAssignmentDTO vm)
        {
            _dc.UserGroups.Attach(entity);
            _dc.Entry(entity).State = EntityState.Modified;

            SaveUserGroupActionsRel(ref entity, vm);

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Id = entity.UserGroupID };
        }

        private void SaveUserActionRel(ref User entity, ActionAssignmentDTO vm)
        {
            var actionIds = vm.UserActionIDs;

            var existing = _dc.UserActions.Where(r => r.UserID == vm.UserID);

            if (existing != null)
            {
                foreach (var item in existing)
                {
                    if (actionIds.Contains(item.ActionID))
                    {
                        item.Retired = false;
                        actionIds.Remove(item.ActionID);
                    }
                    else
                    {
                        item.Retired = true;
                    }
                }
            }

            if (actionIds != null)
            {
                var actions = _dc.Actions.Where(r => r.Retired == false && actionIds.Contains(r.ActionID));
                var addActions = new List<UserActionRel>();

                foreach (var item in actions)
                {
                    addActions.Add(
                        new UserActionRel()
                        {
                            User = entity,
                            Action = item,
                            Retired = false
                        }
                    );
                }

                entity.UserActions ??= new List<UserActionRel>();
                entity.UserActions.AddRange(addActions);
            }
        }

        private void SaveUserGroupActionsRel(ref UserGroup entity, ActionAssignmentDTO vm)
        {
            var actionIds = vm.GroupActionIDs;

            //Get all relations (even retired) with tracking
            var existing = _dc.UserGroupActions.Where(r => r.UserGroupID == vm.UserGroupID);
             
            if (existing != null)
            {
                foreach (var item in existing)
                {
                    if (actionIds.Contains(item.ActionID))
                    {
                        item.Retired = false;
                        actionIds.Remove(item.ActionID);
                    }
                    else
                    {
                        item.Retired = true;
                    }
                }
            }

            if (actionIds != null)
            {
                var actions = _dc.Actions.Where(r => r.Retired == false && actionIds.Contains(r.ActionID));
                var addActions = new List<UserGroupActionRel>();

                foreach (var item in actions)
                {
                    addActions.Add(
                        new UserGroupActionRel()
                        {
                            Action = item,
                            UserGroup = entity,
                            Retired = false
                        }
                    );
                }

                entity.UserGroupActions ??= new List<UserGroupActionRel>();
                entity.UserGroupActions.AddRange(addActions);
            }
        }

        public UserGroup? GetUserGroup(int userGroupId)
        {
            return _dc.UserGroups
                .AsNoTracking()
                .FirstOrDefault(r => r.Retired == false && r.UserGroupID == userGroupId);
        }

        public (IQueryable<UserGroup>, int) GetUserGroupGrid(SearchUserGroupDTO args)
        {
            var res = _dc.UserGroups.AsNoTracking().Where(r => r.Retired == false);

            if (!string.IsNullOrEmpty(args.SearchTerm))
            {
                res = res.Where(r => r.Name.ToLower().Contains(args.SearchTerm.ToLower()));
            }

            return (res, res.Count());
        }

        public RetValue SaveUserGroup(UserGroup entity, GlobalEnum.CrudOperation operation)
        {
            if (operation == GlobalEnum.CrudOperation.Edit)
            {
                _dc.UserGroups.Attach(entity);
                _dc.Entry(entity).State = EntityState.Modified;

                _dc.Entry(entity).Property(r => r.SysCreatedByUserID).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedDate).IsModified = false;
            }
            else if (operation == GlobalEnum.CrudOperation.Add)
            {
                _dc.UserGroups.Add(entity);
            }

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Id = entity.UserGroupID };
        }
    }
}
