﻿using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.BudgetData;

namespace PFMPortal.Infrastructure.Mappings.PFM
{
    public class AccountCategoryDataMapper
    {
        public AccountCategoryDataGridDTO MapGrid(AccountCategoryData entity, bool isEdit)
        {
            var model = new AccountCategoryDataGridDTO()
            {
                AccountCategoryDataID = entity.AccountCategoryDataID,
                MunicipalityName = entity.Municipality?.MunicipalityName ?? string.Empty,
                AccountCategoryID = entity.AccountCategoryID,
                AccountCategoryName = entity.AccountCategory?.AccountCategoryName ?? string.Empty,
                Year = entity.Year,
                MunicipalityID = entity.MunicipalityID,
                TotalPlannedValue = entity.TotalPlannedValue,
                TotalFinalValue = entity.TotalFinalValue
            };

            //if (isEdit)
            //{
            //    model.AccountCategoryHelperName = AddEditModeSpan(entity.BudgetPosition?.AccountCategoryID, entity.BudgetPosition?.AccountCategory?.AccountCategoryName);
            //}
            //else
            //{
            //    model.AccountCategoryHelperName =
            //        AddReadModeSpan(entity.BudgetPosition?.AccountCategoryID, entity.BudgetPosition?.AccountCategory?.AccountCategoryName, entity.BudgetPosition?.AccountCategory?.Information);
            //}

            return model;
        }
    }
}
