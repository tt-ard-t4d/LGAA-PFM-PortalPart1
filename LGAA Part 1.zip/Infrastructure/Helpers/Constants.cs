﻿namespace PFMPortal.Infrastructure.Helpers
{
    public class Constants
    {
        public const int NumberOfObjectsPerPage = 20;
        public const int DefaultPageNumber = 1;

        public static readonly string DefaultSortOrder = "asc";
        public static readonly string NotDefaultIfSortOrder = "desc";

        public static readonly string Error = "error";
        public static readonly string Success = "success";
        public static readonly string Warning = "warning";

        public static readonly string KendoGridMoneyFormat = "{0:n2}";
    }
}
