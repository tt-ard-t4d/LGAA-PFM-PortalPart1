﻿using AngleSharp.Dom;
using PFMPortal.Domain.Contracts;
using PFMPortal.Domain.Entities.App;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;

namespace PFMPortal.Domain.Entities
{
    public class User : SysEntity
    {
        public Guid UserID { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidTo { get; set; }
        public string FirstNameEnc { get; set; }
        public string LastNameEnc { get; set; }
        public string EmailEnc { get; set; }
        public string UserNameEnc { get; set; }
        public string PasswordHash { get; set; }
        public string PasswordSalt { get; set; }                                             
        public Guid EmailCode { get; set; }
        public int LanguageId { get; set; } 
        public virtual ICollection<UserGroupUserRel> UserGroupUsers { get; set; }
        public virtual ICollection<UserActionRel> UserActions { get; set; }
        public virtual ICollection<UserMunicipalityRel> UserMunicipalities { get; set; }
        public bool IsDirectoryUser  { get; set; }
    }
}
