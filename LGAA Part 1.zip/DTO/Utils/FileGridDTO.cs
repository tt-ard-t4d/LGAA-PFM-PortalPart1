﻿namespace PFMPortal.DTO.Utils
{
    public class FileGridDTO
    {
        public int FormFileID { get; set; } = 0;
        public Guid? FileGUID { get; set; }
        public string FileName { get; set; } = string.Empty;
        public string FileExtension { get; set; } = string.Empty;   
        public decimal FileSize { get; set; }
        public string UrlAzure { get; set; } = string.Empty;
        public Guid UserID { get; set; }
        public int Total { get; set; }
        public string MunicipalityName { get; set; } = string.Empty;
        public string LGUStatus { get; set; } = string.Empty;
    }
}
