﻿using Infrastructure.Helpers;
using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.BudgetData;
using PFMPortal.Infrastructure.Models;
using static PFMPortal.Infrastructure.Helpers.PFMEnum;

namespace PFMPortal.Domain.Contracts.PFM
{
    public interface IBudgetDataRepository
    {
        public IQueryable<BudgetData> GetBudgetDataGrid(SearchBudgetDataDTO args);
        public List<int> GetBudgetDataYears();
        public List<int> GetBudgetDataYearsForMunicipality(int municipalityId);
        public RetValue CreateBudgetDataEntry(int year, List<Municipality> municipalities, Guid loggedUserId);
        public RetValue Save(IEnumerable<BudgetData> items, BudgetDataValueType dataValueType);
        public IQueryable<BudgetData> GetDataForChart(int municipalityID, int yearID, short accountTypeID);
        public IQueryable<BudgetData> GetDataForChartMunicipalities(List<int> municipalityIDs, int year, int accountTypeID);
        public BudgetTitle? GetBudgetTitle(int yearId, int municipalityId);
        public RetValue SaveBudgetTitle(BudgetTitle entity, GlobalEnum.CrudOperation operation);
    }
}
