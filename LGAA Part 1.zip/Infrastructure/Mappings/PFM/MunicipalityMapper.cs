﻿using Infrastructure.Helpers;
using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.Municipality;

namespace PFMPortal.Infrastructure.Mappings.PFM
{
    public class MunicipalityMapper
    {
        public MunicipalityDTO Map(Municipality? entity)
        {
            if (entity == null)
            {
                return new MunicipalityDTO();
            }

            return new MunicipalityDTO()
            {
                MunicipalityID = entity.MunicipalityID,
                EntityID = entity.EntityID,
                EntityName = entity.Entity.EntityName,
                MunicipalityName = entity.MunicipalityName,
                LocalGovernmentUnitName = entity.LocalGovernmentUnit.LocalGovernmentUnitName,
                LocalGovernmentUnitID = entity.LocalGovernmentUnitID,
                Slug = entity.Slug,
            };
        }

        public Municipality Map(MunicipalityDTO model, GlobalEnum.CrudOperation operation, Guid loggedUserId)
        {
            var entity = new Municipality()
            {
                MunicipalityID = model.MunicipalityID,
                EntityID = model.EntityID,
                MunicipalityName = model.MunicipalityName,
                Slug = model.Slug
            };

            if (operation == GlobalEnum.CrudOperation.Add)
            {
                entity.SysCreatedByUserID = loggedUserId;
                entity.SysCreatedDate = DateTime.Now;
            }
            else if (operation == GlobalEnum.CrudOperation.Edit)
            {
                entity.SysLastModifiedByUserID = loggedUserId;
                entity.SysLastModifiedDate = DateTime.Now;
            }

            return entity;
        }

        public MunicipalityGridDTO MapGrid(Municipality entity, int totalNumberOfRows)
        {
            return new MunicipalityGridDTO()
            {
                MunicipalityID = entity.MunicipalityID,
                MunicipalityName = entity.MunicipalityName,
                LocalGovernmentUnitName = entity.LocalGovernmentUnit.LocalGovernmentUnitName,
                EntityName = entity.Entity?.EntityName ?? string.Empty,
                Total = totalNumberOfRows,
                Slug = entity.Slug
            };
        }
    }
}
