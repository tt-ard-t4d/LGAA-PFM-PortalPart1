﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace PFMPortal.Infrastructure.Extensions
{
    public static class SortExtension
    {
        /// <summary>
        /// Return url, we DI for this define in Startup
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        private static IUrlHelper GetUrlHelper(this IHtmlHelper html)
        {
            var urlFactory = html.ViewContext.HttpContext.RequestServices.GetRequiredService<IUrlHelperFactory>();
            var actionAccessor = html.ViewContext.HttpContext.RequestServices.GetRequiredService<IActionContextAccessor>();
            return urlFactory.GetUrlHelper(actionAccessor.ActionContext);
        }

        public static IHtmlContent SortableColumnLink(this IHtmlHelper html, string actionLink = "", string title = "", string columnName = "", string sortBy = "")
        {
            StringBuilder output = new StringBuilder();
            System.Collections.Specialized.NameValueCollection requestQueryString = HttpUtility.ParseQueryString(html.ViewContext.HttpContext.Request.QueryString.ToString());
            Dictionary<string, string> resultQueryString = new Dictionary<string, string>();
            string sortColumn = "";
            string ascDesc = "";

            // Build query string
            foreach (var requestQueryStringKey in requestQueryString.AllKeys)
            {
                if (!String.IsNullOrEmpty(requestQueryStringKey) && !String.IsNullOrEmpty(requestQueryString[requestQueryStringKey]) && requestQueryStringKey.ToLower() != "sortby")
                {
                    resultQueryString.Add(requestQueryStringKey.ToLower(), requestQueryString[requestQueryStringKey].ToString());
                }
            }

            // If something is sorted
            if (!String.IsNullOrEmpty(sortBy))
            {
                sortColumn = sortBy.Split('_')[0];
                ascDesc = sortBy.Split('_')[1];
            }

            actionLink += $"?sortBy={columnName.ToLower()}_{(ascDesc.ToLower() == "asc" ? "desc" : "asc")}";

            if (resultQueryString.Count > 0)
            {
                actionLink += "&";
                actionLink += string.Join("&", resultQueryString
                    .OrderBy(x => x.Key)
                    .Where(x => x.Value != null)
                    .Select(x => x.Key + "=" + x.Value).ToArray());
            }

            output.Append($"<a href=\"{actionLink}\">");
            output.Append($"{title}");


            if (!String.IsNullOrEmpty(sortColumn))
            {
                if (sortColumn.ToLower() == columnName.ToLower())
                {
                    if (ascDesc.ToLower() == "asc")
                    {
                        output.Append("<i class=\"sorting-icon bi bi-caret-up-fill\"></i>");
                    }
                    else
                    {
                        output.Append("<i class=\"sorting-icon bi bi-caret-down-fill\"></i>");
                    }
                }
            }
            else
            {
                output.Append("<i class=\"sorting-icon bi bi-funnel\"></i>");
            }

            output.Append("</a>");
            return new HtmlString(output.ToString());
        }

        public static string IsSelected(this IHtmlHelper html, string controllers = "", string actions = "", string cssClass = "selected")
        {
            ViewContext viewContext = html.ViewContext;
            //bool isChildAction = viewContext.RouteData.Values["Controller"];
            string[] acceptedActions = null;

            /*if (isChildAction)
                viewContext = html.ViewContext.ParentActionViewContext;*/

            string currentAction = viewContext.RouteData.Values["action"].ToString();
            string currentController = viewContext.RouteData.Values["controller"].ToString();

            if (String.IsNullOrEmpty(controllers))
                controllers = currentController;

            if (!String.IsNullOrEmpty(actions))
                acceptedActions = actions.Trim().Split(',').Distinct().ToArray();

            string[] acceptedControllers = controllers.Trim().Split(',').Distinct().ToArray();

            if (acceptedActions != null)
            {
                return acceptedActions.Contains(currentAction) && acceptedControllers.Contains(currentController) ?
                    cssClass : String.Empty;
            }
            else
            {
                return acceptedControllers.Contains(currentController) ?
                    cssClass : String.Empty;
            }
        }

        public static string RemoveQueryStringByKey(this IHtmlHelper html, string url, string key)
        {
            var queryString = HttpUtility.ParseQueryString(url);
            queryString.Remove(key);
            return "?" + queryString.ToString();
        }

        public static IHtmlContent FilterDetailsData(this IHtmlHelper html, string actionLink = "", string title = "", string columnName = "", string sortBy = "")
        {
            StringBuilder output = new StringBuilder();
            System.Collections.Specialized.NameValueCollection requestQueryString = HttpUtility.ParseQueryString(html.ViewContext.HttpContext.Request.QueryString.ToString());
            Dictionary<string, string> resultQueryString = new Dictionary<string, string>();
            string sortColumn = "";
            string ascDesc = "";

            // Build query string
            foreach (var requestQueryStringKey in requestQueryString.AllKeys)
            {
                if (!String.IsNullOrEmpty(requestQueryStringKey) && !String.IsNullOrEmpty(requestQueryString[requestQueryStringKey]) && requestQueryStringKey.ToLower() != "sortby")
                {
                    resultQueryString.Add(requestQueryStringKey.ToLower(), requestQueryString[requestQueryStringKey].ToString());
                }
            }

            // If something is sorted
            if (!String.IsNullOrEmpty(sortBy))
            {
                sortColumn = sortBy.Split('_')[0];
                ascDesc = sortBy.Split('_')[1];
            }

            actionLink += $"?sortBy={columnName.ToLower()}_{(ascDesc.ToLower() == "asc" ? "desc" : "asc")}";

            if (resultQueryString.Count > 0)
            {
                actionLink += "&";
                actionLink += string.Join("&", resultQueryString
                    .OrderBy(x => x.Key)
                    .Where(x => x.Value != null)
                    .Select(x => x.Key + "=" + x.Value).ToArray());
            }

            output.Append($"<a href=\"{actionLink}\">");
            output.Append($"{title}");

            return new HtmlString(output.ToString());
        }
    }
}
