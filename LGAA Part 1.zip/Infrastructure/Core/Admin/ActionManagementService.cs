﻿using Infrastructure.Helpers;
using PFMPortal.Domain.Contracts.Admin;
using PFMPortal.DTO.Admin;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Mappings;
using PFMPortal.Infrastructure.Mappings.Admin;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Infrastructure.Resources;

namespace PFMPortal.Infrastructure.Core.Admin
{
    public class ActionManagementService
    {
        private readonly IActionManagementRepository _actionManagementRepository;
        private readonly IUserRepository _userRepository;

        public ActionManagementService(IActionManagementRepository actionManagementRepository, IUserRepository userRepository)
        {
            _actionManagementRepository = actionManagementRepository;
            _userRepository = userRepository;
        }

        #region <!-- Action -->

        public List<ItemDDL> GetActionsForUser(Guid userId)
        {
            var actions = _actionManagementRepository.GetActionsForUser(userId);

            return actions.Select(r => new ItemDDL() { Id = r.ActionID, Value = $"{r.ActionName} ({r.ActionEnumerationName})" }).ToList();
        }

        public List<ItemDDL> GetActionsForUserGroup(int userGroupId)
        {
            var actions = _actionManagementRepository.GetActionsForUserGroup(userGroupId);

            return actions.Select(r => new ItemDDL() { Id = r.ActionID, Value = $"{r.ActionName} ({r.ActionEnumerationName})" }).ToList();
        }

        public ActionDTO GetAction(int actionId)
        {
            var map = new ActionMapper();
            var entity = _actionManagementRepository.GetAction(actionId);

            return map.Map(entity);
        }

        public GridDTO<ActionGridDTO, SearchActionDTO> GetActionGrid(SearchActionDTO args, int pageNumber = Constants.DefaultPageNumber, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<ActionGridDTO, SearchActionDTO>();
            (var retVal, var totalNumberOfRows) = _actionManagementRepository.GetActionGrid(args);
            var pager = new PageDTO(totalNumberOfRows, args.Page, numberOfObjectsPerPage);

            var map = new ActionMapper();
            var paged = retVal.Page(numberOfObjectsPerPage, args.Page);
            var grid = paged.Select(r => map.Map(r, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        public GridDTO<ActionGridDTO, SearchActionDTO> GetActionTemporalGrid(SearchActionDTO args, int pageNumber = Constants.DefaultPageNumber, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<ActionGridDTO, SearchActionDTO>();
            (var retVal, var totalNumberOfRows) = _actionManagementRepository.GetTemporalActionGrid(args);
            var pager = new PageDTO(totalNumberOfRows, args.Page, numberOfObjectsPerPage);

            var map = new ActionMapper();
            var paged = retVal.Page(numberOfObjectsPerPage, args.Page);
            var grid = paged.Select(r => map.MapHistory(r, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        public RetValue SaveAction(ActionDTO model, Guid loggedUserId)
        {
            var operation = GlobalEnum.CrudOperation.Add;
            var map = new ActionMapper();

            if (model.ActionID > 0)
            {
                operation = GlobalEnum.CrudOperation.Edit;
            }

            var entity = map.Map(model, operation, loggedUserId);

            return _actionManagementRepository.SaveAction(entity, operation);
        }

        #endregion

        #region <!-- User group -->

        public GridDTO<UserGroupGridDTO, SearchUserGroupDTO> GetUserGroupGrid(SearchUserGroupDTO args, int pageNumber = Constants.DefaultPageNumber, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<UserGroupGridDTO, SearchUserGroupDTO>();
            (var retVal, var totalNumberOfRows) = _actionManagementRepository.GetUserGroupGrid(args);
            var pager = new PageDTO(totalNumberOfRows, args.Page, numberOfObjectsPerPage);

            var map = new UserGroupMapper();
            var paged = retVal.Page(numberOfObjectsPerPage, args.Page);
            var grid = paged.Select(r => map.Map(r, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }

        public UserGroupDTO GetUserGroup(int userGroupId)
        {
            var map = new UserGroupMapper();
            var entity = _actionManagementRepository.GetUserGroup(userGroupId);

            return map.Map(entity);
        }

        public RetValue SaveUserGroup(UserGroupDTO model, Guid loggedUserId)
        {
            var operation = GlobalEnum.CrudOperation.Add;
            var map = new UserGroupMapper();

            if (model.UserGroupID > 0)
            {
                operation = GlobalEnum.CrudOperation.Edit;
            }

            var entity = map.Map(model, operation, loggedUserId);

            return _actionManagementRepository.SaveUserGroup(entity, operation);
        }

        #endregion

        #region <!-- Action management -->

        public RetValue SaveActionsForUserGroup(ActionAssignmentDTO model)
        {
            var userGroup = _userRepository.GetUserGroupById(model.UserGroupID);
            
            if (userGroup != null)
            {
                return _actionManagementRepository.SaveActionsForUserGroup(userGroup, model);
            }

            return new RetValue() { IsError = true, ErrorMessage = MessageRes.MissingUserGroup };
        }

        public RetValue SaveActionsForUser(ActionAssignmentDTO model)
        {
            var user = _userRepository.GetUserById(model.UserID);

            if (user != null)
            {
                return _actionManagementRepository.SaveActionsForUser(user, model);
            }

            return new RetValue() { IsError = true, ErrorMessage = MessageRes.MissingUser };
        }

        #endregion
    }
}
