﻿using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using PFMPortal.Domain.Contracts.PFM;
using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.BudgetData;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;
using static PFMPortal.Infrastructure.Helpers.PFMEnum;

namespace PFMPortal.Infrastructure.Data.Repositories.PFM
{
    public class AccountCategoryDataRepository : IAccountCategoryDataRepository
    {
        private readonly DatabaseContext _dc;

        public AccountCategoryDataRepository(DatabaseContext dc)
        {
            _dc = dc;
        }

        public IQueryable<AccountCategoryData> GetAccountCategoryDataGrid(SearchBudgetDataDTO args)
        {
            var res = _dc.AccountCategoryData.AsNoTracking()
                .Where(r => r.Retired == false && r.MunicipalityID == args.MunicipalityID && r.Year == args.Year)
                .Include(r => r.Municipality)
                .Include(r => r.AccountCategory);

            return res;
        }

        public RetValue Save(IEnumerable<AccountCategoryData> accountCategoryData, PFMEnum.BudgetDataValueType dataValueType)
        {
            foreach (var item in accountCategoryData)
            {
                _dc.AccountCategoryData.Attach(item);

                _dc.Entry(item).Property(r => r.SysLastModifiedByUserID).IsModified = true;
                _dc.Entry(item).Property(r => r.SysLastModifiedDate).IsModified = true;

                if (dataValueType == BudgetDataValueType.Planned)
                {
                    _dc.Entry(item).Property(r => r.TotalPlannedValue).IsModified = true;
                }
                else if (dataValueType == BudgetDataValueType.Final)
                {
                    _dc.Entry(item).Property(r => r.TotalFinalValue).IsModified = true;
                }
            }

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { IsError = false };
        }
    }
}
