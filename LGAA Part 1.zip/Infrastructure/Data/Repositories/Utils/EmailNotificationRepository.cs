﻿
using Domain.Contracts;
using Domain.Entities.Utils;
using DTO.Utils;
using Infrastructure.Mappings.Utils;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Infrastructure.Data.Repositories
{
    public class EmailNotificationRepository : IEmailNotificationRepository
    {
        private DatabaseContext dc;
        public EmailNotificationRepository(DatabaseContext ctx)
        {
            dc = ctx;

        }

        /// <summary>
        /// Get item from EmailNotification
        /// </summary>
        /// <returns>Mapped List EmailNotification items</returns>
        public List<EmailNotificationDTO> GetAllEmailNotification()
        {
            List<EmailNotificationDTO> emailnotificationNew = new List<EmailNotificationDTO>();
            var emailnotificationMapper = new EmailNotificationMapper();

            List<EmailNotification> emailnotification = dc.EmailNotifications.AsNoTracking().ToList();

            if (emailnotification != null)
            {
                foreach (var item in emailnotification)
                {
                    emailnotificationNew.Add(emailnotificationMapper.MapEmailNotification(item));
                }
            }

            return emailnotificationNew;

        }

        /// <summary>
        /// Get item EmailNotification by id 
        /// </summary>
        /// <param name="id">ID EmailNotification</param>
        /// <returns>Mapped EmailNotification item</returns>
        public EmailNotificationDTO GetEmailNotificationItem(int? id)
        {
            var emailnotificationMapper = new EmailNotificationMapper();
            EmailNotification emailnotification = dc.EmailNotifications.AsNoTracking().FirstOrDefault(s => s.EmailNotificationID == id);

            if (emailnotification != null)
                return emailnotificationMapper.MapEmailNotification(emailnotification);
            else
                return emailnotificationMapper.MapEmailNotification();
        }

        public void SaveEmailNotification(EmailNotificationDTO emailnotification, int loggedUserId)
        {
            var emailnotificationMapper = new EmailNotificationMapper();
            EmailNotification _emailnotification = emailnotificationMapper.MapEmailNotification(emailnotification);

            if (_emailnotification.EmailNotificationID > 0)
            {
                _emailnotification.SysDateLastModified = DateTime.Now;
                _emailnotification.SysModifiedByUserID = loggedUserId;
                dc.EmailNotifications.Attach(_emailnotification);
                dc.Entry(_emailnotification).State = EntityState.Modified;
            }
            else
            {
                dc.EmailNotifications.Add(_emailnotification);
            }

            dc.SaveChanges();
        }

    }
}
