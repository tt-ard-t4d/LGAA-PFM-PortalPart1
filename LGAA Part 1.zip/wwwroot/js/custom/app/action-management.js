﻿var app = app || {};

app.actionManagement = function () {

    var initActionForm = function () {
        console.log("init");

        app.resource.initSpecificResource('Validations', function () {
            $('form[id="EditActionForm"]').validate({
                ignore: [],
                rules: {
                    'ActionName':
                    {
                        required: true
                    },
                    'ActionEnumerationName':
                    {
                        required: true
                    },
                    'Description':
                    {
                        required: true
                    }
                },
                messages: {
                    'ActionName':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'ActionEnumerationName':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'Description':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    }
                }
            });
        });
    }

    return {
        initActionForm: initActionForm
    }
}();