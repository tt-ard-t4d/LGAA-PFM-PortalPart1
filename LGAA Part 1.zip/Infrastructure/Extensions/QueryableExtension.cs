﻿using DocumentFormat.OpenXml.Spreadsheet;
using System.Linq.Expressions;
using System.Reflection;

namespace PFMPortal.Infrastructure.Extensions
{
    public static class QueryableExtension
    {
        public static IQueryable<T> SortRows<T>(this IQueryable<T> source, string? propertyName, string? direction)
        {
            bool? isDescending = IsDescending(direction);

            if (!source.Any() || string.IsNullOrEmpty(propertyName) || isDescending == null)
            {
                return source;
            }

            try
            {
                return source.OrderBy(propertyName, isDescending: isDescending.Value);
            }
            catch 
            {

            }

            return source;
        }

        private static bool? IsDescending(string? direction)
        {
            if (string.IsNullOrEmpty(direction)) return null;
            if (direction.Equals("desc", StringComparison.OrdinalIgnoreCase)) return true;
            if (direction.Equals("asc", StringComparison.OrdinalIgnoreCase)) return false;

            return null;
        }
    }
}
