﻿namespace PFMPortal.DTO.BudgetData;

public class ChartBudgetTypePieDTO
{
    public int Id { get; set; }
    public string Label { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public decimal Amount { get; set; }

}
