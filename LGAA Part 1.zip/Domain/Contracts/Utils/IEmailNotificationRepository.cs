﻿
using DTO.Utils;
using System.Collections.Generic;

namespace Domain.Contracts
{
    public interface IEmailNotificationRepository
    {
        List<EmailNotificationDTO> GetAllEmailNotification();
        EmailNotificationDTO GetEmailNotificationItem(int? id);
        void SaveEmailNotification(EmailNotificationDTO emailnotification, int loggedUserId);
    }
}
