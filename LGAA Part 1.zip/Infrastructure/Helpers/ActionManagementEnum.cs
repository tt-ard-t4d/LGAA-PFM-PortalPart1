﻿namespace PFMPortal.Infrastructure.Helpers
{
    public class ActionManagementEnum
    {
        public enum UserGroups : short
        {
            SystemAdministrator = 1,
            LGUAdministrator = 2
        }

        public enum ActionEnumeration : short
        {
            ADMIN_USER_CREATE = 1,
            ADMIN_USER_READ = 2,
            ADMIN_USER_EDIT = 3,
            ADMIN_USER_DELETE = 4,
            ADMIN_USERS_OVERVIEW = 5
        }
    }
}
