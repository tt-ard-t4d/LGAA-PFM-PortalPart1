﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Resources;
using System.Text;

namespace PFMPortal.Infrastructure.Extensions
{
    public static class HtmlExtension
    {
        private static IUrlHelper GetUrlHelper(this IHtmlHelper html)
        {
            var urlFactory = html.ViewContext.HttpContext.RequestServices.GetRequiredService<IUrlHelperFactory>();
            var actionAccessor = html.ViewContext.HttpContext.RequestServices.GetRequiredService<IActionContextAccessor>();
            return urlFactory.GetUrlHelper(actionAccessor.ActionContext);
        }

        public static IHtmlContent PaginationTailwind<T, S>(this IHtmlHelper helper, GridDTO<T, S> grid, string action = "", string controller = "")
        {
            if (grid.Pager is null || grid is null)
                return new HtmlString("");

            var urlHelper = helper.GetUrlHelper();
            StringBuilder output = new();

            //Calculate which results are shown
            int firstResultOnPage = (grid.Pager.CurrentPage - 1) * grid.Pager.NumberOfRowsPerPage + 1;
            int lastResultOnPage = grid.Pager.CurrentPage * grid.Pager.NumberOfRowsPerPage;
            if (grid.Pager.TotalPages == 1 || grid.Pager.CurrentPage == grid.Pager.TotalPages)
                lastResultOnPage = grid.Pager.TotalNumberOfRows;

            //Show number of results
            output.AppendLine("<nav class=\"flex flex-col md:flex-row justify-between items-center space-y-3 md:space-y-0 p-4\" aria-label=\"Table navigation\">");
            output.AppendLine("<span class=\"text-sm font-normal text-gray-500\">");
            output.AppendLine(Labels.Showing);
            if(grid.Pager.TotalNumberOfRows != 0)
            {
                output.AppendLine($"<span class=\"font-semibold text-gray-900\">{firstResultOnPage}-{lastResultOnPage}</span>");
                output.AppendLine(Labels.Of);
            }
            output.AppendLine($"<span class='font-semibold text-gray-900'>{grid.Pager.TotalNumberOfRows} </span>");
            output.AppendLine(Labels.Results);
            output.AppendLine("</span>");
            output.AppendLine("<ul class=\"inline-flex items-stretch -space-x-px\">");

            //First page
            string typeOfStart = grid.Pager.CurrentPage > 1 ? "a" : "span";
            output.AppendLine("<li>");
            output.AppendLine($"<{typeOfStart} href=\"{PagingLink(urlHelper, urlHelper.Action(action, controller))}\" class=\"flex items-center justify-center h-full py-1.5 px-3 ml-0 text-gray-500 bg-white rounded-l-lg border border-gray-300 {(grid.Pager.CurrentPage > 1 ? "hover:bg-gray-100 hover:text-gray-700" : "")}\">");
            output.AppendLine($"<svg class=\"w-5 h-3\" aria-hidden=\"true\" fill=\"none\" viewbox=\"0 0 12 10\" xmlns=\"http://www.w3.org/2000/svg\">");
            output.AppendLine("<path stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M5 1 1 5l4 4m6-8L7 5l4 4\" />");
            output.AppendLine("</svg>");
            output.AppendLine($"</{typeOfStart}>");
            output.AppendLine("</li>");

            //Previous page
            output.AppendLine("<li>");
            output.AppendLine($"<{typeOfStart} href=\"{PagingLink(urlHelper, urlHelper.Action(action, controller), grid.Pager.CurrentPage - 1)}\" class=\"flex items-center justify-center h-full py-1.5 px-3 ml-0 text-gray-500 bg-white border border-gray-300 {(grid.Pager.CurrentPage > 1 ? "hover:bg-gray-100 hover:text-gray-700" : "")}\">");
            output.AppendLine($"<svg class=\"w-5 h-5\" aria-hidden=\"true\" fill=\"currentColor\" viewbox=\"0 0 20 20\" xmlns=\"http://www.w3.org/2000/svg\">");
            output.AppendLine("<path fill-rule=\"evenodd\" d=\"M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z\" clip-rule=\"evenodd\" />");
            output.AppendLine("</svg>");
            output.AppendLine($"</{typeOfStart}>");
            output.AppendLine("</li>");

            //All pages
            for (var page = grid.Pager.StartPage; page <= grid.Pager.EndPage; page++)
            {
                output.AppendLine("<li>");
                if (page == grid.Pager.CurrentPage)
                    output.AppendLine($"<a href=\"{PagingLink(urlHelper, urlHelper.Action(action, controller), page)}\" class=\"flex items-center justify-center text-sm z-10 py-2 px-3 leading-tight text-blue-web bg-blue-light border border-blue-light hover:text-blue-us\">");
                else
                    output.AppendLine($"<a href=\"{PagingLink(urlHelper, urlHelper.Action(action, controller), page)}\" class=\"flex items-center justify-center text-sm py-2 px-3 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-gray-700\">");
                output.AppendLine($"{page}");
                output.AppendLine("</a>");
                output.AppendLine("</li>");

            }

            //Last and next page
            string typeOfEnd = grid.Pager.CurrentPage < grid.Pager.TotalPages ? "a" : "span";
            //Next page
            output.AppendLine("<li>");
            output.AppendLine($"<{typeOfEnd} href=\"{PagingLink(urlHelper, urlHelper.Action(action, controller), grid.Pager.CurrentPage + 1)}\" class=\"flex items-center justify-center h-full py-1.5 px-3 leading-tight text-gray-500 bg-white border border-gray-300 {(grid.Pager.CurrentPage < grid.Pager.TotalPages ? "hover:bg-gray-100 hover:text-gray-700" : "")}\" >");
            output.AppendLine($"<svg class=\"w-5 h-5\" aria-hidden=\"true\" fill=\"currentColor\" viewbox=\"0 0 20 20\" xmlns=\"http://www.w3.org/2000/svg\">");
            output.AppendLine("<path fill-rule=\"evenodd\" d=\"M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z\" clip-rule=\"evenodd\" />");
            output.AppendLine("</svg>");
            output.AppendLine($"</{typeOfEnd}>");
            output.AppendLine("</li>");

            //Last page
            output.AppendLine("<li>");
            output.AppendLine($"<{typeOfEnd} href=\"href='{PagingLink(urlHelper, urlHelper.Action(action, controller), grid.Pager.TotalPages)}\" class=\"flex items-center justify-center h-full py-1.5 px-3 leading-tight text-gray-500 bg-white rounded-r-lg border border-gray-300 {(grid.Pager.CurrentPage < grid.Pager.TotalPages ? "hover:bg-gray-100 hover:text-gray-700" : "")}\" >");
            output.AppendLine($"<svg class=\"w-5 h-3\" aria-hidden=\"true\" fill=\"none\" viewbox=\"0 0 12 10\" xmlns=\"http://www.w3.org/2000/svg\">");
            output.AppendLine("<path stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"m7 9 4-4-4-4M1 9l4-4-4-4\" />");
            output.AppendLine("</svg>");
            output.AppendLine($"</{typeOfEnd}>");
            output.AppendLine("</li>");

            output.AppendLine("</ul>"); // ul ends here            
            output.AppendLine("</nav>");
            return new HtmlString(output.ToString());
        }

        public static IHtmlContent Pagination<T, S>(this IHtmlHelper helper, GridDTO<T, S> grid, string action = "", string controller = "")
        {
            var urlHelper = helper.GetUrlHelper();
            StringBuilder output = new StringBuilder();
            output.AppendLine("<nav>");
            output.AppendLine("<ul class='pagination'>");

            if (grid.Pager is not null && grid.Pager.CurrentPage > 1 && grid.Pager.TotalPages != 1)
            {
                output.AppendLine("<li class='page-item'>");
                output.AppendLine($"<a class='page-link' href='{PagingLink(urlHelper, urlHelper.Action(action, controller))}'>{ButtonRes.First}</a>");
                output.AppendLine("</li>");

                output.AppendLine("<li class='page-item'>");
                output.AppendLine($"<a class='page-link' href='{PagingLink(urlHelper, urlHelper.Action(action, controller), grid.Pager.CurrentPage - 1)}'>{ButtonRes.Previous}</a>");
                output.AppendLine("</li>");
            }

            if (grid.Pager is not null)
            {
                for (var page = grid.Pager.StartPage; page <= grid.Pager.EndPage; page++)
                {
                    output.AppendLine($"<li class='page-item {(page == grid.Pager.CurrentPage ? "active" : "")}'>");
                    output.AppendLine($"<a class='page-link' href='{PagingLink(urlHelper, urlHelper.Action(action, controller), page)}'>{page}</a>");
                    output.AppendLine("</li>");
                }
            }

            if (grid.Pager is not null && grid.Pager.CurrentPage < grid.Pager.TotalPages && grid.Pager.TotalPages != 1)
            {
                output.AppendLine("<li class='page-item'>");
                output.AppendLine($"<a class='page-link' href='{PagingLink(urlHelper, urlHelper.Action(action, controller), grid.Pager.CurrentPage + 1)}'>{ButtonRes.Next}</a>");
                output.AppendLine("</li>");

                output.AppendLine("<li class='page-item'>");
                output.AppendLine($"<a class='page-link' href='{PagingLink(urlHelper, urlHelper.Action(action, controller), grid.Pager.TotalPages)}'>{ButtonRes.Last}</a>");
                output.AppendLine("</li>");
            }

            output.AppendLine("</ul>"); // ul ends here            
            output.AppendLine("</nav>");
            return new HtmlString(output.ToString());
        }

        public static IHtmlContent PagingLink(IUrlHelper url, string actionLink, int? page = null)
        {
            StringBuilder output = new StringBuilder();

            actionLink = url.ActionContext.HttpContext.Request.Path;
            var requestQueryString = url.ActionContext.HttpContext.Request.Query.ToDictionary(r => r.Key, r => r.Value);

            List<KeyValuePair<string, string>> resultQueryString = new List<KeyValuePair<string, string>>();

            // Build query string
            foreach (var requestQueryStringKey in requestQueryString)
            {
                if (!String.IsNullOrEmpty(requestQueryStringKey.Key) && requestQueryStringKey.Key.ToLower() != "page")
                {
                    var values = requestQueryStringKey.Value;
                    foreach (var value in values)
                    {
                        resultQueryString.Add(new KeyValuePair<string, string>(requestQueryStringKey.Key, value));
                    }
                }
            }

            // Add default link
            output.Append(actionLink);

            if (page.HasValue)
            {
                output.Append($"?page={page.Value}");
            }

            if (resultQueryString.Count > 0)
            {
                if (page.HasValue)
                {
                    output.Append($"&");
                }
                else
                {
                    output.Append($"?");
                }

                output.Append(string.Join("&", resultQueryString
                    .OrderBy(x => x.Key)
                    .Where(x => x.Value is not null)
                    .Select(x => x.Key + "=" + x.Value).ToArray()));
            }

            return new HtmlString(output.ToString());
        }
    }
}
