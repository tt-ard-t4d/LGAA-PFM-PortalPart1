﻿using Newtonsoft.Json;
using PFMPortal.Domain.Contracts.PFM;
using PFMPortal.DTO.Municipality;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Mappings.PFM;

namespace PFMPortal.Infrastructure.Core.PFM
{
    public class PFMDropDownService
    {
        private readonly IPFMDropDownRepository _repository;
        private readonly IBudgetDataRepository _budgetDataRepository;
        private readonly IMunicipalityRepository _municipalityRepository;

        public PFMDropDownService(IPFMDropDownRepository repository, IBudgetDataRepository budgetDataRepository, IMunicipalityRepository municipalityRepository)
        {
            _repository = repository;
            _budgetDataRepository = budgetDataRepository;
            _municipalityRepository = municipalityRepository;
        }

        public List<ItemDDL> GetEntities()
        {
            return _repository.GetEntities().Select(r => new ItemDDL() { Id = r.EntityID, Value = r.EntityName }).ToList();
        }

        public List<ItemDDL> GetBudgetDataYears()
        {
            return _budgetDataRepository.GetBudgetDataYears().Select(r => new ItemDDL() { Id = r, Value = r.ToString() }).OrderBy(year => year.Value).ToList();
        }

        public List<ItemDDL> GetMunicipalitiesForUser(Guid userId)
        {
            return _repository.GetMunicipalitiesForUser(userId).Select(r => new ItemDDL() { Id = r.MunicipalityID, Value = r.MunicipalityName, Code = r.Slug }).ToList();
        }

        public List<ItemDDL> GetAllMunicipalities()
        {
            return _repository.GetAllMunicipalities().Select(r => new ItemDDL() { Id = r.MunicipalityID, Value = r.MunicipalityName, Code = r.Slug }).ToList();
        }

        public List<ItemDDL> GetRetiredMunicipalities()
        {
            return _municipalityRepository.GetRetiredMunicipalities().Select(r => new ItemDDL() { Id = r.MunicipalityID, Value = r.MunicipalityName, Code = r.Slug }).ToList();
        }

        public List<ItemDDL> GetAccountTypes()
        {
            return _repository.GetAccountTypes().Select(r => new ItemDDL() { Id = r.AccountTypeID, Value = r.AccountTypeName }).ToList();
        }

        public List<ItemDDL> CreateYearDDL(int startingYear)
        {
            var years = new List<ItemDDL>();
            var currentYear = DateTime.Now.Year;

            for (int i = currentYear+1; i >= startingYear; i--)
            {
                years.Add(new ItemDDL { Id = i, Value = i.ToString() });
            }

            return years;
        }

        public List<ItemDDL> GetValueTypes()
        {
            return new List<ItemDDL>() 
            { 
                new ItemDDL() { Id = (byte) PFMEnum.BudgetDataValueType.Planned, Value = "Planirana vrijednost" },
                new ItemDDL() { Id = (byte) PFMEnum.BudgetDataValueType.Final, Value = "Finalna vrijednost" }
            };
        }

        public List<ItemDDL> GetSlugs()
        {
            using (StreamReader r = new("wwwroot/static-data/minicipality-slugs.json"))
            {
                string json = r.ReadToEnd();
                MunicipalitySlugDTO obj = JsonConvert.DeserializeObject<MunicipalitySlugDTO>(json);
                return obj.Slugs.Select(r => new ItemDDL() { Value = r }).ToList();
            }
        }
    }
}
