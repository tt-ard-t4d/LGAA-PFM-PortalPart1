﻿namespace PFMPortal.Domain.Entities.App
{
    public class UserMunicipalityRel
    {
        public int UserAndMunicipalityID { get; set; }
        public Guid UserID { get; set; }
        public User User { get; set; }
        public int MunicipalityID { get; set; }
        public Municipality Municipality { get; set; }
        public bool Retired { get; set; }
    }
}
