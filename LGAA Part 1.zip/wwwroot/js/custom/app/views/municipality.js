﻿var app = app || {};

app.municipality = function () {

    var initGrid = function () {
        app.selectPicker.addPickers({
            search: true,
            multiple: false,
            clear: false,
            selectAll: false,
        });
        $(() => {
            getMunicipalitiesWithoutEntries();
        })
    };

    var initForm = function () {
/*        addValidation();*/
    };

    var addValidation = function () {
        app.resource.initSpecificResource('Validations', function () {
            $('form[id="EditMunicipalityForm"]').validate({
                validClass: 'bg-green-50 border border-green-500 text-green-900 text-sm rounded-lg focus:ring-green-500 focus:border-green-500 block w-full p-2.5',
                errorClass: 'mt-2 text-sm text-red-600',
                highlight: function (element, errorClass) {
                    $(element).addClass("bg-red-50 border-red-500 text-red-900 placeholder-red-700 focus:ring-red-500 focus:border-red-500");

                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass(errorClass).addClass(validClass);
                    $(element.form).find("label[for=" + element.id + "]")
                        .removeClass(errorClass);
                },
                ignore: ":not(:visible)",
                rules: {
                    'MunicipalityName':
                    {
                        required: true,
                    },
                    'EntityID':
                    {
                        required: true,
                    }
                },
                messages: {
                    'MunicipalityName':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    },
                    'EntityID':
                    {
                        'required': app.resource.getByResourceGroupAndKey('Validations', 'Required'),
                    }
                }
            });
        });
    };

    var initYearChangeListener = function () {
        $('#Year').on('change', getMunicipalitiesWithoutEntries);
    }

    var updateMunicipialities = function (data) {
        console.log(data);
        $('#MunicipalitiesMissingEntry').html(data);
    }

    var getMunicipalitiesWithoutEntries = function () {
        const year = $('#Year').val();

        $.ajax({
            url: '/Municipality/GetMunicipalitiesWithoutEntries',
            data: {
                year: year
            },
            success: function (data) {
                updateMunicipialities(data);
            },
            dataType: 'html'
        });
    };

    var addEntryCreateOnClick = function () {
        $('#CreateBudgetDataBtn').on('click', function () {
            let year = $('#Year').val();
            createBudgetDataEntry(year);
        });
    }

    var createBudgetDataEntry = function (year) {
        var endpointRoute = '/Municipality/CreateBudgetDataEntry';
        app.resource.initSpecificResources(['Buttons', 'MessageRes'], function () {
            app.modal.createConfirmationModal(app.resource.getByResourceGroupAndKey('MessageRes', 'CreateBudgetDataEntryMsg'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Yes'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Cancel'),
                function () { createEntries(endpointRoute, year); });
        });
    };

    var createEntries = function (endpointRoute, data) {
        app.utility.showLoader('body');
        $.ajax({
            method: "POST",
            url: endpointRoute,
            data: {
                year: data
            },
            dataType: "json"
        }).done(function (result) {
            app.utility.hideLoader('body');
            window.location.href = result.returnUrl;
        });
    };

    var onMunicipalityChange = function () {
        $('#MunicipalityID').on('change', function () {
            $.ajax({
                method: 'GET',
                url: '/Municipality/GetRetiredMunicipality',
                data: {
                    id: $(this).val()
                },
                dataType: "json",
                success: function (data) {
                    $('#Slug').val(data.slug);
                    $('#Entity').val(data.entityName);
                    $('#LocalGovernmentUnit').val(data.localGovernmentUnitName);
                },
                error: function () {

                }
            });
        });
    }


    var deleteMunicipality = function (id) {
        var endpointRoute = '/Municipality/Delete';
        app.resource.initSpecificResources(['Buttons', 'MessageRes'], function () {
            app.modal.createConfirmationModal(app.resource.getByResourceGroupAndKey('MessageRes', 'DeleteMunicipalityMsg'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Yes'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Cancel'),
                function () { sendDeleteRequest(endpointRoute, id); });
        });
    };

    var sendDeleteRequest = function (endpointRoute, data) {
        app.utility.showLoader('body');
        $.ajax({
            method: "POST",
            url: endpointRoute,
            data: {
                id: data
            },
            dataType: "json"
        }).done(function (result) {
            app.utility.hideLoader('body');
            window.location.href = result.returnUrl;
        });
    };

    return {
        initForm: initForm,
        initGrid: initGrid,
        getMunicipalitiesWithoutEntries: getMunicipalitiesWithoutEntries,
        addEntryCreateOnClick: addEntryCreateOnClick,
        initYearChangeListener: initYearChangeListener,
        onMunicipalityChange: onMunicipalityChange,
        deleteMunicipality: deleteMunicipality,
    }
}();