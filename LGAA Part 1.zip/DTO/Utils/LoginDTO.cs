﻿namespace PFMPortal.DTO.Utils
{
    public class LoginDTO
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool RememberMe { get; set; } = false;
        public string ReturnUrl { get; set; } = string.Empty;
    }
}
