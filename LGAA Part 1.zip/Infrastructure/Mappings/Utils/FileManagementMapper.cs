﻿using Infrastructure.Helpers;
using PFMPortal.Domain.Entities;
using PFMPortal.Domain.Entities.Utils;
using PFMPortal.DTO.Admin;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Utility;

namespace PFMPortal.Infrastructure.Mappings.Utils
{
    public class FileManagementMapper
    {
        public FileGridDTO MapGrid(FormFiles entity, int totalNumberOfRows = 0)
        {
            if (entity == null)
            {
                return new FileGridDTO();
            }

            return new FileGridDTO()
            {
                FormFileID = entity.FormFileID,
                FileGUID = entity.FileGuidID,
                FileName = entity.Name,
                FileExtension = entity.Extension,
                FileSize = (entity.Size ?? 0m) / 1024m,
                Total = totalNumberOfRows,
                UserID = entity.SysCreatedByUserID
            };
        }
    }
}
