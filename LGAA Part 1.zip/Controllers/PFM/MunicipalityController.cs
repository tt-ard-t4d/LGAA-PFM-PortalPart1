﻿using Authorization;
using Microsoft.AspNetCore.Mvc;
using PFMPortal.DTO.Municipality;
using PFMPortal.Infrastructure.Core.PFM;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Infrastructure.Resources;

namespace PFMPortal.Controllers.PFM
{
    [AuthorizeUserGroups(ActionManagementEnum.UserGroups.SystemAdministrator)]
    public class MunicipalityController : Controller
    {
        private readonly MunicipalityService _service;
        private readonly BudgetDataService _budgetDataService;
        private readonly PFMDropDownService _dropdownService;

        public MunicipalityController(MunicipalityService service, PFMDropDownService dropdownService, BudgetDataService budgetDataService)
        {
            _service = service;
            _dropdownService = dropdownService;
            _budgetDataService = budgetDataService;
        }

        public IActionResult Index(SearchMunicipalityDTO args)
        {
            CreateFilterDDL(ref args);

            return View(_service.GetMunicipalityGrid(args));
        }

        public IActionResult Create()
        {
            var model = new MunicipalityEditDTO();
            CreateAddEditDDL(ref model);

            return View("Edit", model);
        }

        //public IActionResult Edit(int id)
        //{
        //    var municipality = _service.GetMunicipality(id);

        //    if (municipality.MunicipalityID > 0)
        //    {
        //        CreateAddEditDDL(ref municipality);
        //        return View("Edit", municipality);
        //    }

        //    TempData["error-message"] = MessageRes.Error;
        //    return RedirectToAction("Index", "Municipality");
        //}

        [HttpPost]
        public IActionResult Save(MunicipalityEditDTO model)
        {
            if (ModelState.IsValid)
            {
                var res = _service.Save(model, User.Identity.GetLoggedUserId());

                if (!res.IsError)
                {
                    TempData["success-message"] = MessageRes.Success;
                    return RedirectToAction("Index", "Municipality");
                }

                TempData["error-message"] = res.ErrorMessage;
                CreateAddEditDDL(ref model);
                return View("Edit", model);
            }

            TempData["error-message"] = MessageRes.InvalidModel;
            CreateAddEditDDL(ref model);
            return View("Edit", model);
        }

        [HttpPost]
        public JsonResult Delete(int id)
        {
            if (id > 0)
            {
                var res = _service.DeleteMunicipality(id);

                if (res.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                    return new JsonResult(new RetValue() { IsError = true, ReturnUrl = Url.Action("Index", "Municipality") });
                }

                TempData["success-message"] = MessageRes.Success;
                return new JsonResult(new RetValue() { IsError = true, ReturnUrl = Url.Action("Index", "Municipality") });
            }

            TempData["error-message"] = MessageRes.Error;
            return new JsonResult(new RetValue() { IsError = true, ReturnUrl = Url.Action("Index", "Municipality") });
        }

        public IActionResult IndexBudgetDataEntry()
        {
            var args = new BudgetDataEntryDTO();

            CreateBudgetDataEntryDDL(ref args);

            return View("IndexBudgetDataEntry", args);
        }

        [HttpPost]
        public JsonResult CreateBudgetDataEntry(int year)
        {
            Guid loggedUserId = User.GetLoggedUserId();

            if (year > 0)
            {
                var res = _budgetDataService.CreateBudgetDataEntry(year, loggedUserId);
                if (res.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                }
                else
                {
                    TempData["success-message"] = MessageRes.Success;
                }
            }

            return Json(new RetValue() { ReturnUrl = Url.Action("Index", "Municipality") ?? string.Empty } );
        }

        [HttpGet]
        public JsonResult GetRetiredMunicipality(int id)
        {
            return Json(_service.GetRetiredMunicipality(id));
        }

        public IActionResult GetMunicipalitiesWithoutEntries(int year)
        {
            var data = _service.GetMunicipalitiesWithoutEntries(year);

            return PartialView("_MunicipalitiesWithoutEntries", data);
        }

        public List<int> GetYearsWithData(int municipalityId)
        {
            return _service.GetYearsWithData(municipalityId);
        }

        private void CreateAddEditDDL(ref MunicipalityEditDTO args)
        {
            args.Municipalities = _dropdownService.GetRetiredMunicipalities();
        }
        
        private void CreateFilterDDL(ref SearchMunicipalityDTO args)
        {
            args.Entities = _dropdownService.GetEntities();
        }

        private void CreateBudgetDataEntryDDL(ref BudgetDataEntryDTO args)
        {
            args.Years = _dropdownService.CreateYearDDL(startingYear: 2023);
        }
    }
}
