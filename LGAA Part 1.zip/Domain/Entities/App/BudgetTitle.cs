﻿namespace PFMPortal.Domain.Entities.App
{
    public class BudgetTitle : SysEntity
    {
        public Guid BudgetTitleGuid { get; set; }
        public int BudgetTitleDisplayId { get; set; }
        public int Year { get; set; }
        public int MunicipalityId { get; set; }
        public string Title { get; set; }
    }
}
