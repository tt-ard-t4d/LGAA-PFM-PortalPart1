﻿using DocumentFormat.OpenXml.InkML;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.CodeAnalysis.Elfie.Serialization;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Org.BouncyCastle.Asn1.X509.Qualified;
using PFMPortal.DTO.Utils;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace PFMPortal.Infrastructure.Helpers
{
    public static class DDLHelper
    {
        //Works only with List<int>
        //public static bool IsValidList<T>(this T model, string targetPropertyName, List<ItemDDL> ddlValues) where T : class
        //{
        //    if (string.IsNullOrEmpty(targetPropertyName)) return false;

        //    var targetProperty = model.GetType().GetProperty(targetPropertyName);

        //    if (targetProperty == null)
        //    {
        //        throw new ArgumentException("Invalid property name");
        //    }

        //    var type = targetProperty.GetType();

        //    if (type != typeof(List<int>) && type != typeof(List<int?>) && type != typeof(List<short>) && type != typeof(List<short?>))
        //    {
        //        throw new ArgumentException("Invalid property type");
        //    }

        //    var propertyValues = targetProperty.GetValue(model);

        //    //Never
        //    if (propertyValues == null) return true;

        //    //Get attempted list of IDs
        //    var attemptedValues = (List<int>)propertyValues;

        //    //Zero IDs selected
        //    if (attemptedValues.Count() == 0)
        //    {
        //        return true;
        //    }

        //    //Map ddl values to list of ints
        //    var allowedValues = ddlValues.Select(r => r.Id).ToList();
        //    var outlierValues = attemptedValues.Where(r => !allowedValues.Contains(r));

        //    return outlierValues.Count() == 0;
        //}

        public static bool IsValidList(this List<int> attemptedValues, List<ItemDDL> allowedValues)
        {
            return CheckIsValid(attemptedValues, allowedValues);
        }

        public static bool IsValidList(this List<short> attemptedValues, List<ItemDDL> allowedValues)
        {
            return CheckIsValid(attemptedValues.Select(r => (int)r).ToList(), allowedValues);
        }

        private static bool CheckIsValid(List<int> attemptedValues, List<ItemDDL> allowedValues)
        {
            var allowedValueIds = allowedValues.Select(r => r.Id).ToList();

            var outliers = attemptedValues.Where(r => !allowedValueIds.Contains(r));

            return outliers.Count() == 0;
        }
    }
}
