﻿namespace PFMPortal.DTO.Utils
{
    public class GridArgsDTO
    {
        public int Page { get; set; } = 1;
        public string SortBy { get; set; }
    }
}
