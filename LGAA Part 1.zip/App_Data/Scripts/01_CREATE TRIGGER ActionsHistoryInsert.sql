USE [PFMPortalDB]
GO

/****** Object:  Trigger [dbo].[ActionsHistoryInsert]    Script Date: 5/19/2023 10:59:54 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[ActionsHistoryInsert] ON [dbo].[Actions]

FOR INSERT
AS
DECLARE @Now AS DateTime = GetDate()

SET NOCOUNT ON

IF	 
	UPDATE([ActionID])	
      OR  UPDATE([ActionName])
      OR UPDATE([ActionEnumerationName])
      OR UPDATE([Description])
      OR UPDATE([Retired])
BEGIN 
insert into ActionsHistory
    select *, 2, 'insert-inserted', @Now
      from inserted
END


GO

ALTER TABLE [dbo].[Actions] ENABLE TRIGGER [ActionsHistoryInsert]
GO

EXEC sp_settriggerorder @triggername=N'[dbo].[ActionsHistoryInsert]', @order=N'Last', @stmttype=N'INSERT'
GO


