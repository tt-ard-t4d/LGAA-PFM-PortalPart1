﻿using PFMPortal.DTO.Utils;

namespace PFMPortal.DTO.Admin
{
    public class SearchUserDTO : GridArgsDTO
    {
        public string SearchTerm { get; set; }
        public List<ItemDDL> UserGroups { get; set; }
        public int UserGroupID { get; set; }
        public List<ItemDDL> UserActions { get; set; }
        public int ActionID { get; set; }
        public DateTime? ContractDate { get; set; }
    }
}
