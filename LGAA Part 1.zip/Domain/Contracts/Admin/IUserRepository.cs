﻿using Infrastructure.Helpers;
using Microsoft.AspNetCore.DataProtection;
using Org.BouncyCastle.Asn1.Cms;
using PFMPortal.Domain.Entities;
using PFMPortal.DTO.Admin;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Infrastructure.Models.StoredProcedures;

namespace PFMPortal.Domain.Contracts.Admin
{
    public interface IUserRepository
    {
        public User? GetUserById(Guid userId);
        public User? GetUserByEmailCode(string emailCode);
        public User? GetUserByUserNameEnc(string userNameEnc);
        public User? GetUserByEmailEnc(string emailEnc);
        public UserGroup? GetUserGroupById(int userGroupId);
        public RetValue Save(User entity, UserDTO vm, GlobalEnum.CrudOperation operation);
        public RetValue ChangePassword(User entity, string password);
        public RetValue Delete(Guid userId, Guid loggedUserId);
        public IQueryable<User> GetUserEmails(Guid impersonatedUserId);
        public (IQueryable<User>, int) GetUserGrid(SearchUserDTO args);
        public IQueryable<GetUserActions> GetUserActions(Guid userId);
        public IQueryable<UserActionRel> GetUserActionRels();
        public IQueryable<UserGroupUserRel> GetUserGroupUserRels();
        User? GetDirectoryUserByEmail(string? email);
    }
}
