﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PFMPortal.Migrations
{
    /// <inheritdoc />
    public partial class NewMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 1,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 2,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 3,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 4,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 5,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 6,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 7,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 8,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 9,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 10,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 11,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 12,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 13,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 14,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 15,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 16,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 17,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 18,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 19,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 20,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 21,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 22,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 23,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 24,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 25,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 26,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 27,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 28,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 29,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 30,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 31,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 32,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "ActionID",
                keyValue: 1,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "ActionID",
                keyValue: 2,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "ActionID",
                keyValue: 3,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "ActionID",
                keyValue: 4,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "ActionID",
                keyValue: 5,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 1,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 2,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 3,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 4,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 5,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 6,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 1,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 2,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 3,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 4,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 5,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 6,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 7,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 8,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 9,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 10,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 11,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 12,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 13,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 14,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 15,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 16,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 17,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 18,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 19,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 20,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 21,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 22,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 23,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 24,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 25,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 26,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 27,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 28,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 29,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 30,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 31,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 32,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 33,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 34,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 35,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 36,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 37,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 38,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 39,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 40,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 41,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 42,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 43,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 44,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 45,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 46,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 47,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 48,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 49,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 50,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 51,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 52,
                columns: new[] { "BudgetPositionName", "SysCreatedDate" },
                values: new object[] { "Izgradnja putne infrastrukture", new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 53,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 54,
                columns: new[] { "BudgetPositionName", "SysCreatedDate" },
                values: new object[] { "Izgradnja objekata od važnosti za rad JLU", new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 55,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 56,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 57,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 58,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 59,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 60,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 61,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 62,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 63,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 64,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 65,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 66,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 67,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 68,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 69,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 70,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 71,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 72,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 73,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 74,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 75,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 76,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 77,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 78,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 79,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 80,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 81,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 82,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 83,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 84,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 85,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 86,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 87,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 88,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 89,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 90,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 91,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 92,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 93,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 94,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 95,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 96,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 97,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 98,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 99,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 100,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 101,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 102,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 103,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 104,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 105,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 106,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 107,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 108,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 109,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 110,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 111,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 112,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 113,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 114,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 115,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 116,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 117,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 118,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 119,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 120,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 121,
                columns: new[] { "BudgetPositionName", "SysCreatedDate" },
                values: new object[] { "Izgradnja i održavanje saobraćajnih objekata", new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified) });

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 122,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 123,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 124,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 125,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 126,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 127,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 128,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 129,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 130,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.InsertData(
                schema: "pfm",
                table: "BudgetPositions",
                columns: new[] { "BudgetPositionID", "AccountCategoryID", "Archived", "BudgetPositionName", "Retired", "SysCreatedByUserID", "SysCreatedDate", "SysLastModifiedByUserID", "SysLastModifiedDate" },
                values: new object[,]
                {
                    { 132, 11, false, "Ostalo", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, null },
                    { 133, 13, false, "Ostalo", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, null }
                });

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "EmailNotifications",
                keyColumn: "EmailNotificationID",
                keyValue: 1,
                column: "SysDateCreated",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "EmailNotifications",
                keyColumn: "EmailNotificationID",
                keyValue: 2,
                column: "SysDateCreated",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 1,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 2,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 3,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 4,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 5,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 6,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 7,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 8,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 9,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 10,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 11,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 12,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 13,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 14,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 15,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 16,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 17,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 18,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 19,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 20,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 21,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 22,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 23,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 24,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 25,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 26,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 27,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 28,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 29,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 30,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 31,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 32,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 33,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 34,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 35,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 36,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 37,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 38,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 39,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 40,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 41,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 42,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 43,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 44,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 45,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 46,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 47,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 48,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 49,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 50,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 51,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 52,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 53,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 54,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 55,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 56,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 57,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 58,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 59,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 60,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 61,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 62,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 63,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 64,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 65,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 66,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 67,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 68,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 69,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 70,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 71,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 72,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 73,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 74,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 75,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 76,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 77,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 78,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 79,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 80,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 81,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 82,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 83,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 84,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 85,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 86,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 87,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 88,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 89,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 90,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 91,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 92,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 93,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 94,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 95,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 96,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 97,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 98,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 99,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 100,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 101,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 102,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 103,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 104,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 105,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 106,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 107,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 108,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 109,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 110,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 111,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 112,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 113,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 114,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 115,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 116,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 117,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 118,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 119,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 120,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 121,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 122,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 123,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 124,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 125,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 126,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 127,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 128,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 129,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 130,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 131,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 132,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 133,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 134,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 135,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 136,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 137,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 138,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 139,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 140,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 141,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 142,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "UserGroupID",
                keyValue: (short)1,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "UserGroupID",
                keyValue: (short)2,
                column: "SysCreatedDate",
                value: new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Users",
                keyColumn: "UserID",
                keyValue: new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                columns: new[] { "EmailCode", "SysCreatedDate", "ValidFrom", "ValidTo" },
                values: new object[] { new Guid("00000000-0000-0000-0000-000000000000"), new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2024, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2297, 10, 16, 0, 0, 0, 0, DateTimeKind.Unspecified) });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 132);

            migrationBuilder.DeleteData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 133);

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 1,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 2,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 3,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 4,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 5,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 6,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 7,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 8,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 9,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 10,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 11,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 12,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 13,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 14,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 15,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 16,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 17,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 18,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 19,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 20,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 21,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 22,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 23,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 24,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 25,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 26,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 27,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 28,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 29,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 30,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 31,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "AccountCategories",
                keyColumn: "AccountCategoryID",
                keyValue: 32,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "ActionID",
                keyValue: 1,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3402));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "ActionID",
                keyValue: 2,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3404));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "ActionID",
                keyValue: 3,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3407));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "ActionID",
                keyValue: 4,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3409));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Actions",
                keyColumn: "ActionID",
                keyValue: 5,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3411));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 1,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3533));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 2,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3536));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 3,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3539));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 4,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3541));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 5,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3543));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                keyColumn: "AuditLogEnumerationID",
                keyValue: 6,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3545));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 1,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 2,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 3,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 4,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 5,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 6,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 7,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 8,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 9,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 10,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 11,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 12,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 13,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 14,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 15,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 16,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 17,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 18,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 19,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 20,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 21,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 22,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 23,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 24,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 25,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 26,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 27,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 28,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 29,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 30,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 31,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 32,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 33,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 34,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 35,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 36,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 37,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 38,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 39,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 40,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 41,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 42,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 43,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 44,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 45,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 46,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 47,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 48,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 49,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 50,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 51,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 52,
                columns: new[] { "BudgetPositionName", "SysCreatedDate" },
                values: new object[] { "Igradnja putne infrastrukture", new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560) });

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 53,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 54,
                columns: new[] { "BudgetPositionName", "SysCreatedDate" },
                values: new object[] { "Igradnja objekata od važnosti za rad JLU", new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560) });

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 55,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 56,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 57,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 58,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 59,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 60,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 61,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 62,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 63,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 64,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 65,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 66,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 67,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 68,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 69,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 70,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 71,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 72,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 73,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 74,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 75,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 76,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 77,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 78,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 79,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 80,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 81,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 82,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 83,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 84,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 85,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 86,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 87,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 88,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 89,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 90,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 91,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 92,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 93,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 94,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 95,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 96,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 97,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 98,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 99,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 100,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 101,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 102,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 103,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 104,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 105,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 106,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 107,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 108,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 109,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 110,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 111,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 112,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 113,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 114,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 115,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 116,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 117,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 118,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 119,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 120,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 121,
                columns: new[] { "BudgetPositionName", "SysCreatedDate" },
                values: new object[] { "Igradnja i održavanje saobraćajnih objekata", new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560) });

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 122,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 123,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 124,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 125,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 126,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 127,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 128,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 129,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "BudgetPositions",
                keyColumn: "BudgetPositionID",
                keyValue: 130,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "EmailNotifications",
                keyColumn: "EmailNotificationID",
                keyValue: 1,
                column: "SysDateCreated",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3521));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "EmailNotifications",
                keyColumn: "EmailNotificationID",
                keyValue: 2,
                column: "SysDateCreated",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3523));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 1,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3907));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 2,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3910));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 3,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3913));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 4,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3915));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 5,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3917));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 6,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3920));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 7,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3922));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 8,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3924));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 9,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3926));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 10,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3929));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 11,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3931));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 12,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3933));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 13,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3935));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 14,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3937));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 15,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3940));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 16,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3942));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 17,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3944));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 18,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3946));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 19,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3948));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 20,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3951));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 21,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3953));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 22,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3956));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 23,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3959));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 24,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3961));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 25,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3963));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 26,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3965));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 27,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3989));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 28,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3992));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 29,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3994));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 30,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3996));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 31,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3998));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 32,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4001));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 33,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4004));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 34,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4008));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 35,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4010));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 36,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4012));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 37,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4015));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 38,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4018));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 39,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4022));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 40,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4024));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 41,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4028));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 42,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4030));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 43,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4032));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 44,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4034));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 45,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4037));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 46,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4040));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 47,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4044));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 48,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4046));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 49,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4048));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 50,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4050));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 51,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4053));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 52,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4055));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 53,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4057));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 54,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4059));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 55,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4061));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 56,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4063));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 57,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4066));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 58,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4069));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 59,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4071));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 60,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4073));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 61,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4075));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 62,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4077));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 63,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4080));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 64,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4082));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 65,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4084));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 66,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4086));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 67,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4088));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 68,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4090));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 69,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4092));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 70,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4096));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 71,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4098));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 72,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4100));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 73,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4102));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 74,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4104));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 75,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4106));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 76,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4109));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 77,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4111));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 78,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4113));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 79,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4115));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 80,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4117));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 81,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4142));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 82,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4145));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 83,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4148));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 84,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4150));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 85,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4153));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 86,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4155));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 87,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4157));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 88,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4159));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 89,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4161));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 90,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4164));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 91,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4166));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 92,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4168));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 93,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4170));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 94,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4173));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 95,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4175));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 96,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4178));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 97,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4180));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 98,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4182));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 99,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4184));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 100,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4186));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 101,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4188));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 102,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4190));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 103,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4192));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 104,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4195));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 105,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4197));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 106,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4200));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 107,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4202));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 108,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4205));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 109,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4207));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 110,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4209));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 111,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4211));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 112,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4213));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 113,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4215));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 114,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4218));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 115,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4220));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 116,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4222));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 117,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4224));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 118,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4227));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 119,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4229));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 120,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4232));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 121,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4234));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 122,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4236));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 123,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4238));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 124,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4240));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 125,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4242));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 126,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4245));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 127,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4247));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 128,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4249));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 129,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4251));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 130,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4254));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 131,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4256));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 132,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4258));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 133,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4261));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 134,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4263));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 135,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4288));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 136,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4290));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 137,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4293));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 138,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4295));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 139,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4297));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 140,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4299));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 141,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4302));

            migrationBuilder.UpdateData(
                schema: "pfm",
                table: "Municipalities",
                keyColumn: "MunicipalityID",
                keyValue: 142,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4304));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "UserGroupID",
                keyValue: (short)1,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3196));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "UserGroups",
                keyColumn: "UserGroupID",
                keyValue: (short)2,
                column: "SysCreatedDate",
                value: new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3261));

            migrationBuilder.UpdateData(
                schema: "dbo",
                table: "Users",
                keyColumn: "UserID",
                keyValue: new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                columns: new[] { "EmailCode", "SysCreatedDate", "ValidFrom", "ValidTo" },
                values: new object[] { new Guid("208e1ebf-2468-4302-b177-0b25e73ed482"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3492), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3494), new DateTime(2297, 7, 26, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3495) });
        }
    }
}
