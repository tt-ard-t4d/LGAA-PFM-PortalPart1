﻿
using Domain.Entities.Utils;
using Microsoft.EntityFrameworkCore;
using PFMPortal.Domain.Entities;
using PFMPortal.Domain.Entities.App;
using PFMPortal.Domain.Entities.Utils;
using PFMPortal.Infrastructure.Data;
using PFMPortal.Infrastructure.Models.StoredProcedures;
using System.Reflection;


namespace Infrastructure.Data
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions options) : base(options)
        {
            this.ChangeTracker.LazyLoadingEnabled = false;
        }

        #region <!-- Utils --> 

        public DbSet<EmailNotification> EmailNotifications { get; set; }
        public DbSet<AuditLog> AuditLogs { get; set; }
        public DbSet<AuditLogEnumeration> AuditLogEnumerations { get; set; }
        public DbSet<FormFiles> FormFiles { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserGroup> UserGroups { get; set; }
        public DbSet<PFMPortal.Domain.Entities.Action> Actions { get; set; }
        public DbSet<ActionHistory> ActionsHistory { get; set; }
        public DbSet<UserGroupUserRel> UserGroupUsers { get; set; }
        public DbSet<UserGroupActionRel> UserGroupActions { get; set; }
        public DbSet<UserActionRel> UserActions { get; set; }

        #endregion

        public DbSet<AccountCategory> AccountCategories { get; set; }
        public DbSet<AccountType> AccountTypes { get; set; }
        public DbSet<BudgetData> BudgetData { get; set; }
        public DbSet<BudgetPosition> BudgetPositions { get; set; }
        public DbSet<Entity> Entities { get; set; }
        public DbSet<Municipality> Municipalities { get; set; }
        public DbSet<UserMunicipalityRel> UserMunicipalities { get; set; }
        public DbSet<LocalGovernmentUnit> LocalGovernmentUnits { get; set; }
        public DbSet<AccountCategoryData> AccountCategoryData { get; set; }
        public DbSet<BudgetTitle> BudgetTitles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region <!--- Configure stored procedure return models --->

            modelBuilder.Entity<GetUserActions>().HasNoKey().ToView(null);

            #endregion

            #region <!--- Configure Primary Keys --->

            modelBuilder.Entity<PFMPortal.Domain.Entities.Action>(r =>
            {
                r.ToTable("Actions", "dbo", r =>
                {
                    r.HasTrigger("ActionsHistoryInsert");
                    r.HasTrigger("ActionsHistoryUpdate");
                });

                r.HasKey(r => r.ActionID);
                r.HasIndex(r => r.ActionName).IsUnique();
                r.HasIndex(r => r.ActionEnumerationName).IsUnique();
                r.Property(r => r.ActionID).ValueGeneratedOnAdd();
            });


            modelBuilder.Entity<User>(r =>
            {
                r.ToTable("Users", "dbo");
                r.HasKey(r => r.UserID);
                r.Property(r => r.UserID).HasDefaultValueSql("NEWID()");
                r.Property(r => r.EmailCode).HasDefaultValueSql("NEWID()");
            });

            modelBuilder.Entity<UserActionRel>(r =>
            {
                r.ToTable("UserActionRel", "dbo");
                r.HasKey(r => r.UserAndActionID);
                r.Property(r => r.UserAndActionID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UserGroup>(r =>
            {
                r.ToTable("UserGroups", "dbo");
                r.HasKey(r => r.UserGroupID);
                r.Property(r => r.UserGroupID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UserGroupActionRel>(r =>
            {
                r.ToTable("UserGroupActionRel", "dbo");
                r.HasKey(r => r.UserGroupAndActionID);
                r.Property(r => r.UserGroupAndActionID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UserGroupUserRel>(r =>
            {
                r.ToTable("UserGroupUserRel", "dbo");
                r.HasKey(r => r.UserAndGroupID);
                r.Property(r => r.UserAndGroupID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<AuditLog>(r =>
            {
                r.ToTable("AuditLogs", "dbo");
                r.HasKey(r => r.AuditLogID);
                r.Property(r => r.AuditLogID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<AuditLogEnumeration>(r =>
            {
                r.ToTable("AuditLogEnumerations", "dbo");
                r.HasKey(r => r.AuditLogEnumerationID);
                r.Property(r => r.AuditLogEnumerationID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<EmailNotification>(r =>
            {
                r.ToTable("EmailNotifications", "dbo");
                r.HasKey(r => r.EmailNotificationID);
                r.Property(r => r.EmailNotificationID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<FormFiles>(r =>
            {
                r.ToTable("FormFiles", "dbo");
                r.HasKey(r => r.FormFileID);
                r.Property(r => r.FormFileID).ValueGeneratedOnAdd();
                r.Property(r => r.Name).HasMaxLength(250);
                r.Property(r => r.Extension).HasMaxLength(50);
                r.Property(r => r.Title).HasMaxLength(1500);
            });

            modelBuilder.Entity<AccountCategory>(r =>
            {
                r.ToTable("AccountCategories", "pfm");
                r.HasKey(r => r.AccountCategoryID);
            });

            modelBuilder.Entity<AccountType>(r =>
            {
                r.ToTable("AccountTypes", "pfm");
                r.HasKey(r => r.AccountTypeID);
            });

            modelBuilder.Entity<BudgetData>(r =>
            {
                r.ToTable("BudgetData", "pfm");
                r.HasKey(r => r.BudgetDataID);
                r.Property(r => r.BudgetDataID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<BudgetPosition>(r =>
            {
                r.ToTable("BudgetPositions", "pfm");
                r.HasKey(r => r.BudgetPositionID);
                r.Property(r => r.BudgetPositionID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<Entity>(r =>
            {
                r.ToTable("Entities", "pfm");
                r.HasKey(r => r.EntityID);
            });

            modelBuilder.Entity<Municipality>(r =>
            {
                r.ToTable("Municipalities", "pfm");
                r.HasKey(r => r.MunicipalityID);
                r.HasIndex(r => r.Slug).IsUnique();
                r.Property(r => r.MunicipalityID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<UserMunicipalityRel>(r =>
            {
                r.ToTable("UserMunicipalityRel", "pfm");
                r.HasKey(r => r.UserAndMunicipalityID);
                r.Property(r => r.UserAndMunicipalityID).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<LocalGovernmentUnit>(r =>
            {
                r.ToTable("LocalGovernmentUnits", "pfm");
                r.HasKey(r => r.LocalGovernmentUnitID);
            });

            modelBuilder.Entity<AccountCategoryData>(r =>
            {
                r.ToTable("AccountCategoryData", "pfm");
                r.HasKey(r => r.AccountCategoryDataID);
                r.Property(r => r.AccountCategoryDataID).ValueGeneratedOnAdd();
            });


            modelBuilder.Entity<BudgetTitle>(r =>
            {
                r.ToTable("BudgetTitles", "pfm");
                r.HasKey(r => r.BudgetTitleGuid);
                r.Property(r => r.BudgetTitleGuid).ValueGeneratedOnAdd();
                r.HasIndex(r => r.BudgetTitleDisplayId).IsUnique();
                r.Property(r => r.BudgetTitleDisplayId).ValueGeneratedOnAdd();
            });

            #endregion

            #region <!--- Configure many-to-many relations --->

            //Adding many-to-many relation to UserRoleUserRel
            modelBuilder.Entity<UserGroupUserRel>()
                .HasOne(ur => ur.UserGroup)
                .WithMany(r => r.UserGroupUsers)
                .HasForeignKey(ur => ur.UserGroupID);
            modelBuilder.Entity<UserGroupUserRel>()
                .HasOne(ur => ur.User)
                .WithMany(r => r.UserGroupUsers)
                .HasForeignKey(ur => ur.UserID);

            //Adding many-to-many relation to UserGroupActionRel
            modelBuilder.Entity<UserGroupActionRel>()
                .HasOne(ur => ur.UserGroup)
                .WithMany(r => r.UserGroupActions)
                .HasForeignKey(ur => ur.UserGroupID);
            modelBuilder.Entity<UserGroupActionRel>()
                .HasOne(ur => ur.Action)
                .WithMany(r => r.UserGroupActions)
                .HasForeignKey(ur => ur.ActionID);

            //Adding many-to-many relation to UserActionRel
            modelBuilder.Entity<UserActionRel>()
                .HasOne(ur => ur.User)
                .WithMany(r => r.UserActions)
                .HasForeignKey(ur => ur.UserID);
            modelBuilder.Entity<UserActionRel>()
                .HasOne(ur => ur.Action)
                .WithMany(r => r.UserActions)
                .HasForeignKey(ur => ur.ActionID);

            //Adding many-to-many relation to UserMunicipalityRel
            modelBuilder.Entity<UserMunicipalityRel>()
                .HasOne(r => r.User)
                .WithMany(r => r.UserMunicipalities)
                .HasForeignKey(r => r.UserID);
            modelBuilder.Entity<UserMunicipalityRel>()
                .HasOne(r => r.Municipality)
                .WithMany(r => r.UserMunicipalities)
                .HasForeignKey(r => r.MunicipalityID);

            #endregion

            #region <!--- Configure one-to-many relations --->

            modelBuilder.Entity<AccountCategory>()
                .HasMany(r => r.BudgetPositions)
                .WithOne(r => r.AccountCategory)
                .HasForeignKey(r => r.AccountCategoryID);

            modelBuilder.Entity<AccountType>()
                .HasMany(r => r.AccountCategories)
                .WithOne(r => r.AccountType)
                .HasForeignKey(r => r.AccountTypeID);

            modelBuilder.Entity<Entity>()
                .HasMany(r => r.Municipalities)
                .WithOne(r => r.Entity)
                .HasForeignKey(r => r.EntityID);

            modelBuilder.Entity<Municipality>()
                .HasMany(r => r.BudgetData)
                .WithOne(r => r.Municipality)
                .HasForeignKey(r => r.MunicipalityID);

            modelBuilder.Entity<BudgetPosition>()
                .HasMany(r => r.BudgetData)
                .WithOne(r => r.BudgetPosition)
                .HasForeignKey(r => r.BudgetPositionID);

            modelBuilder.Entity<LocalGovernmentUnit>()
                .HasMany(r => r.Municipalities)
                .WithOne(r => r.LocalGovernmentUnit)
                .HasForeignKey(r => r.LocalGovernmentUnitID);

            modelBuilder.Entity<AccountCategory>()
                .HasMany(r => r.AccountCategoryData)
                .WithOne(r => r.AccountCategory)
                .HasForeignKey(r => r.AccountCategoryID);

            modelBuilder.Entity<Municipality>()
                .HasMany(r => r.AccountCategoryData)
                .WithOne(r => r.Municipality)
                .HasForeignKey(r => r.MunicipalityID);

            #endregion

            #region < !--- Seed Audit Log Enumeration ---->



            #endregion


            Assembly assemblyWithConfigurations = GetType().Assembly;
            modelBuilder.ApplyConfigurationsFromAssembly(assemblyWithConfigurations);


            //Removing cascade delete
            foreach (var relationship in modelBuilder.Model.GetEntityTypes().SelectMany(e => e.GetForeignKeys()))
            {
                relationship.DeleteBehavior = DeleteBehavior.Restrict;
            }

            ConfigureHistoryTables(modelBuilder);

            modelBuilder.ConfigureDefaultFields();
            modelBuilder.Seed();
            modelBuilder.SeedPFMData();

            base.OnModelCreating(modelBuilder);
        }

        private void ConfigureHistoryTables(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ActionHistory>(r =>
            {
                r.HasKey(r => r.HistoryID);
                r.Property(r => r.HistoryID).ValueGeneratedOnAdd();
                r.ToTable("ActionsHistory", "dbo");
            });
        }
    }
}
