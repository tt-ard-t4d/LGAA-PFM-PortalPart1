﻿using ClosedXML.Excel;
using PFMPortal.Domain.Contracts.PFM;
using PFMPortal.DTO.BudgetData;
using PFMPortal.Infrastructure.Mappings.PFM;
using PFMPortal.Infrastructure.Resources;

namespace PFMPortal.Infrastructure.Core.PFM
{
    public class BudgetDataReportService
    {
        private readonly IBudgetDataRepository _repository;

        public BudgetDataReportService(IBudgetDataRepository repository)
        {
            _repository = repository;
        }

        private List<BudgetDataReportDTO> GetDataForExcelExport(int municipalityId, int year)
        {
            var args = new SearchBudgetDataDTO()
            {
                MunicipalityID = municipalityId,
                Year = year
            };

            var data = _repository.GetBudgetDataGrid(args);

            var map = new BudgetDataReportMapper();

            return data.Select(r => map.Map(r)).ToList();
        }

        private IEnumerable<IGrouping<string, BudgetDataReportDTO>> GroupData(int municipalityId, int year)
        {
            var data = GetDataForExcelExport(municipalityId, year);

            return data.GroupBy(r => r.AccountCategoryName);
        }

        public Tuple<MemoryStream, string> ExportToExcel(int municipalityId, int year, string reportName)
        {
            var data = GroupData(municipalityId, year);
            int startRow = 1;

            using (XLWorkbook wb = new XLWorkbook())
            {
                var ws = wb.Worksheets.Add(ReportingRes.DefaultSheetName);

                ws.Cell(startRow, 1).Value = BudgetDataRes.BudgetPositionName;
                ws.Cell(startRow, 1).Style.Font.Bold = true;
                ws.Cell(startRow, 2).Value = BudgetDataRes.PlannedValueBAM;
                ws.Cell(startRow, 2).Style.Font.Bold = true;
                ws.Cell(startRow, 3).Value = BudgetDataRes.FinalValueBAM;
                ws.Cell(startRow, 3).Style.Font.Bold = true;
                ws.Cell(startRow, 4).Value = BudgetDataRes.Comment;
                ws.Cell(startRow, 4).Style.Font.Bold = true;
                ws.Range(ws.Cell(startRow, 1), ws.Cell(startRow, 4)).Style.Border.SetOutsideBorder(XLBorderStyleValues.Thin);
                ws.Range(ws.Cell(startRow, 1), ws.Cell(startRow, 4)).Style.Border.SetInsideBorder(XLBorderStyleValues.Thin);
                ws.Range(ws.Cell(startRow, 1), ws.Cell(startRow, 4)).Style.Fill.BackgroundColor = XLColor.Gray;

                startRow++;

                foreach (var accountCategory in data)
                {
                    ws.Cell(startRow, 1).Value = accountCategory.Key;
                    ws.Range(ws.Cell(startRow, 1), ws.Cell(startRow, 4)).Merge();
                    ws.Range(ws.Cell(startRow, 1), ws.Cell(startRow, 4)).Style.Fill.BackgroundColor = XLColor.Gray;
                    ws.Range(ws.Cell(startRow, 1), ws.Cell(startRow, 4)).Style.Font.Bold = true;
                    ws.Range(ws.Cell(startRow, 1), ws.Cell(startRow, 4)).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
                    ws.Range(ws.Cell(startRow, 1), ws.Cell(startRow, 4)).Style.Border.SetOutsideBorder(XLBorderStyleValues.Thin);

                    startRow++;

                    var budgetPositionStartRow = startRow;

                    foreach (var item in accountCategory)
                    {
                        ws.Cell(startRow, 1).Value = item.BudgetPositionName;
                        ws.Cell(startRow, 2).Value = item.PlannedValue;
                        ws.Cell(startRow, 2).Style.NumberFormat.Format = "#,##0.00";
                        ws.Cell(startRow, 3).Value = item.FinalValue;
                        ws.Cell(startRow, 3).Style.NumberFormat.Format = "#,##0.00";
                        ws.Cell(startRow, 4).Value = item.Comment;

                        startRow++;
                    }

                    ws.Range(ws.Cell(budgetPositionStartRow, 1), ws.Cell(startRow - 1, 4)).Style
                        .Border.SetOutsideBorder(XLBorderStyleValues.Thin)
                        .Border.SetInsideBorder(XLBorderStyleValues.Thin)
                        .Fill.BackgroundColor = XLColor.LightBlue;
                }

                ws.Columns().AdjustToContents();
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string fileName = reportName + "_" + DateTime.Now.ToString("yyyyMMdd") + "_" + DateTime.Now.ToString("HHmmss") + ".xlsx";
                    return Tuple.Create(stream, fileName);
                }
            }
        }
    }
}
