var app = app || {};

app.sidebar = function () {
    const closeDropdown = function () {
        $('#dropdown-administration-toggle').attr("aria-expanded", false);
        $('#dropdown-administration').addClass("hidden");
    }

    const showElements = function () {
        $("li.side-li > a > *").not(".icon").removeClass('hidden');
        $("li.side-li > button > *").not(".icon").removeClass('hidden');
    }

    const hideElements = function () {
        closeDropdown();
        $("li.side-li > a > *").not(".icon").addClass('hidden');
        $("li.side-li > button > *").not(".icon").addClass('hidden');
    }

    const openMenu = function () {
        $(this).animate(
            {
                "width": "16rem",
            },
            {
                duration: 100,
                easing: "swing",
                queue: false,
            }
        );
        $("#content").animate(
            {
                "margin-left": "16em",
            },
            {
                duration: 100,
                easing: "swing",
                queue: false,
                done: showElements
            }
        );
    }

    const closeMenu = function () {
        $(this).animate(
            {
                "width": "4rem"
            },
            {
                start: hideElements,
                queue: false,
            }
        );
        $("#content").animate(
            {
                "margin-left": "4em",
            },
            {
                start: hideElements,
                queue: false,
                done: hideElements

            }
        );
    }

    const initSidebar = function () {
        $(function () {
            if ($("body").width() > 768) {
                $("#content").addClass("md:ml-16");
                hideElements();
                $("#app-sidebar").hover(
                    openMenu,
                    closeMenu
                )
            }
        });
    }

    return {
        initSidebar: initSidebar,
    }
}();