﻿using Infrastructure.Helpers;
using Kendo.Mvc.Extensions;
using Microsoft.AspNetCore.Mvc;
using PFMPortal.DTO.BudgetData;
using PFMPortal.Infrastructure.Core.PFM;
using PFMPortal.Infrastructure.Core.Utils;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Resources;

namespace PFMPortal.Controllers.PFM
{
    public class BudgetDataPublicController : Controller
    {
        private readonly BudgetDataService _service;
        private readonly BudgetDataReportService _reportService;
        private readonly PFMDropDownService _dropdownService;
        private readonly FileManagementService _fileManagementService;

        public BudgetDataPublicController(BudgetDataService service, PFMDropDownService dropdownService, BudgetDataReportService reportService, FileManagementService fileManagementService)
        {
            _service = service;
            _dropdownService = dropdownService;
            _reportService = reportService;
            _fileManagementService = fileManagementService;
        }

        public IActionResult Index(SearchBudgetDataDTO args)
        {
            return IndexHelper(args, "IndexGraph");
        }

        public IActionResult IndexTable(SearchBudgetDataDTO args)
        {
            return IndexHelper(args, "IndexTable");
        }

        public IActionResult IndexDocument(SearchBudgetDataDTO args)
        {
            if (!string.IsNullOrEmpty(args.MunicipalityName))
            {
                var res = _service.GetMunicipalityBySlug(args.MunicipalityName);

                if (res.MunicipalityID == 0)
                {
                    TempData["error-message"] = MessageRes.MunicipalityNotFound;
                    return RedirectToAction("Index", "Home");
                }

                args.MunicipalityID = res.MunicipalityID;

                ViewData["MunicipalityTitle"] =  res.MunicipalityName ?? string.Empty;
                ViewData["LGUStatus"] = LGUHelper.GetLGUType(res.EntityID, res.LocalGovernmentUnitID) ?? string.Empty;
            }
            
            CreateFilterDDLs(ref args);

            var ret = _fileManagementService.GetFileGrid(args);
            return View("IndexDocument", ret);
        }

        private IActionResult IndexHelper(SearchBudgetDataDTO args, string viewName)
        {
            if (!string.IsNullOrEmpty(args.MunicipalityName))
            {
                var res = _service.GetMunicipalityBySlug(args.MunicipalityName);

                if (res.MunicipalityID == 0)
                {
                    TempData["error-message"] = MessageRes.MunicipalityNotFound;
                    return RedirectToAction("Index", "Home");
                }

                args.MunicipalityID = res.MunicipalityID;
            }

            CreateFilterDDLs(ref args);

            var grid = _service.GetBudgetDataReadGrid(args);
            grid.Description = _service.GetBudgetTitle(args.Year, args.MunicipalityID).Title;

            if (args.MunicipalityID > 0 && !grid.Data.Any())
            {
                TempData["error-message"] = MessageRes.BudgetDataMissing;
                return RedirectToAction("Index", "Home");
            }

            ViewData["MunicipalityTitle"] = grid.Data.FirstOrDefault()?.MunicipalityName ?? string.Empty;
            ViewData["LGUStatus"] = grid.Data.FirstOrDefault()?.LGUStatus ?? string.Empty;

            return View(viewName, grid);
        }

        private void CreateFilterDDLs(ref SearchBudgetDataDTO args)
        {
            args.Municipalities = _dropdownService.GetAllMunicipalities();
            args.Years = _dropdownService.GetBudgetDataYears();
            args.ValueTypes = _dropdownService.GetValueTypes();
            args.AccountTypes = _dropdownService.GetAccountTypes();

            if (args.Year == 0)
            {
                args.Year = _service.GetLatestYearForMunicipality(args.MunicipalityID);
            }
        }

        #region <!--- Reports --->

        [HttpGet]
        public IActionResult ExcelExport(int municipalityId, int year)
        {
            var _excel = _reportService.ExportToExcel(municipalityId, year, "Izvještaj");
            return File(_excel.Item1.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", _excel.Item2);
        }

        #endregion

        #region "CHARTS"

        public IActionResult MainPieChart(int municipalityID, int yearID, short accountTypeID, short amountTypeID = (short)GlobalEnum.AmountType.Planned)
        {
            // add current year as default
            if (yearID == 0)
            {
                yearID = DateTime.Now.Year;
            }

            var lst = _service.GetDataForMainPieChart(municipalityID, yearID, accountTypeID, amountTypeID);
            return Json(lst);
        }

        public IActionResult DonutCharts(int accountCategoryID, int municipalityID, int yearID, short accountTypeID, short amountTypeID = (short)GlobalEnum.AmountType.Planned)
        {
            // add current year as default
            if (yearID == 0)
            {
                yearID = DateTime.Now.Year;
            }
            var lst = _service.GetDataForDonutChart(accountCategoryID, municipalityID, yearID, accountTypeID, amountTypeID);
            return Json(lst);
        }

        public JsonResult BarChart(int municipalityID, int yearID)
        {
            if (yearID == 0)
            {
                yearID = DateTime.Now.Year;
            }

            var lst = _service.GetDataForBarChart(municipalityID, yearID);
            return Json(lst);
        }

        public JsonResult ExportToJson(int municipalityID, int yearID)
        {
            if (yearID == 0)
            {
                yearID = DateTime.Now.Year;
            }

            var data = _service.GetData(municipalityID, yearID);

            return Json(data);
        }

        #endregion
    }
}
