﻿namespace PFMPortal.Domain.Entities.App
{
    public class BudgetPosition : SysEntity
    {
        public int BudgetPositionID { get; set; }
        public string BudgetPositionName { get; set; } = string.Empty;
        public int AccountCategoryID { get; set; }
        public virtual AccountCategory AccountCategory { get; set; }
        public virtual ICollection<BudgetData> BudgetData { get; set; }
        public bool Archived { get; set; }
    }
}
