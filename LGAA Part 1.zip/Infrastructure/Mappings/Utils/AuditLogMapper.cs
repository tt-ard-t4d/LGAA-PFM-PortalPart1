﻿using Domain.Entities.Utils;
using DTO.Utils;
using PFMPortal.Domain.Entities;
using PFMPortal.DTO.Admin;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Utility;

namespace Infrastructure.Mappings.Utils
{
    public class AuditLogMapper
    {
        public AuditLogDTO MapAuditLog(AuditLog auditlog)
        {
            return new AuditLogDTO()
            {
                AuditLogID = auditlog.AuditLogID,
                AuditLogText = auditlog.AuditLogText,
                SysCreatedByUserID = auditlog.SysCreatedByUserID,
                SysModifiedByUserID = auditlog.SysLastModifiedByUserID,
                SysDateCreated = auditlog.SysCreatedDate,
                SysDateLastModified = auditlog.SysLastModifiedDate,
                RelatedItemID = auditlog.RelatedItemID
            };
        }

        public AuditLogDTO MapAuditLog()
        {
            return new AuditLogDTO()
            {
                AuditLogID = 0
            };
        }

        public AuditLog MapAuditLog(AuditLogDTO auditlog)
        {
            return new AuditLog()
            {
                AuditLogID = auditlog.AuditLogID,
                AuditLogText = auditlog.AuditLogText,
                SysCreatedByUserID = auditlog.SysCreatedByUserID,
                SysLastModifiedByUserID = auditlog.SysModifiedByUserID,
                SysCreatedDate = auditlog.SysDateCreated,
                SysLastModifiedDate = auditlog.SysDateLastModified,
                RelatedItemID = auditlog.RelatedItemID

            };
        }

        public AuditLogGridDTO MapGrid(AuditLog entity, IConfiguration configuration, int totalNumberOfRows = 0)
        {
            if (entity == null)
            {
                return new AuditLogGridDTO();
            }

            return new AuditLogGridDTO()
            {
                AuditLogID = entity.AuditLogID,
                AuditLogText = entity.AuditLogText,
                AuditLogEnumerationID = entity.AuditLogEnumerationID,
                SysDateCreated = entity.SysCreatedDate,
                Total = totalNumberOfRows
            };
        }
    }
}
