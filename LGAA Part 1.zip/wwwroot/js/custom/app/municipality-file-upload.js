﻿var app = app || {};

app.municipalityFileUpload = function () {

    $(function () {
        countNumberOfItems();
    });

    let fileTableId = '#FileTable';
    let labelFileName = 'LabelFileName';

    var upload = function (id, typeId, recentlyAddedTableId) {

        var input = $('input[type=file][name=filedata]')[0];

        $.each(input.files, function (i, g) {
            app.utility.showLoader();
            data = {};
            data.NewFileName = input.files.item(i).name;
            data.Files = g;
            data.FileSize = input.files.item(i).size;

            addTempFilesToDB(data, id, typeId, recentlyAddedTableId);
        });
    }

    var addTempFilesToDB = function (filedata, id, typeId) {

        var formData = new FormData();
        formData.append('id', id);
        formData.append('typeId', typeId);
        formData.append('file', filedata.Files);

        $.ajax({
            url: '/FileUpload/AddTempFileItems',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (data) {
                app.utility.hideLoader()
                if (data) {

                    $.each(data, function (i, g) {

                        let html =
                        `<tr class="bg-white border-b">
                            <td><a href="${g.urlAzure}" target="_self"><i class="bi bi-download"></i></a></td>
                            <td scope ="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">${g.fileName}</td>
                            <td>${g.fileExtension}</td>
                            <td>${g.fileLenght}</td>
                            <td><i class="bi bi-trash" onclick="app.municipalityFileUpload.deleteFileFromList('${g.formFileID}', $(this).parent().parent())"></i></td>
                        </tr>`;

                        $(fileTableId + ' > tbody').prepend(html);
                    });

                    countNumberOfItems();
                }
            },
            error: function () {
                toastr.error(app.resource.getByResourceGroupAndKey('MessageRes', 'Error'));
            }
        });
    };

    var countNumberOfItems = function () {
        var rowCount = $(`${fileTableId} tr`).length;
        $(labelFileName).text(`${rowCount} files`);
    }

    var deleteFileFromList = function (id, el) {

        var endpointRoute = '/FileUpload/DeleteFormFile';
        app.resource.initSpecificResources(['Buttons', 'MessageRes'], function () {
            app.modal.createConfirmationModal(app.resource.getByResourceGroupAndKey('MessageRes', 'DeleteFile'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Yes'),
                app.resource.getByResourceGroupAndKey('Buttons', 'Cancel'),
                function () { sendDeleteRequest(endpointRoute, id, el); });
        });

    }

    var sendDeleteRequest = function (endpointRoute, data, el) {
        if (data > 0) {
            app.utility.showLoader('body');
            $.ajax({
                method: "POST",
                url: endpointRoute,
                data: {
                    id: data
                },
                dataType: "json"
            }).done(function (result) {
                app.utility.hideLoader()
                if (data.isError) {
                    toastr.error(app.resource.getByResourceGroupAndKey('MessageRes', 'Error'));
                } else {
                    $(el).remove();
                    countNumberOfItems();
                    toastr.success(app.resource.getByResourceGroupAndKey('MessageRes', 'DeleteSuccess'));
                }
            });
        }
    };

    var downloadFile = function (guid) {
        app.utility.showLoader('body');
        window.location = baseurl + '/Form/DownloadFormFile?GUID=' + guid;
        app.utility.hideLoader('body');
    }

    return {
        upload: upload,
        deleteFileFromList: deleteFileFromList,
        downloadFile: downloadFile,
    }
}();