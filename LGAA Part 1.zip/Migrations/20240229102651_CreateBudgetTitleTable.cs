﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PFMPortal.Migrations
{
    /// <inheritdoc />
    public partial class CreateBudgetTitleTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BudgetTitles",
                schema: "pfm",
                columns: table => new
                {
                    BudgetTitleGuid = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    BudgetTitleDisplayId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Year = table.Column<int>(type: "int", nullable: false),
                    MunicipalityId = table.Column<int>(type: "int", nullable: false),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BudgetTitles", x => x.BudgetTitleGuid);
                });

            migrationBuilder.CreateIndex(
                name: "IX_BudgetTitles_BudgetTitleDisplayId",
                schema: "pfm",
                table: "BudgetTitles",
                column: "BudgetTitleDisplayId",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BudgetTitles",
                schema: "pfm");
        }
    }
}
