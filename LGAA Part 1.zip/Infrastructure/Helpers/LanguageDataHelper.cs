﻿using Microsoft.AspNetCore.Http;
using DTO.Utils;
using System.Globalization;
using Infrastructure.Models;

namespace Infrastructure.Helpers
{
    /// <summary>
    /// OBRISATI CITAVU KLASU; NAKON DODAVANJA CORE VARIJANTE
    /// </summary>
    public class LanguageDataHelper
    {

        #region <!--- APPLICATION LANGUAGE --->

        public static List<LanguageDTO> Languages
        {
            get { return AppSettingsHelper.GetContxt<List<LanguageDTO>>("Languages"); }
            set
            {
                AppSettingsHelper.SetContxt("Languages", value);
            }
        }

        #endregion

        #region <!--- APPLICATION LANGUAGE --->
        public static void SetApplicationLanguage()
        {
            CultureInfo cultureInfo = new CultureInfo(LanguageDataHelper.ApplicationLanguage.LCID);
            Thread.CurrentThread.CurrentCulture = cultureInfo;
            Thread.CurrentThread.CurrentUICulture = cultureInfo;
        }

        private static LanguageDTO GetAppLanguage()
        {
            return LanguageDataHelper.Languages.Where(r => r.LCID == Thread.CurrentThread.CurrentCulture.LCID).FirstOrDefault();
        }

        public static LanguageDTO ApplicationLanguage
        {
            get { return GetAppLanguage(); }
            set
            {
                Thread.CurrentThread.CurrentCulture = CultureInfo.GetCultureInfo(DataUserLanguage.Name);
                Thread.CurrentThread.CurrentUICulture = CultureInfo.GetCultureInfo(DataUserLanguage.Name);
            }
        }

        public static string DateFormat
        {
            get
            {
                // Replace is because of moment.js formatting
                return DateTimeFormatInfo.CurrentInfo.ShortDatePattern.Replace("yyyy", "YYYY").Replace('d', 'D');
            }
        }

        public static int ApplicationLanguageId
        {
            get { return GetAppLanguage().LanguageID; }
        }

        #endregion

        #region <!--- DATA LANGUAGE --->

        public static int DataUserLanguageId { get { return GetUserDataLanguageId(); } }

        private static LanguageDTO GetUserDataLanguage()
        {
            var user = AppSettingsHelper.GetContxt<UserData>("CurrentUser");
            var lid = int.Parse(AppSettingsHelper.GetConfig("AppIdentitySettings:DefaultLanguageId"));

          

            if (user != null) { lid = user.DefaultLanguageID; }

            return LanguageDataHelper.Languages.Where(c => c.LanguageID == lid).FirstOrDefault();
        }

        private static int GetUserDataLanguageId()
        {
            var user = AppSettingsHelper.GetContxt<UserData>("CurrentUser") != null ? AppSettingsHelper.GetContxt<UserData>("CurrentUser") : null;
            if (user != null) { return user.DefaultLanguageID; }
            return int.Parse(AppSettingsHelper.GetConfig("AppIdentitySettings:DefaultLanguageId"));
        }

        public static LanguageDTO DataUserLanguage
        {
            get { return GetUserDataLanguage(); }
            set
            {

            }
        }



        #endregion

    }
}