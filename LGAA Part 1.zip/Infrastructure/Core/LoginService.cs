﻿using Infrastructure.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using PFMPortal.Domain.Contracts.Admin;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Core.Admin;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Mappings;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Infrastructure.Models.StoredProcedures;
using PFMPortal.Infrastructure.Utility;
using System.Security.Claims;

namespace PFMPortal.Infrastructure.Core
{
    public class LoginService
    {
        private readonly IUserRepository _userRepository;
        private readonly IConfiguration _configuration;
        private readonly UserService _userService;

        public LoginService(IUserRepository userRepository, IConfiguration configuration, UserService userService)
        {
            _userRepository = userRepository;
            _configuration = configuration;
            _userService = userService;
        }

        public UserData ValidateUser(string userName, string password)
        {
            var userNameEnc = SEDManager.Protect(userName, _configuration);

            var user = _userRepository.GetUserByUserNameEnc(userNameEnc);

            if (user != null)
            {
                var isAuthenticated = HashingUtils.VerifyPassword(password, user.PasswordHash, user.PasswordSalt);

                if (isAuthenticated == true)
                {
                    var map = new SessionUserMapper();
                    //User actions are obtained as stored procedure result
                    var userActions = _userService.GetUserActions(user.UserID);
                    return map.Map(user, userActions, _configuration);
                }
            }

            return new UserData();
        }

        public ClaimsPrincipal AddClaims(LoginDTO model, UserData user)
        {
            var userClaim = new List<Claim>()
            {
                new Claim(ClaimTypes.Name, model.UserName.ToString()),
                new Claim(CustomClaimTypes.UserId, user.UserID.ToString(), ClaimValueTypes.Integer),
                new Claim(CustomClaimTypes.Email, user.Email.ToString()),
                new Claim(CustomClaimTypes.CurrentImpersonatedUserId, user.UserID.ToString(), ClaimValueTypes.Integer),
                new Claim(CustomClaimTypes.CurrentImpersonatedUserEmail, user.Email),
            };

            var userIdentity = new ClaimsIdentity(userClaim, CookieAuthenticationDefaults.AuthenticationScheme);
            var userPrincipal = new ClaimsPrincipal(userIdentity);

            return userPrincipal;
        }

        public UserData ValidateDirectoryUserEmail(string? email)
        {
            var userEmailEnc = SEDManager.Protect(email, _configuration);

            var user = _userRepository.GetDirectoryUserByEmail(userEmailEnc);

            if (user != null)
            {
                    var map = new SessionUserMapper();
                    var userActions = _userService.GetUserActions(user.UserID);
                    return map.Map(user, userActions, _configuration);
                
            }

            return new UserData();
        }
    }
}
