﻿using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using PFMPortal.Domain.Contracts.PFM;
using PFMPortal.Domain.Entities.App;

namespace PFMPortal.Infrastructure.Data.Repositories.PFM
{
    public class PFMDropdownRepository : IPFMDropDownRepository
    {
        private readonly DatabaseContext _dc;

        public PFMDropdownRepository(DatabaseContext dc)
        {
            _dc = dc;
        }

        public IQueryable<AccountType> GetAccountTypes()
        {
            return _dc.AccountTypes.Where(r => r.Retired == false).AsNoTracking();
        }

        public IQueryable<Municipality> GetAllMunicipalities()
        {
            return _dc.Municipalities.Where(r => r.Retired == false).AsNoTracking();
        }

        public IQueryable<Entity> GetEntities()
        {
            return _dc.Entities.Where(r => r.Retired == false).AsNoTracking();
        }

        public IQueryable<Municipality> GetMunicipalitiesForUser(Guid userId)
        {
            return _dc.UserMunicipalities.Include(r => r.Municipality).Where(r => r.Retired == false && r.UserID == userId).Select(r => r.Municipality);
        }
    }
}
