﻿namespace PFMPortal.DTO.BudgetDataComparison
{
    public class GraphDataDTO
    {
        public List<string> BudgetLines { get; set; } = new List<string>();
        public List<MunicipalityBudgetDataDTO> Data { get; set; } = new List<MunicipalityBudgetDataDTO>();
        public List<int> EmptyMunicipalities { get; set; } = new();
    }
}
