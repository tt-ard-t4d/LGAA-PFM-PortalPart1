﻿using Microsoft.AspNetCore.Mvc;

namespace PFMPortal.Controllers
{
    public class PartialController : Controller
    {
        public PartialViewResult ConfirmationModal()
        {
            return PartialView("_ConfirmationModal");
        }
    }
}
