﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Globalization;

namespace PFMPortal.Infrastructure.Binders.Providers
{
    public class DateTimeModelBinderProvider : IModelBinderProvider
    {
        internal static readonly DateTimeStyles SupportedStyles = DateTimeStyles.AdjustToUniversal | DateTimeStyles.AllowWhiteSpaces;
        public IModelBinder? GetBinder(ModelBinderProviderContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException(nameof(context));
            }

            var modelType = context.Metadata.UnderlyingOrModelType;

            if (modelType == typeof(DateTime) || modelType == typeof(DateTime?))
            {
                return new DateTimeModelBinder(SupportedStyles);
            }

            return null;
        }
    }
}
