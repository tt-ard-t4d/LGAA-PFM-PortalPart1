﻿using ClosedXML.Excel;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Resources;

namespace PFMPortal.Infrastructure.Core.Utils
{
    public class ReportingService
    {
        public Tuple<MemoryStream, string> GenerateReport<T>(List<T> data, string reportName) where T: class, new()
        {
            return CreateDefaultReport(data, reportName);
        }

        private Tuple<MemoryStream, string> CreateDefaultReport<T>(List<T> data, string reportName) where T : class, new()
        {
            using (XLWorkbook wb = new XLWorkbook())
            {
                var ws = wb.Worksheets.Add(ReportingRes.DefaultSheetName);
                ReportHelper.CreateHeader(ref ws, data);
                ReportHelper.CreateRows(ref ws, data);

                ws.Columns().AdjustToContents();
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string fileName = reportName + "_" + DateTime.Now.ToString("yyyyMMdd") + "_" + DateTime.Now.ToString("HHmmss") + ".xlsx";
                    return Tuple.Create(stream, fileName);
                }
            }
        }
    }
}
