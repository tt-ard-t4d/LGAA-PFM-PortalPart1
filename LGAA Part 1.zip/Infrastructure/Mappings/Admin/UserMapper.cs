﻿using AngleSharp.Dom;
using Infrastructure.Helpers;
using Microsoft.AspNetCore.DataProtection;
using PFMPortal.Domain.Entities;
using PFMPortal.DTO.Admin;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Utility;
using System.Text;

namespace PFMPortal.Infrastructure.Mappings.Admin
{
    public class UserMapper
    {
        public UserDTO Map(User? entity, IConfiguration configuration)
        {
            if (entity == null)
            {
                return new UserDTO();
            }

            return new UserDTO()
            {
                UserID = entity.UserID,
                UserName = SEDManager.Unprotect(entity.UserNameEnc, configuration),
                FirstName = SEDManager.Unprotect(entity.FirstNameEnc, configuration),
                LastName = SEDManager.Unprotect(entity.LastNameEnc, configuration),
                Email = SEDManager.Unprotect(entity.EmailEnc, configuration),
                EmailCode = entity.EmailCode,
                UserGroupIDs = entity.UserGroupUsers.Where(r => r.Retired == false).Select(r => (int)r.UserGroupID).ToList(),
                UserActionIDs = entity.UserActions.Where(r => r.Retired == false).Select(r => (int)r.ActionID).ToList(),
                MunicipalityIDs = entity.UserMunicipalities.Where(r => r.Retired == false).Select(r => r.MunicipalityID).ToList(),
                ValidFrom = entity.ValidFrom,
                ValidTo = entity.ValidTo,
                IsDirectoryUser = entity.IsDirectoryUser
            };
        }

        public UserDTO MapEmail(User? entity, IConfiguration configuration)
        {
            if (entity == null)
            {
                return new UserDTO();
            }

            return new UserDTO()
            {
                UserID = entity.UserID,
                Email = SEDManager.Unprotect(entity.EmailEnc, configuration),
            };
        }

        public User Map(UserDTO model, IConfiguration configuration, GlobalEnum.CrudOperation operation, Guid loggedUserId)
        { 
            var user = new User()
            {
                UserID = model.UserID,
                UserNameEnc = SEDManager.Protect(model.UserName, configuration),
                FirstNameEnc = SEDManager.Protect(model.FirstName, configuration),
                LastNameEnc = SEDManager.Protect(model.LastName, configuration),
                EmailEnc = SEDManager.Protect(model.Email.ToLower(), configuration),
                ValidFrom = model.ValidFrom.HasValue ? model.ValidFrom.Value : DateTime.Now,
                ValidTo = model.ValidTo.HasValue ? model.ValidTo.Value : DateTime.MaxValue,
                IsDirectoryUser = model.IsDirectoryUser
            };

            if (operation == GlobalEnum.CrudOperation.Add)
            {
                user.SysCreatedByUserID = Guid.NewGuid();
                user.SysCreatedDate = DateTime.Now;
                user.Retired = false;

                string passwordSalt;

                if (model.UserChoicePassword)
                {
                    model.Password = HashingUtils.GenerateRandomString();
                }

                string passwordHash = HashingUtils.HashPassword(model.Password, out passwordSalt);
                user.PasswordHash = passwordHash;
                user.PasswordSalt = passwordSalt;
            }
            else if (operation == GlobalEnum.CrudOperation.Edit)
            {
                user.SysLastModifiedByUserID = loggedUserId;
                user.SysLastModifiedDate = DateTime.Now;
            }

            return user;
        }
        public UserGridDTO MapGrid(User entity, IConfiguration configuration, int totalNumberOfRows = 0)
        {
            if (entity == null)
            {
                return new UserGridDTO();
            }

            return new UserGridDTO()
            {
                UserID = entity.UserID,
                FirstName = SEDManager.Unprotect(entity.FirstNameEnc, configuration),
                LastName = SEDManager.Unprotect(entity.LastNameEnc, configuration),
                Email = SEDManager.Unprotect(entity.EmailEnc, configuration),
                UserName = SEDManager.Unprotect(entity.UserNameEnc, configuration),
                Total = totalNumberOfRows
            };
        }
    }
}
