﻿using Microsoft.AspNetCore.Mvc;
using PFMPortal.Infrastructure.Core.PFM;

namespace PFMPortal.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly MunicipalityService _municipalityService;
        public HomeController(ILogger<HomeController> logger, MunicipalityService municipalityService)
        {
            _municipalityService = municipalityService;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View(_municipalityService.GetMunicipalityHomeGrid());
        }

        public string Culture()
        {
            return Thread.CurrentThread.CurrentCulture.Name;
        }

        public IActionResult Info()
        {
            return View();
        }
    }
}