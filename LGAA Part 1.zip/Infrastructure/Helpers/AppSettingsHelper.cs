﻿using Microsoft.AspNetCore.Http;
using System.Text.Json;

namespace Infrastructure.Helpers
{
    /// <summary>
    /// OBRISATI CITAVU KLASU
    /// </summary>
    public static class AppSettingsHelper
    {
        private static IConfiguration _config;
        private static IHttpContextAccessor _contxt;

        public static void AppSettingsConfigure(IConfiguration config, IHttpContextAccessor contxt)
        { 
            _config = config;
            _contxt = contxt;
        }

        public static string GetConfig(string key)
        { 
            return _config.GetSection(key).Value;
        }

      
        public static void SetContxt<T>( string key, T value)
        {
            HttpContext httpContext = _contxt.HttpContext;
            httpContext.Session.SetString(key, JsonSerializer.Serialize(value));
        }

        public static T? GetContxt<T>(string key)
        {
            HttpContext httpContext = _contxt.HttpContext;
            var value = httpContext.Session.GetString(key);
            return value == null ? default : JsonSerializer.Deserialize<T>(value);
        }

        public static string GetContxtHeader(string key)
        {
            HttpContext httpContext = _contxt.HttpContext;
            var value = httpContext.Request.Headers[key];
            return value;
        }

    }
}
