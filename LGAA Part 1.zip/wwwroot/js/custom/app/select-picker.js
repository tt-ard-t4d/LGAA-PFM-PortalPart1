﻿var app = app || {};

app.selectPicker = function () {

    var addPickers = function (options = {}) {
        const { search = false, multiple = false, clear = false, selectAll = false, rows = 5, disabled = false, autoSelect = false, classList = "" } = options;
        $('.select-picker').each(function () {
            $(this).attr('data-te-class-notch-leading', "hidden");
            $(this).attr("data-te-class-notch-leading-normal", "hidden");
            $(this).attr("data-te-class-notch-leading-white", "hidden");
            $(this).attr("data-te-class-notch-middle", "hidden");
            $(this).attr("data-te-class-notch-middle-normal", "hidden");
            $(this).attr("data-te-class-notch-middle-white", "hidden");
            $(this).attr("data-te-class-notch-trailing", "hidden");
            $(this).attr("data-te-class-notch-trailing-normal", "hidden");
            $(this).attr("data-te-class-notch-trailing-white", "hidden");
            $(this).attr("data-te-class-select-input-size-default", "py-2.5 leading-none");
            $(this).attr("data-te-class-select-input-size-lg", "py-2.5 leading-none");
            $(this).attr("data-te-class-select-input-size-sm", "py-2.5 leading-none");
            $(this).attr("data-te-class-form-outline", "relative border-0");
            $(this).attr("data-te-class-select-input", "bg-gray-50 border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full px-2.5 py-2.5");
            $(this).attr("data-te-class-select-arrow-default", "top-2.5");

            const select = te.Select.getOrCreateInstance(this,
                {
                    multiple: multiple,
                    selectAll: selectAll,
                    selectClearButton: false,
                    selectFilter: search,
                    selectDisplayedLabels: rows,
                    disabled: disabled,
                    selectAutoSelect: autoSelect,
                    selectOptionsSelectedLabel: "izabranih opcija",
                    selectSearchPlaceholder: "Pretraži...",
                    selectNoResultText: "Nema rezultata",
                    selectAllLabel: "Odaberi sve opcije",
                });
            //select.addEventListener('valueChange.te.select', function () {
            //    $("[data-te-select-clear-btn-ref]").each(function () {
            //        $(this).click(function () {
            //            console.log("Klik")
            //        })
            //    })
            //});
        });

        
        

    };

    return {
        addPickers: addPickers
    }
}();