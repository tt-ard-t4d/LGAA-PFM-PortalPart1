﻿using DocumentFormat.OpenXml.Bibliography;
using Infrastructure.Data;
using Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using PFMPortal.Domain.Contracts.PFM;
using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.BudgetData;
using PFMPortal.Infrastructure.Models;
using static PFMPortal.Infrastructure.Helpers.PFMEnum;

namespace PFMPortal.Infrastructure.Data.Repositories.PFM
{
    public class BudgetDataRepository : IBudgetDataRepository
    {

        private readonly DatabaseContext _dc;

        public BudgetDataRepository(DatabaseContext dc)
        {
            _dc = dc;
        }

        public RetValue CreateBudgetDataEntry(int year, List<Municipality> municipalities, Guid loggedUserId)
        {
            var budgetPositions = GetBudgetPositions();
            //var accountCategories = GetAccountCategories();

            AddBudgetDataEntries(year, ref municipalities, ref budgetPositions, loggedUserId);
            //AddAccountCategoryDataEntries(year, ref municipalities, ref accountCategories, loggedUserId);

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { IsError = false };
        }

        private void AddBudgetDataEntries(int year, ref List<Municipality> municipalities, ref List<BudgetPosition> budgetPositions, Guid loggedUserId)
        {
            DateTime currentDate = DateTime.Now;

            foreach (var mun in municipalities)
            {
                foreach (var pos in budgetPositions)
                {
                    if (mun.EntityID == pos.AccountCategory.EntityID)
                    {
                        _dc.BudgetData.Add(

                        new BudgetData()
                        {
                            BudgetDataID = 0,
                            Year = year,
                            MunicipalityID = mun.MunicipalityID,
                            BudgetPositionID = pos.BudgetPositionID,
                            PlannedValue = null,
                            FinalValue = null,
                            SysCreatedDate = currentDate,
                            SysCreatedByUserID = loggedUserId
                        });
                    }
                }
            }
        }

        private void AddAccountCategoryDataEntries(int year, ref List<Municipality> municipalities, ref List<AccountCategory> accountCategories, Guid loggedUserId)
        {
            DateTime currentDate = DateTime.Now;

            foreach (var mun in municipalities)
            {
                foreach (var cat in accountCategories)
                {
                    if (cat.EntityID == mun.EntityID)
                    {
                        _dc.AccountCategoryData.Add(
                            new AccountCategoryData()
                            {
                                AccountCategoryID = cat.AccountCategoryID,
                                MunicipalityID = mun.MunicipalityID,
                                Year = year,
                                TotalPlannedValue = null,
                                TotalFinalValue = null,
                                SysCreatedDate = currentDate,
                                SysCreatedByUserID = loggedUserId
                            }
                        );
                    }
                }
            }

        }

        public IQueryable<BudgetData> GetBudgetDataGrid(SearchBudgetDataDTO args)
        {
            var res = _dc.BudgetData.AsNoTracking()
                .Where(r => r.Retired == false && r.MunicipalityID == args.MunicipalityID && r.Year == args.Year)
                .Include(r => r.Municipality)
                .ThenInclude(r => r.LocalGovernmentUnit)
                .Include(r => r.BudgetPosition)
                .ThenInclude(r => r.AccountCategory);

            return res;
        }

        public List<int> GetBudgetDataYears()
        {
            return _dc.BudgetData.AsNoTracking().Where(r => r.Retired == false).GroupBy(r => r.Year)
                .Select(r => r.First().Year).ToList();
        }

        public List<int> GetBudgetDataYearsForMunicipality(int municipalityId)
        {
            return _dc.BudgetData.AsNoTracking().Where(r => r.MunicipalityID == municipalityId && r.Retired == false)
                .GroupBy(r => r.Year).Select(r => r.First().Year).ToList();
        }

        private List<BudgetPosition> GetBudgetPositions()
        {
            return _dc.BudgetPositions
                .Include(r => r.AccountCategory)
                .AsNoTracking().Where(r => r.Retired == false).ToList();
        }

        private List<AccountCategory> GetAccountCategories()
        {
            return _dc.AccountCategories
                .AsNoTracking().Where(r => r.Retired == false).ToList();
        }

        public RetValue Save(IEnumerable<BudgetData> budgetData, BudgetDataValueType dataValueType)
        {
            foreach (var item in budgetData)
            {
                _dc.BudgetData.Attach(item);

                _dc.Entry(item).Property(r => r.SysLastModifiedByUserID).IsModified = true;
                _dc.Entry(item).Property(r => r.SysLastModifiedDate).IsModified = true;

                if (dataValueType == BudgetDataValueType.Planned)
                {
                    _dc.Entry(item).Property(r => r.PlannedValue).IsModified = true;
                }
                else if (dataValueType == BudgetDataValueType.Final)
                {
                    _dc.Entry(item).Property(r => r.FinalValue).IsModified = true;
                    _dc.Entry(item).Property(r => r.Comment).IsModified = true;
                }
            }

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { IsError = false };
        }

        public IQueryable<BudgetData> GetDataForChart(int municipalityID, int yearID, short accountTypeID)
        {
            return _dc.BudgetData
                .Include(p => p.BudgetPosition)
                .Include(p => p.BudgetPosition.AccountCategory)
                .Include(p => p.BudgetPosition.AccountCategory.AccountType)
                .AsNoTracking()
                .Where(r =>
                r.MunicipalityID == municipalityID &&
                r.Year == yearID &&
                r.BudgetPosition.AccountCategory.AccountTypeID == accountTypeID);
        }

        public IQueryable<BudgetData> GetDataForChartMunicipalities(List<int> municipalityIDs, int year, int accountTypeID)
        {
            return _dc.BudgetData
                .Include(p => p.BudgetPosition)
                .Include(p => p.BudgetPosition.AccountCategory)
                .Include(p => p.BudgetPosition.AccountCategory.AccountType)
                .AsNoTracking()
                .Where(r => municipalityIDs.Contains(r.MunicipalityID) && r.Year == year && r.BudgetPosition.AccountCategory.AccountTypeID == accountTypeID);
        }

        public BudgetTitle? GetBudgetTitle(int yearId, int municipalityId)
        {
            return _dc.BudgetTitles.AsNoTracking()
                .FirstOrDefault(r => r.Year == yearId && r.MunicipalityId == municipalityId);
        }

        public RetValue SaveBudgetTitle(BudgetTitle entity, GlobalEnum.CrudOperation operation)
        {

            if (operation == GlobalEnum.CrudOperation.Edit)
            {
                _dc.BudgetTitles.Attach(entity);
                _dc.Entry(entity).State = EntityState.Modified;
                _dc.Entry(entity).Property(r => r.BudgetTitleGuid).IsModified = false;
                _dc.Entry(entity).Property(r => r.BudgetTitleDisplayId).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedDate).IsModified = false;
                _dc.Entry(entity).Property(r => r.SysCreatedByUserID).IsModified = false;
                _dc.Entry(entity).Property(r => r.Retired).IsModified = false;
            }
            else if (operation == GlobalEnum.CrudOperation.Add)
            {
                _dc.BudgetTitles.Add(entity);
            }

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }

            return new RetValue() { Guid = entity.BudgetTitleGuid };
        }
    }
}
