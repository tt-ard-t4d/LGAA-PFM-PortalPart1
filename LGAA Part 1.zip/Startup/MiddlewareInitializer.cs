﻿using Microsoft.AspNetCore.Builder;
using PFMPortal.Infrastructure.Middleware;

namespace PFMPortal.Startup
{
    public static partial class MiddlewareInitializer
    {
        public static WebApplication ConfigureMiddleware(this WebApplication app)
        {
            if (!app.Environment.IsDevelopment())
            {
                //Strict-Transport-Security header
                app.UseHsts();
            }
            else
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();
            app.AddResponseHeaders();
            app.UseSession();

            app.UseStaticFiles();
            app.UseRouting();
            app.Use((context, next) =>
            {
                context.Request.EnableBuffering();
                return next();
            });

            app.UseAuthentication();
            app.UseAuthorization();
            app.UseLocalization();

            return app;
        }
    }
}
