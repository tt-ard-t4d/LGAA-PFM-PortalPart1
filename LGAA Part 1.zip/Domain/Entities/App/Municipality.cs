﻿namespace PFMPortal.Domain.Entities.App
{
    public class Municipality : SysEntity
    {
        public int MunicipalityID { get; set; }
        public byte EntityID { get; set; }
        public string Slug { get; set; } = string.Empty;
        public virtual Entity Entity { get; set; }
        public string MunicipalityName { get; set; } = string.Empty;
        public byte LocalGovernmentUnitID { get; set; }
        public virtual LocalGovernmentUnit LocalGovernmentUnit { get; set; }
        public virtual ICollection<BudgetData> BudgetData { get; set; }
        public virtual ICollection<UserMunicipalityRel> UserMunicipalities { get; set; }
        public virtual ICollection<AccountCategoryData> AccountCategoryData { get; set; }
    }
}
