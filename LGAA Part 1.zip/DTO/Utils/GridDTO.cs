﻿namespace PFMPortal.DTO.Utils
{
    public class GridDTO<T, S>
    {
        public IEnumerable<T> Data { get; set; }
        public S Search { get; set; }
        public PageDTO Pager { get; set; }
        public bool IsSelectable { get; set; } = false;
        public int Total { get; set; }
        public string Description { get; set; }
    }
}
