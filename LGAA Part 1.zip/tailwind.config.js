/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        './Pages/**/*.cshtml',
        './Views/**/*.cshtml'
    ],
    theme: {
        extend: {
            colors: {
                "blue-us": "#002F6C",
                "blue-medium": "#0067B9",
                "blue-light": "#A7C6ED",
                "blue-web": "#205493",
                "red-us": "#BA0C2F",
                "red-dark": "#651D32",
                "black-rich": "#212721",
                "gray-dark": "6C6463",
                "gray-medium": "8C8985",
                "gray-light": "CFCDC9",
                "black-rich": "212721",
                "graph-red": "#f25840",
                "graph-red-secondary": "#f6d9d1",
                "graph-orange": "#eb9100",
                "graph-orange-secondary": "#f7e9cc",
                "graph-green": "#4e7733",
                "graph-green-secondary": "#e0e3d8",
                "graph-pink": "#db91be",
                "graph-pink-secondary": "#f4e5ea",
                "graph-blue": "#37c0c7",
                "graph-blue-secondary": "#e1f1f2",
                "graph-purple": "#793b7d",
                "graph-purple-secondary": "#f4e5ea",
                "graph-navy": "#0084bc",
                "graph-navy-secondary": "#e1f1f2",
                "graph-gray": "#586F7C",
                "graph-gray-secondary": "#F4F4F9",
                "graph-midnight": "#104F55",
                "graph-midnight-secondary": "#9EC5AB",

            },
            fontFamily: {
                'sans': ['"Source Sans 3"', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', '"Segoe UI"', 'Roboto', '"Helvetica Neue"', 'Arial', '"Noto Sans"', 'sans-serif', '"Apple Color Emoji"', '"Segoe UI Emoji"', '"Segoe UI Symbol"', '"Noto Color Emoji"'],
            },
        }
    },
    plugins: [],
}