﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using PFMPortal.DTO.BudgetDataComparison;
using PFMPortal.Infrastructure.Core.PFM;
using PFMPortal.Infrastructure.Resources;
using static PFMPortal.Infrastructure.Helpers.PFMEnum;

namespace PFMPortal.Controllers.PFM
{
    public class BudgetDataComparisonController : Controller
    {

        private readonly BudgetDataService _service;
        private readonly PFMDropDownService _dropdownService;
        private readonly MunicipalityService _municipalityService;

        public BudgetDataComparisonController(BudgetDataService service, PFMDropDownService dropdownService, MunicipalityService municipalityService)
        {
            _service = service;
            _dropdownService = dropdownService;
            _municipalityService = municipalityService;
        }


        public IActionResult Index(SearchBudgetDataComparisonDTO args)
        {
            CreateFilterDDLs(ref args);
            if (args.Years.IsNullOrEmpty())
            {
                TempData["error-message"] = MessageRes.NoData;
                return RedirectToAction("Index", "Home");
            }
            if (args.Year == 0)
            {
                args.Year = args.Years.FirstOrDefault()?.Id ?? 0;
            }
            return View(args);
        }

        public JsonResult GetGraphData([FromQuery] BudgetDataRequestDTO requestData)
        {
            if (requestData.GraphType == GraphType.ActualBudgetBarChart)
            {
                return GetComparisonGraphData(requestData);
            }

            var ret = new GraphDataDTO();
            bool first = true;

            foreach (var MunicipalityId in requestData.MunicipalityIDs)
            {
                if (first)
                {
                    ret.BudgetLines.AddRange(_service.GetDataForMainPieChart(MunicipalityId, requestData.Year, requestData.AccountType, (short)requestData.GraphType).Select(podatak => podatak.Label));
                    first = false;
                }
                var name = _municipalityService.GetMunicipality(MunicipalityId).MunicipalityName;
                var data = new List<decimal>();
                data.AddRange(_service.GetDataForMainPieChart(MunicipalityId, requestData.Year, requestData.AccountType, (short)requestData.GraphType).Select(podatak => podatak.Amount));

                //Ukinuti ako ne želimo prikazivati postotke već podatke
                var aditionalData = new List<decimal>(data);
                var empty = !UpdateListWithPercentage(ref data);

                //bool empty = CheckData(data);
                if (!empty)
                {
                    ret.Data.Add(new MunicipalityBudgetDataDTO() { Name = name, Data = data, AditionalData = aditionalData });
                }
                else
                {
                    ret.EmptyMunicipalities.Add(MunicipalityId);
                }
            }

            return Json(ret);
        }


        private JsonResult GetComparisonGraphData(BudgetDataRequestDTO requestData)
        {
            var ret = new GraphDataDTO();
            bool first = true;

            foreach (var MunicipalityId in requestData.MunicipalityIDs)
            {
                if (first)
                {
                    ret.BudgetLines.AddRange(_service.GetDataForMainPieChart(MunicipalityId, requestData.Year, requestData.AccountType, (short)requestData.GraphType).Select(podatak => podatak.Label));
                    first = false;
                }
                var name = _municipalityService.GetMunicipality(MunicipalityId).MunicipalityName;
                var dataPlanned = new List<decimal>();
                dataPlanned.AddRange(_service.GetDataForMainPieChart(MunicipalityId, requestData.Year, requestData.AccountType, (short)GraphType.PlannedBudgetPieChart).Select(podatak => podatak.Amount));

                var dataExecuted = new List<decimal>();
                dataExecuted.AddRange(_service.GetDataForMainPieChart(MunicipalityId, requestData.Year, requestData.AccountType, (short)GraphType.ExecutedBudgetPieChart).Select(podatak => podatak.Amount));
                bool empty = CheckData(dataPlanned) && CheckData(dataExecuted);
                if (!empty)
                {
                    ret.Data.Add(new MunicipalityBudgetDataDTO() { Name = name, Data = BudgetDifference(dataPlanned, dataExecuted) });
                }
                else
                {
                    ret.EmptyMunicipalities.Add(MunicipalityId);
                }
            }

            return Json(ret);
        }

        public JsonResult GetBudgetDataDifference(List<int> municipalityIds, int year, int accountTypeId)
        {
            return Json(_service.GetBudgetDataDifference(municipalityIds, year, accountTypeId));
        }

        private List<decimal> BudgetDifference(List<decimal> dataPlanned, List<decimal> dataExecuted)
        {
            if (dataPlanned.Count != dataExecuted.Count)
            {
                throw new ArgumentException("Input lists must have the same number of elements.");
            }

            return dataPlanned.Zip(dataExecuted, (planned, executed) => executed - planned).ToList();
        }

        private bool CheckData(List<decimal> data)
        {
            return data.All(item => item == 0);
        }

        private void CreateFilterDDLs(ref SearchBudgetDataComparisonDTO args)
        {
            args.Municipalities = _dropdownService.GetAllMunicipalities();
            args.Years = _dropdownService.GetBudgetDataYears();
        }

        public static bool UpdateListWithPercentage(ref List<decimal> list)
        {
            decimal totalSum = list.Sum();

            if (totalSum == 0)
            {
                // Handle the case where the sum is 0 to avoid division by zero.
                return false;
            }

            for (int i = 0; i < list.Count; i++)
            {
                list[i] = (list[i] / totalSum) * 100.0m;
            }

            return true;
        }
    }
}
