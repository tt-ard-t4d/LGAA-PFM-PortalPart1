﻿namespace PFMPortal.DTO.Municipality
{
    public class MunicipalitySlugDTO
    {
        public List<string>? Slugs { get; set; }
    }
}
