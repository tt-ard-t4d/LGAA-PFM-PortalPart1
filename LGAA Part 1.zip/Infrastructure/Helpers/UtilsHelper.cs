﻿using Ganss.Xss;
using System.Text.RegularExpressions;

namespace PFMPortal.Infrastructure.Helpers
{
    /// <summary>
    /// Dodati implementacije, provjeriti prvo
    /// </summary>
    public static class UtilsHelper
    {
        public static string GetSafeInput(string input)
        {
            if (!String.IsNullOrEmpty(input))
            {
                var safeInput = input;

                safeInput = Regex.Replace(safeInput, @"\=.*?cmd\b", "", RegexOptions.IgnoreCase);

                var sanitizer = new HtmlSanitizer();
                safeInput = sanitizer.Sanitize(safeInput);

                return safeInput;
            }

            return string.Empty;
        }

        public static (string? columnName, string? direction) GetSortOrder(string sort)
        {
            if (String.IsNullOrEmpty(sort)) return (null, null);
            var str = sort.Split("_");
            return ((str.Length > 0) ? str[0] : "", (str.Length > 0) ? str[1] : "");
        }
    }
}
