﻿using Domain.Entities.Utils;
using DTO.Utils;

namespace Infrastructure.Mappings.Utils
{
    public class AuditLogEnumerationMapper
    {
        public AuditLogEnumerationDTO MapAuditLogEnumeration(AuditLogEnumeration auditlogenum)
        {
            return new AuditLogEnumerationDTO()
            {
                AuditLogEnumerationID = auditlogenum.AuditLogEnumerationID,
                AuditLogEnumerationDescription = auditlogenum.AuditLogEnumerationDescription,
                AuditLogEnumerationText = auditlogenum.AuditLogEnumerationText,
                SysCreatedByUserID = auditlogenum.SysCreatedByUserID,
                SysLastModifiedByUserID = auditlogenum.SysLastModifiedByUserID,
                SysCreatedDate = auditlogenum.SysCreatedDate,
                SysLastModifiedDate = auditlogenum.SysLastModifiedDate
            };
        }

        public AuditLogEnumerationDTO MapAuditLogEnumeration()
        {
            return new AuditLogEnumerationDTO()
            {
                AuditLogEnumerationID = 0
            };
        }

        public AuditLogEnumeration MapAuditLogEnumeration(AuditLogEnumerationDTO auditlogenum)
        {
            return new AuditLogEnumeration()
            {
                AuditLogEnumerationID = auditlogenum.AuditLogEnumerationID,
                AuditLogEnumerationDescription = auditlogenum.AuditLogEnumerationDescription,
                AuditLogEnumerationText = auditlogenum.AuditLogEnumerationText,
                SysCreatedByUserID = auditlogenum.SysCreatedByUserID,
                SysLastModifiedByUserID = auditlogenum.SysLastModifiedByUserID,
                SysCreatedDate = auditlogenum.SysCreatedDate,
                SysLastModifiedDate = auditlogenum.SysLastModifiedDate
            };
        }
    }
}
