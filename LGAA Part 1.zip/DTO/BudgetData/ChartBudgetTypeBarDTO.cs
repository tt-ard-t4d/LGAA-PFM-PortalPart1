﻿namespace PFMPortal.DTO.BudgetData
{
    public class ChartBudgetTypeBarDTO
    {
        public string Label { get; set; } = string.Empty;
        public decimal PlannedAmount { get; set; }
        public decimal ExecutedAmount { get; set; }
        public int Id { get; set; }
    }
}
