﻿namespace PFMPortal.DTO.Utils
{
    public class SearchFileDTO : GridArgsDTO
    {
        public string SearchTerm { get; set; }
        public int FileTypeID { get; set; }
    }
}
