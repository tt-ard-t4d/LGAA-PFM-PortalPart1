﻿using Authorization;
using Microsoft.AspNetCore.Mvc;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Core.Utils;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;

namespace PFMPortal.Controllers.Utils
{
    [AuthorizeUserGroups(ActionManagementEnum.UserGroups.LGUAdministrator, ActionManagementEnum.UserGroups.SystemAdministrator)]
    public class FileUploadController : Controller
    {
        private readonly FileUploadService _fileUploadService;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public FileUploadController(FileUploadService fileUploadService, IHttpContextAccessor httpContextAccessor)
        {
            _fileUploadService = fileUploadService;
            _httpContextAccessor = httpContextAccessor;
        }

        public IActionResult Index()
        {
            var model = new FileUploadDTO();
            return View(model);
        }

        public IActionResult AddTempFileItems([FromForm] FileUploadData data)
        {
            _httpContextAccessor.HttpContext?.Request.Body.Seek(0, SeekOrigin.Begin);

            var files = _httpContextAccessor.HttpContext?.Request.Form.Files;

            if (files != null && files.Count > 0 && data.TypeId > 0)
            {
                Guid userId = User.Identity != null ? User.Identity.GetLoggedUserId() : Guid.Empty;

                var ret = _fileUploadService.SaveFilesToDBAndAzure(data.TypeId, userId, files, formId: data.Id);

                if (!ret.Ret.IsError)
                {
                    var res = Json(ret.Data);
                    return res;
                }

                return Json(ret.Ret);
            }

            return Json("{}");
        }

        [HttpPost]
        public IActionResult DeleteFormFile(int id)
        {
            return Json(_fileUploadService.DeleteFile(id));
        }
    }
}
