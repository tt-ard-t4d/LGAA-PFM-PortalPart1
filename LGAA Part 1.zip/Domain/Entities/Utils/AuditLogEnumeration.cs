﻿using PFMPortal.Domain.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Entities.Utils
{
    public class AuditLogEnumeration : SysEntity
    {
        public int AuditLogEnumerationID { get; set; }
        public string AuditLogEnumerationDescription { get; set; }
        public string AuditLogEnumerationText { get; set; }
    }
}
