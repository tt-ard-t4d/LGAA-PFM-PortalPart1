﻿namespace DTO.Utils
{
    public class AuditLogDTO
    {
        public int AuditLogID { get; set; }
        public string AuditLogText { get; set; }
        public int SysCreatedByUserID { get; set; }
        public DateTime SysDateCreated { get; set; }
        public int? SysModifiedByUserID { get; set; }
        public Nullable<DateTime> SysDateLastModified { get; set; }
        public long? RelatedItemID { get; set; }
        public int? AuditLogEnumerationID { get; set; }
    }
}
