﻿using PFMPortal.DTO.Utils;

namespace PFMPortal.DTO.Municipality
{
    public class BudgetDataEntryDTO
    {
        public List<ItemDDL> Years { get; set; } = new List<ItemDDL>();
    }
}
