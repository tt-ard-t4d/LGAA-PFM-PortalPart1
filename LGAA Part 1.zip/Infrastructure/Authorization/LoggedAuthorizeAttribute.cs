﻿

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Web;
using Infrastructure.Helpers;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Extensions;

namespace Authorization
{
    /// <summary>
    /// Base authorization if is not logged return user to login page
    /// </summary>
    public class LoggedAuthorizeAttribute : Attribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {
            if (!filterContext.HttpContext.Session.IsLoggedIn())
            {
                HandleUnauthorizedRequest(filterContext);
            }

            return;
        }

        protected  void HandleUnauthorizedRequest(AuthorizationFilterContext filterContext)
        {
            //filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "action", "Login" }, { "controller", "Login" } , { "url" , filterContext.HttpContext.Request.RawUrl.ToString() } });
            filterContext.Result = new RedirectResult("/Login/Login?url=" + HttpUtility.UrlEncode(filterContext.HttpContext.Request.GetDisplayUrl().ToString()));
        }
    }
}