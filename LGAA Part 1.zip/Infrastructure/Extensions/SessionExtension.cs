﻿using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;
using System.Text.Json;

namespace PFMPortal.Infrastructure.Extensions
{
    public static class SessionExtension
    {
        public static void SetValue<T>(this ISession session, string key, T value)
        {
            session.SetString(key, JsonSerializer.Serialize(value));
        }

        public static T? GetValue<T>(this ISession session, string key)
        {
            var value = session.GetString(key);
            return value == null ? default : JsonSerializer.Deserialize<T>(value);
        }

        public static bool IsLoggedIn(this ISession session)
        {
            bool? isLoggedIn = session.GetValue<bool>(SessionConstants.LoggedIn);

            if (!isLoggedIn.HasValue) return false;

            return isLoggedIn.Value;
        }

        public static bool CheckIsInAction(this ISession session, params ActionManagementEnum.ActionEnumeration[] allowedActions)
        {
            var currentUserActionIds = session.GetValue<List<UserDataAction>>(SessionConstants.Actions)?.Select(r => r.ActionID);
            var allowedActionIds = allowedActions.Select(r => (int)r).ToList();

            if (currentUserActionIds != null)
            {
                return allowedActionIds.Any(r => currentUserActionIds.Contains(r));
            }

            return false;
        }

        public static bool CheckIsInAction(this ISession session, params int[] allowedActions)
        {
            var currentUserActionIds = session.GetValue<List<UserDataAction>>(SessionConstants.Actions)?.Select(r => r.ActionID);
            var allowedActionIds = allowedActions.Select(r => (int)r).ToList();

            if (currentUserActionIds != null)
            {
                return allowedActionIds.Any(r => currentUserActionIds.Contains(r));
            }

            return false;
        }

        public static bool CheckIsInUserGroup(this ISession session, params ActionManagementEnum.UserGroups[] allowedGroups)
        {
            var currentUserGroupIds = session.GetValue<List<UserDataGroup>>(SessionConstants.UserGroups)?.Select(r => r.UserGroupID);
            var allowedGroupIds = allowedGroups.Select(r => (int)r).ToList();

            if (currentUserGroupIds != null)
            {
                return allowedGroupIds.Any(r => currentUserGroupIds.Contains(r));
            }

            return false;
        }

        public static bool CheckIsInUserGroup(this ISession session, params int[] allowedGroupsIds)
        {
            var attemptedGroupIds = session.GetValue<List<UserDataGroup>>(SessionConstants.UserGroups)?.Select(r => r.UserGroupID);

            if (attemptedGroupIds != null)
            {
                return allowedGroupsIds.Any(r => attemptedGroupIds.Contains(r));
            }

            return false;
        }

    }
}
