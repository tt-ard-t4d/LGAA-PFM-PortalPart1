﻿var app = app || {};

app.ddl = function () {
    /*
     url = data for drop down list
     parentName = name of parent ddl
     childDDL = ddl where we load data
     lstRemove = reset ddl's in this list
     */
    onChangeDDL = function (url, parentName, childName, lstForRemove) {
        app.utility.showLoader('body');

        var parentDDL = $(`#${parentName}`);
        var childDDL = $(`#${childName}`);
        let emptyText = $(`#${childName} option:first-child`).text();

        const parentId = parentDDL.val();
        const childId = childDDL.val();
        const data = {
            parentId: parentId
        }

        $.ajax({
            type: "POST",
            url: url,
            dataType: "json",
            data: data,
            success: function (data) {
                createDDL(childDDL, data, emptyText);
                clearDDL(lstForRemove);
                app.utility.hideLoader('body');
            },
            error: function (xhr, ajaxOptions, thrownError) {
                if (xhr.status === 404) {
                    app.utility.hideLoader('body');
                    alert(thrownError);
                }
            }
        });
    };

    var createDDL = function (ddl, data, emptyText, id = "0") {
        ddl.empty();
        var optionItems = `<option value="">${emptyText}</option>`;

        if (data.length > 0) {
            ddl.attr("disabled", false);
        } else {
            ddl.attr("disabled", true);
        }


        if (data) {
            for (var i = 0; i < data.length; i++) {
                let sel = (data[i].Id === id) ? "selected" : "";
                if (sel === "") {
                    optionItems += '<option value="' + data[i].id + '">' + data[i].code + ' - ' + data[i].value + '</option>';
                } else {
                    optionItems += '<option selected value="' + data[i].id + '">' + data[i].code + ' - ' + data[i].value + '</option>';
                }
            }

            ddl.append(optionItems);
            ddl.selectpicker('refresh');
            return;
        }
        ddl.selectpicker('refresh');
    };

    var clearDDL = function (ddls) {
        if (ddls) {
            for (var i = 0; i < ddls.length; i++) {
                let ddl = $(`#${ddls[i]}`);
                let emptyText = $(`#${ddls[i]} option:first-child`).text();
                ddl.empty();
                ddl.append(`<option value="">${emptyText}</option>`);
                ddl.selectpicker('refresh');
            }
        }
    };

    return {
        onChangeDDL: onChangeDDL
    }
}();
