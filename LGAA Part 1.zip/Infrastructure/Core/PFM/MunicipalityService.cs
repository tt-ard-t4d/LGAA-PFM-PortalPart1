﻿using PFMPortal.DTO.Admin;
using PFMPortal.DTO.Municipality;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Mappings;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Domain.Contracts.PFM;
using PFMPortal.Infrastructure.Mappings.PFM;
using Infrastructure.Helpers;
using PFMPortal.Infrastructure.Extensions;

namespace PFMPortal.Infrastructure.Core.PFM
{
    public class MunicipalityService
    {
        private readonly IMunicipalityRepository _repository;

        public MunicipalityService(IMunicipalityRepository municipalityRepository)
        {
            _repository = municipalityRepository;
        }

        public MunicipalityDTO GetMunicipality(int id)
        {
            var map = new MunicipalityMapper();
            var entity = _repository.GetMunicipalityById(id);

            return map.Map(entity);
        }

        public MunicipalityDTO GetRetiredMunicipality(int id)
        {
            var map = new MunicipalityMapper();
            var entity = _repository.GetRetiredMunicipality(id);

            return map.Map(entity);
        }

        public RetValue DeleteMunicipality(int id)
        {
            return _repository.DeleteMunicipality(id);
        }

        public GridDTO<MunicipalityGridDTO, SearchMunicipalityDTO> GetMunicipalityGrid(SearchMunicipalityDTO args, int pageNumber = Constants.DefaultPageNumber, int numberOfObjectsPerPage = Constants.NumberOfObjectsPerPage)
        {
            var ret = new GridDTO<MunicipalityGridDTO, SearchUserDTO>();
            (var retVal, var totalNumberOfRows) = _repository.GetMunicipalityGrid(args);
            var pager = new PageDTO(totalNumberOfRows, args.Page, numberOfObjectsPerPage);

            var map = new MunicipalityMapper();
            var paged = retVal.Page(numberOfObjectsPerPage, args.Page);
            var grid = paged.Select(c => map.MapGrid(c, totalNumberOfRows)).ToList();

            var gridMap = new GridMapper();
            return gridMap.MapGrid(grid, args, pager);
        }
        
        public List<MunicipalityGridDTO> GetMunicipalityHomeGrid()
        {
            var municipalities = _repository.GetAllMunicipalities();
            var map = new MunicipalityMapper();
            return municipalities.Select(c=> map.MapGrid(c, 1)).ToList();
        }



        public RetValue Save(MunicipalityEditDTO model, Guid loggedUserId)
        {
            var entity = _repository.GetRetiredMunicipality(model.MunicipalityID);

            if (entity == null) return new RetValue() { IsError = true, ErrorMessage = "JLS ne postoji u sistemu" };

            entity.Retired = false;
            entity.SysLastModifiedByUserID = loggedUserId;
            entity.SysLastModifiedDate = DateTime.Now;

            return _repository.Save(entity);
        }

        public (List<MunicipalityDTO>, int) GetMunicipalitiesWithoutEntries(int year)
        {
            var map = new MunicipalityMapper();

            var res = _repository.GetMunicipalitiesWithoutEntries(year);

            return (res.Item1.Select(r => map.Map(r)).ToList(), res.Item2);
        }

        public List<int> GetYearsWithData(int municipalityId)
        {
            return _repository.GetYearsWithData(municipalityId);
        }

        public List<MunicipalityDTO> GetMunicipalitiesForUser(Guid userId)
        {
            var res = _repository.GetMunicipalitiesForUser(userId);

            var map = new MunicipalityMapper();

            return res.Select(r => map.Map(r)).ToList();
        }
    }
}
