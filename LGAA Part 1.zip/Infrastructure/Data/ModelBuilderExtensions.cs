﻿using Authorization;
using Domain.Entities.Utils;
using Infrastructure.Helpers;
using Microsoft.EntityFrameworkCore;
using MimeKit.Utils;
using PFMPortal.Domain.Entities;
using PFMPortal.Domain.Entities.App;
using System.Reflection.Emit;
using Action = PFMPortal.Domain.Entities.Action;

namespace PFMPortal.Infrastructure.Data
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder builder)
        {
            var currentDate = new DateTime(2024, 1, 1, 0, 0, 0);
            builder.Entity<UserGroup>(ur =>
            {
                ur.HasData(
                    new UserGroup() { UserGroupID = 1, Name = "System Administrator", SysCreatedDate = currentDate, SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), Retired = false },
                    new UserGroup() { UserGroupID = 2, Name = "LGU Administrator", SysCreatedDate = currentDate, SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), Retired = false }
                );
            });

            builder.Entity<Action>(ur =>
            {
                ur.HasData(
                    new Action { ActionID = 1, ActionName = "Create User", ActionEnumerationName = "ADMIN_USER_CREATE", Description = "", Retired = false, SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), SysCreatedDate = currentDate },
                    new Action { ActionID = 2, ActionName = "View User", ActionEnumerationName = "ADMIN_USER_READ", Description = "", Retired = false, SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), SysCreatedDate = currentDate },
                    new Action { ActionID = 3, ActionName = "Edit User", ActionEnumerationName = "ADMIN_USER_EDIT", Description = "", Retired = false, SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), SysCreatedDate = currentDate },
                    new Action { ActionID = 4, ActionName = "Delete User", ActionEnumerationName = "ADMIN_USER_DELETE", Description = "", Retired = false, SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), SysCreatedDate = currentDate },
                    new Action { ActionID = 5, ActionName = "Users Overview", ActionEnumerationName = "ADMIN_USERS_OVERVIEW", Description = "", Retired = false, SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), SysCreatedDate = currentDate }
                );
            });

            builder.Entity<UserGroupActionRel>(ur =>
            {
                ur.HasData(
                    new UserGroupActionRel { UserGroupAndActionID = 1, UserGroupID = 1, ActionID = 1, Retired = false },
                    new UserGroupActionRel { UserGroupAndActionID = 2, UserGroupID = 1, ActionID = 2, Retired = false },
                    new UserGroupActionRel { UserGroupAndActionID = 3, UserGroupID = 1, ActionID = 3, Retired = false },
                    new UserGroupActionRel { UserGroupAndActionID = 4, UserGroupID = 1, ActionID = 4, Retired = false },
                    new UserGroupActionRel { UserGroupAndActionID = 5, UserGroupID = 1, ActionID = 5, Retired = false }
                );
            });

            builder.Entity<UserActionRel>(ur =>
            {
                ur.HasData(
                    new UserActionRel { UserAndActionID = 1, UserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), ActionID = 5 },
                    new UserActionRel { UserAndActionID = 2, UserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), ActionID = 4 }
                );
            });

            builder.Entity<User>().HasData(
                new User()
                {
                    UserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    FirstNameEnc = "vOIUBnFT5Y809QUJqH4AzQ==",
                    LastNameEnc = "vOIUBnFT5Y809QUJqH4AzQ==",
                    UserNameEnc = "1/ZVbp32LhD77H7MGNgKmw==",
                    EmailEnc = "St6/v49lrqKXW5W7ytqLHA==",
                    PasswordHash = "B93ACCB02E0366BFF97B511D7816AC2D731709E826AFCB1055EAFE8A147F6A903A8AE9D53BFC22BD30A30D0510221B2F70F46EF0960BB51F7CF12D2B59A818D3",
                    PasswordSalt = "kfOdYzluTdhj0qr452F0eyDISySC70ef7jLPEt8ZI5OFQEHTkY12cKZC7go71lYkRcJbV/jEWKGVpQJCsWWk/A==",
                    SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    EmailCode = Guid.Empty,
                    SysCreatedDate = currentDate,
                    ValidFrom = currentDate,
                    ValidTo = currentDate.AddDays(100000),
                    LanguageId = 1
                }
            );

            builder.Entity<UserGroupUserRel>().HasData(
                new UserGroupUserRel()
                {
                    UserAndGroupID = 1,
                    UserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                    UserGroupID = 1,
                    Retired = false
                }
            );


            builder.Entity<EmailNotification>().HasData(
                new EmailNotification()
                {
                    EmailNotificationID = (int)GlobalEnum.Email.EmailPasswordSetup,
                    EmailDescription = "EmailPasswordSetup",
                    EmailSubject = "Setup your password",
                    EmailText = "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n        /* Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Dear <Name> ,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    You have been added as user on the system. \r\n                                                    <br>\r\n                                                    Your username is: <b> <Username> </b> .\r\n                                                    \r\n                                                    <br>\r\n                                                    <br>\r\n                                                    We kindly ask you that by clicking on the following link <ConfirmationLink> , you choose the password for using the system.\r\n                                                    <br>\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>",
                    SysDateCreated = currentDate,
                    SysCreatedByUserID = 1,
                    EmailStatus = (short)GlobalEnum.EmailStatus.Developer
                },
                new EmailNotification()
                {
                    EmailNotificationID = (int)GlobalEnum.Email.EmailPasswordReset,
                    EmailDescription = "EmailPasswordReset",
                    EmailSubject = "Reset your password",
                    EmailText = "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n            /*\r\n                                  Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Dear <Name> ,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    To change your password, click on the following link: <ConfirmationLink>\r\n                                                    <br>\r\n                                                    Your username is: <Username> .\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>",
                    SysDateCreated = currentDate,
                    SysCreatedByUserID = 1,
                    EmailStatus = (short)GlobalEnum.EmailStatus.Developer
                }
            );

            builder.Entity<AuditLogEnumeration>().HasData(
              new AuditLogEnumeration
              {
                  AuditLogEnumerationID = 1,
                  AuditLogEnumerationDescription = "Log-in",
                  AuditLogEnumerationText = "User <username> logged in.",
                  SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                  SysCreatedDate = currentDate,
                  SysLastModifiedByUserID = null,
                  SysLastModifiedDate = null,
                  Retired = false
              },
               new AuditLogEnumeration
               {
                   AuditLogEnumerationID = 2,
                   AuditLogEnumerationDescription = "Log-out",
                   AuditLogEnumerationText = "User <username> logged out.",
                   SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                   SysCreatedDate = currentDate,
                   SysLastModifiedByUserID = null,
                   SysLastModifiedDate = null,
                   Retired = false
               },
               new AuditLogEnumeration
               {
                   AuditLogEnumerationID = 3,
                   AuditLogEnumerationDescription = "User registration",
                   AuditLogEnumerationText = "User <username> has been registered.",
                   SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                   SysCreatedDate = currentDate,
                   SysLastModifiedByUserID = null,
                   SysLastModifiedDate = null,
                   Retired = false
               },
               new AuditLogEnumeration
               {
                   AuditLogEnumerationID = 4,
                   AuditLogEnumerationDescription = "User creation",
                   AuditLogEnumerationText = "User <username> has been created.",
                   SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                   SysCreatedDate = currentDate,
                   SysLastModifiedByUserID = null,
                   SysLastModifiedDate = null,
                   Retired = false
               },
               new AuditLogEnumeration
               {
                   AuditLogEnumerationID = 5,
                   AuditLogEnumerationDescription = "Email notifications sent",
                   AuditLogEnumerationText = "Email notification <emailNotificationName> has been sent to <username>.",
                   SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                   SysCreatedDate = currentDate,
                   SysLastModifiedByUserID = null,
                   SysLastModifiedDate = null,
                   Retired = false
               },
               new AuditLogEnumeration
               {
                   AuditLogEnumerationID = 6,
                   AuditLogEnumerationDescription = "Forgotten password reset",
                   AuditLogEnumerationText = "User <username> requested password reset.",
                   SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                   SysCreatedDate = currentDate,
                   SysLastModifiedByUserID = null,
                   SysLastModifiedDate = null,
                   Retired = false
               }
            );
        }


        public static void SeedPFMData(this ModelBuilder builder)
        {

            var defaultUserId = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f");
            var currentDate = new DateTime(2024, 1, 1, 0, 0, 0);
            var defaultCreateDate = currentDate;

            #region Entities
            builder.Entity<Entity>().HasData(

                    new Entity()
                    {
                        EntityID = 1,
                        EntityName = "Federacija Bosne i Hercegovine",
                        Retired = false
                    },
                    new Entity()
                    {
                        EntityID = 2,
                        EntityName = "Republika Srpska",
                        Retired = false
                    }
                );
            #endregion

            #region LGU types
            builder.Entity<LocalGovernmentUnit>().HasData(

                    new LocalGovernmentUnit()
                    {
                        LocalGovernmentUnitID = 1,
                        LocalGovernmentUnitName = "Općina"
                    },
                    new LocalGovernmentUnit()
                    {
                        LocalGovernmentUnitID = 2,
                        LocalGovernmentUnitName = "Grad"
                    }
                );
            #endregion

            #region Account types
            builder.Entity<AccountType>().HasData(

                   new AccountType()
                   {
                       AccountTypeID = 1,
                       AccountTypeName = "Budžetski prihodi",
                       Retired = false
                   },
                   new AccountType()
                   {
                       AccountTypeID = 2,
                       AccountTypeName = "Budžetski rashodi",
                       Retired = false
                   }
               );
            #endregion

            #region Account Categories

            builder.Entity<AccountCategory>().HasData(

                new AccountCategory()
                {
                    AccountCategoryID = 1,
                    AccountCategoryName = "Prihodi od poreza",
                    Information = "Čine ih prihodi na dobit i dohodak od pojedinca i preduzeća koji posluju na teritoriji lokalne uprave, porez na imovinu, te indirektni porezi koji pripadaju lokalnoj upravi",
                    AccountTypeID = 1,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 2,
                    AccountCategoryName = "Neporezni prihodi",
                    Information = "Najčešće se sastoje od administrativnih taksi i naknada na lokalnom nivou, komunalnih taksi i naknada, naknada za date koncesije na području lokalne uprave, naknada od rente, naknada od prometa šumom, prihoda od davanja prava na eksploataciji prirodnih resursa, vodne naknade, naknada za zaštitu prirodnih i drugih nesreća, novčanih kaznih, naknada za upotrebu cesta za vozila, sredstava za finansiranje požara, prihoda od pružanja usluga i slično.",
                    AccountTypeID = 1,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 3,
                    AccountCategoryName = "Tekući transferi i donacije",
                    Information = "Uključuju novčane transfere sa viših nivoa vlasti vezano za različita davanja pojedincima, javnim ustanovama, neprofitnim i nevladinim organizacijama i udruženjima registrovanim na području lokalne uprave.",
                    AccountTypeID = 1,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 4,
                    AccountCategoryName = "Kapitalni transferi",
                    Information = "Novčane pomoći sa viših nivoa vlasti vezani za dugoročne/ višegodišnje projekte i davanja na području lokalne uprave.",
                    AccountTypeID = 1,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 5,
                    AccountCategoryName = "Kapitalni primici",
                    Information = "Sredstva dobijena prodajom stalne imovine kao što je zemljište, stambeni objekti i finansijska imovina.",
                    AccountTypeID = 1,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 6,
                    AccountCategoryName = "Krediti",
                    Information = "Sredstva iz finansijskih zaduživanja.",
                    AccountTypeID = 1,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 7,
                    AccountCategoryName = "Suficit prethodnih godina",
                    Information = "Ukoliko postoje, ovo su neutrošena sredstva iz prethodnih godina koja se prenose u tekuću budžetsku godinu, te time povećavaju prihodovnu stranu budžeta.",
                    AccountTypeID = 1,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 8,
                    AccountCategoryName = "Plate i naknade zaposlenih",
                    Information = "Sredstva za plate, naknade, doprinose zaposlenih u lokalnim upravama i organima javnih institucija na području lokalne uprave.",
                    AccountTypeID = 2,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 9,
                    AccountCategoryName = "Materijalni troškovi",
                    Information = "Najčešće se sastoje od administrativnih taksi i naknada, izdataka za energiju, prevoz i komunikaciju, troškova održavanja, troškova učešća u zajedničkim projektima od značaja za lokalnu upravu, sredstava za zaštitu od prirodnih i drugih nesreća, nakada za rad mjesnih zajednica, sredstava za zaštitu od požara, rashodi po osnovu putovanja i smještaja i slično.",
                    AccountTypeID = 2,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 10,
                    AccountCategoryName = "Komunalne usluge",
                    Information = "Sredstva za održavanje cesta i puteva, javne rasvjete, zelenih površina, rada zimske službe, održavanje i sanacije vodovodne i kanalizacione mreže, zbrinjavanja pasa lutalica, i slično.",
                    AccountTypeID = 2,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 11,
                    AccountCategoryName = "Tekući transferi",
                    Information = "Pokrivaju jednokratna davanja javnim ustanovama na području lokalne uprave, izdatke za sport i kulturu, troškove prevoza učenika, različita socijalna davanja, stipendije nadarenim učenicima i sportistima, subvencije poljoprivredi, malom biznisu i poduzetništvu, transfere nevladinom sektoru, boračkoj populaciji i projektima od važnosti za mlade.",
                    AccountTypeID = 2,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 12,
                    AccountCategoryName = "Kapitalni transferi",
                    Information = "Odnose se na kapitalne doznake i pomoći lokalnoj upravi, neprofitnim organizacijama i pojedincima, te javnim preduzećima.",
                    AccountTypeID = 2,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 13,
                    AccountCategoryName = "Kapitalni izdaci",
                    Information = "Sredstva za izgradnju putne, vodovodne i kanalizacione infrastrukture, izgradnje objekata od važnosti za funkcionisanje lokalne uprave, sportsko-rekreativnih kapaciteta, objekata od kulturno-historijskog značaja, unapređenja javne rasvjete, izgradnju grobalja, poslovnih zona i slično.",
                    AccountTypeID = 2,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 14,
                    AccountCategoryName = "Otplate duga",
                    Information = "Otplata duga jedinice lokalne samouprave",
                    AccountTypeID = 2,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 15,
                    AccountCategoryName = "Tekuća rezerva",
                    Information = "Tekuća rezerva jedinice lokalne samouprave",
                    AccountTypeID = 2,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 16,
                    AccountCategoryName = "Raspored akumulisanog suficita",
                    Information = "Suficit (neutrošena sredstva) jedinice lokalne samouprave",
                    AccountTypeID = 2,
                    EntityID = 1,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 17,
                    AccountCategoryName = "Prihodi od poreza",
                    Information = "Čine ih prihodi na dobit i dohodak od pojedinca i preduzeća koji posluju na teritoriji lokalne uprave, porez na imovinu, te indirektni porezi koji pripadaju lokalnoj upravi.",
                    AccountTypeID = 1,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 18,
                    AccountCategoryName = "Neporeski prihodi",
                    Information = "Najčešće se sastoje od administrativnih taksi i naknada na lokalnom nivou, komunalnih taksi i naknada, naknada za date koncesije na području lokalne uprave, naknada od rente, naknada od prometa šumom, prihoda od davanja prava na eksploataciji prirodnih resursa, vodne naknade, naknada za zaštitu prirodnih i drugih nesreća, novčanih kaznih, naknada za upotrebu cesta za vozila, sredstava za finansiranje požara, prihoda od pružanja usluga i slično.",
                    AccountTypeID = 1,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 19,
                    AccountCategoryName = "Grantovi i transferi",
                    Information = "Uključuju novčane transfere sa viših nivoa vlasti vezano za različita davanja pojedincima, javnim ustanovama, neprofitnim i nevladinim organizacijama i udruženjima registrovanim na području lokalne uprave.",
                    AccountTypeID = 1,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 20,
                    AccountCategoryName = "Kapitalni grantovi",
                    Information = "Novčane pomoći sa viših nivoa vlasti vezani za dugoročne/ višegodišnje projekte i davanja na području lokalne uprave.",
                    AccountTypeID = 1,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 21,
                    AccountCategoryName = "Finansiranje",
                    Information = "Sredstva dobijena prodajom stalne imovine kao što je zemljište, stambeni objekti i finansijska imovina",
                    AccountTypeID = 1,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 22,
                    AccountCategoryName = "Primici od finansijske imovine i zaduživanja",
                    Information = "Sredstva iz finansijskih zaduživanja.",
                    AccountTypeID = 1,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 23,
                    AccountCategoryName = "Raspodjela suficita iz prethodnih godina",
                    Information = "Ukoliko postoje, ovo su neutrošena sredstva iz prethodnih godina koja se prenose u tekuću budžetsku godinu, te time povećavaju prihodovnu stranu budžeta.",
                    AccountTypeID = 1,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 24,
                    AccountCategoryName = "Rashodi na lična primanja",
                    Information = "Sredstva za plate, naknade, doprinose zaposlenih u lokalnim upravama i organima javnih institucija na području lokalne uprave.",
                    AccountTypeID = 2,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 25,
                    AccountCategoryName = "Rashodi po osnovu korištenja roba i usluga",
                    Information = "Najčešće se sastoje od administrativnih taksi i naknada, izdataka za energiju, prevoz i komunikaciju, troškova održavanja, troškova učešća u zajedničkim projektima od značaja za lokalnu upravu, sredstava za zaštitu od prirodnih i drugih nesreća, nakada za rad mjesnih zajednica, sredstava za zaštitu od požara, rashodi po osnovu putovanja i smještaja i slično.",
                    AccountTypeID = 2,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 26,
                    AccountCategoryName = "Komunalne usluge",
                    Information = "Sredstva za održavanje cesta i puteva, javne rasvjete, zelenih površina, rada zimske službe, održavanje i sanacije vodovodne i kanalizacione mreže, zbrinjavanja pasa lutalica, i slično.",
                    AccountTypeID = 2,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 27,
                    AccountCategoryName = "Tekući grantovi, subvencije i transferi",
                    Information = "Pokrivaju jednokratna davanja javnim ustanovama na području lokalne uprave, izdatke za sport i kulturu, troškove prevoza učenika, različita socijalna davanja, stipendije nadarenim učenicima i sportistima, subvencije poljoprivredi, malom biznisu i poduzetništvu, transfere nevladinom sektoru, boračkoj populaciji i projektima od važnosti za mlade.",
                    AccountTypeID = 2,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 28,
                    AccountCategoryName = "Kapitalni grantovi i doznake",
                    Information = "Odnose se na kapitalne doznake i pomoći lokalnoj upravi, neprofitnim organizacijama i pojedincima, te javnim preduzećima.",
                    AccountTypeID = 2,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 29,
                    AccountCategoryName = "Izdaci za nefinansijsku imovinu",
                    Information = "Sredstva za izgradnju putne, vodovodne i kanalizacione infrastrukture, izgradnje objekata od važnosti za funkcionisanje lokalne uprave, sportsko-rekreativnih kapaciteta, objekata od kulturno-historijskog značaja, unapređenja javne rasvjete, izgradnju grobalja, poslovnih zona i slično",
                    AccountTypeID = 2,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 30,
                    AccountCategoryName = "Izdaci za finansijsku imovinu i otplate dugova",
                    Information = "Izdaci za finansijsku imovinu i otplate dugova jedinice lokalne samopurave",
                    AccountTypeID = 2,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 31,
                    AccountCategoryName = "Budžetska rezerva",
                    Information = "Budžetska rezerva jedinice lokalne samopurave",
                    AccountTypeID = 2,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                },
                new AccountCategory()
                {
                    AccountCategoryID = 32,
                    AccountCategoryName = "Raspored akumulisanog suficita",
                    Information = "Suficit (neutrošena sredstva) jedinice lokalne samopurave",
                    AccountTypeID = 2,
                    EntityID = 2,
                    SysCreatedByUserID = defaultUserId,
                    SysCreatedDate = defaultCreateDate,
                    Retired = false
                }
            );
            #endregion

            #region Budget positions
            builder.Entity<BudgetPosition>().HasData(

                    new BudgetPosition()
                    {
                        BudgetPositionID = 1,
                        BudgetPositionName = "Porez na dobit i dohodak",
                        AccountCategoryID = 1,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 2,
                        BudgetPositionName = "Porez na imovinu",
                        AccountCategoryID = 1,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 3,
                        BudgetPositionName = "Indirektni porezi",
                        AccountCategoryID = 1,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 130,
                        BudgetPositionName = "Zaostale uplate poreza",
                        AccountCategoryID = 1,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 4,
                        BudgetPositionName = "Administrativne takse i naknade",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 5,
                        BudgetPositionName = "Komunalne takse i naknade",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 6,
                        BudgetPositionName = "Naknade na date koncesije",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 7,
                        BudgetPositionName = "Naknade od rente",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 8,
                        BudgetPositionName = "Naknada na promet šuma",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 9,
                        BudgetPositionName = "Prihodi od davanja prava na eksploataciju prirodnih resursa, patenata i autorskih prava",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 10,
                        BudgetPositionName = "Naknada za zaštitu od prirodnih i drugih nesreća",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 11,
                        BudgetPositionName = "Novčane kazne",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 12,
                        BudgetPositionName = "Naknade za upotrebu cesta za vozila građana",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 13,
                        BudgetPositionName = "Sredstva za finansiranje zaštite od požara",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 14,
                        BudgetPositionName = "Prihodi od pružanja javnih usluga",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 15,
                        BudgetPositionName = "Ostalo",
                        AccountCategoryID = 2,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 16,
                        BudgetPositionName = "Tekući transferi i donacije",
                        AccountCategoryID = 3,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 17,
                        BudgetPositionName = "Kapitalni transferi",
                        AccountCategoryID = 4,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 18,
                        BudgetPositionName = "Primici od prodaje stalnih sredstava",
                        AccountCategoryID = 5,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 19,
                        BudgetPositionName = "Ostali kapitalni primici",
                        AccountCategoryID = 5,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 20,
                        BudgetPositionName = "Krediti",
                        AccountCategoryID = 6,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 21,
                        BudgetPositionName = "Suficit prethodnih godina",
                        AccountCategoryID = 7,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 22,
                        BudgetPositionName = "Plate i naknade zaposlenih",
                        AccountCategoryID = 8,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 23,
                        BudgetPositionName = "Administrativne takse i naknade",
                        AccountCategoryID = 9,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 24,
                        BudgetPositionName = "Izdaci za enargiju, prevoz i komunikaciju",
                        AccountCategoryID = 9,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 25,
                        BudgetPositionName = "Troškovi održavanja",
                        AccountCategoryID = 9,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 26,
                        BudgetPositionName = "Učešće u zajedničkim projektima",
                        AccountCategoryID = 9,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 27,
                        BudgetPositionName = "Sredstva za zaštitu od prirodnih i drugih nepogoda",
                        AccountCategoryID = 9,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 28,
                        BudgetPositionName = "Nakade radu MZ",
                        AccountCategoryID = 9,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 29,
                        BudgetPositionName = "Sredstva za zaštitu od požara",
                        AccountCategoryID = 9,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 30,
                        BudgetPositionName = "Sredstva za zaštitu okoliša",
                        AccountCategoryID = 9,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 31,
                        BudgetPositionName = "Ostali materijalni troškovi",
                        AccountCategoryID = 9,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 32,
                        BudgetPositionName = "Održavanje cesta i puteva",
                        AccountCategoryID = 10,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 33,
                        BudgetPositionName = "Javna rasvjeta",
                        AccountCategoryID = 10,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 34,
                        BudgetPositionName = "Održavanje zelenih površina",
                        AccountCategoryID = 10,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 35,
                        BudgetPositionName = "Rad zimske službe",
                        AccountCategoryID = 10,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 36,
                        BudgetPositionName = "Održavanje i saniranje vodovoda i kanalizacije",
                        AccountCategoryID = 10,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 37,
                        BudgetPositionName = "Zbrinjavanje pasa lutalica",
                        AccountCategoryID = 10,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 38,
                        BudgetPositionName = "Ostalo",
                        AccountCategoryID = 10,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 39,
                        BudgetPositionName = "Tekući transferi javnim ustanovama i javnim preduzećima",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 40,
                        BudgetPositionName = "Izdaci za sportske aktivnosti",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 41,
                        BudgetPositionName = "Izdaci za kulturu",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 42,
                        BudgetPositionName = "Troškovi prevoza učenika",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 43,
                        BudgetPositionName = "Socijalna davanja",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 44,
                        BudgetPositionName = "Stipendije učenicima i sportistima",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 45,
                        BudgetPositionName = "Poticaji poljoprivrede",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 46,
                        BudgetPositionName = "Poticaj razvoja malog biznisa i poduzetništva",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 47,
                        BudgetPositionName = "Transferi za OCD",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 48,
                        BudgetPositionName = "Naknade za porodilje",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 49,
                        BudgetPositionName = "Transferi boračkoj populaciji",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 50,
                        BudgetPositionName = "Transferi za omladinske aktivnosti",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 51,
                        BudgetPositionName = "Kapitalni transferi",
                        AccountCategoryID = 12,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 52,
                        BudgetPositionName = "Izgradnja putne infrastrukture",
                        AccountCategoryID = 13,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 53,
                        BudgetPositionName = "Izgradnja vodovodne i kanalizacione infrastrukture",
                        AccountCategoryID = 13,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 54,
                        BudgetPositionName = "Izgradnja objekata od važnosti za rad JLU",
                        AccountCategoryID = 13,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 55,
                        BudgetPositionName = "Izgradnja sportskih i rekreativnih objekata",
                        AccountCategoryID = 13,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 56,
                        BudgetPositionName = "Izgradnja objekata od kulturno-historijskog značaja",
                        AccountCategoryID = 13,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 57,
                        BudgetPositionName = "Izgradnja javne rasvjete",
                        AccountCategoryID = 13,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 58,
                        BudgetPositionName = "Izgradnja i proširenje grobalja",
                        AccountCategoryID = 13,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 59,
                        BudgetPositionName = "Izgradnja poslovnih zona",
                        AccountCategoryID = 13,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 60,
                        BudgetPositionName = "Otplate duga",
                        AccountCategoryID = 14,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 61,
                        BudgetPositionName = "Tekuća rezerva",
                        AccountCategoryID = 15,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 62,
                        BudgetPositionName = "Raspored akumulisanog suficita",
                        AccountCategoryID = 16,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 63,
                        BudgetPositionName = "Porez na dohodak, dobit i lična primanja",
                        AccountCategoryID = 17,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 64,
                        BudgetPositionName = "Porez na imovinu",
                        AccountCategoryID = 17,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 65,
                        BudgetPositionName = "Indirektni porezi doznačeni od UIO",
                        AccountCategoryID = 17,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 66,
                        BudgetPositionName = "Ostali poreski prihodi",
                        AccountCategoryID = 17,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 67,
                        BudgetPositionName = "Opštinske administrativne takse",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 68,
                        BudgetPositionName = "Komunalne takse",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 69,
                        BudgetPositionName = "Naknada za uređenje građevinskog zemljišta",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 70,
                        BudgetPositionName = "Naknade za razvoj nerazvijenih dijelova opštine",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 71,
                        BudgetPositionName = "Nakada za promet šuma",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 72,
                        BudgetPositionName = "Prihodi od davanja prava na eksploataciju prirodnih resursa, patenata i autorskih prava",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 73,
                        BudgetPositionName = "Naknada za zaštitu od prirodnih i drugih nesreća",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 74,
                        BudgetPositionName = "Novčane kazne",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 75,
                        BudgetPositionName = "Naknade za korištenje puteva",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 76,
                        BudgetPositionName = "Sredstva za finansiranje zaštite od požara",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 77,
                        BudgetPositionName = "Naknade za vodu",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 78,
                        BudgetPositionName = "Prihodi od pružanja javnih usluga",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 79,
                        BudgetPositionName = "Ostali neporeski prihodi",
                        AccountCategoryID = 18,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 80,
                        BudgetPositionName = "Grantovi i transferi",
                        AccountCategoryID = 19,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 81,
                        BudgetPositionName = "Kapitalni grantovi",
                        AccountCategoryID = 20,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 82,
                        BudgetPositionName = "Primici od prodaje stalne imovine",
                        AccountCategoryID = 21,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 83,
                        BudgetPositionName = "Ostali primici",
                        AccountCategoryID = 21,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 84,
                        BudgetPositionName = "Primici od finansijske imovine i zaduživanja",
                        AccountCategoryID = 22,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 85,
                        BudgetPositionName = "Raspodjela suficita iz prethodnih godina",
                        AccountCategoryID = 23,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 86,
                        BudgetPositionName = "Rashodi na lična primanja",
                        AccountCategoryID = 24,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 87,
                        BudgetPositionName = "Rashodi po osnovu zakupa",
                        AccountCategoryID = 25,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 88,
                        BudgetPositionName = "Izdaci za energiju, prevoz i komunikaciju",
                        AccountCategoryID = 25,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 89,
                        BudgetPositionName = "Troškovi održavanja - režije",
                        AccountCategoryID = 25,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 90,
                        BudgetPositionName = "Sredstva za održavanje životne sredine",
                        AccountCategoryID = 25,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 91,
                        BudgetPositionName = "Nakade radu MZ",
                        AccountCategoryID = 25,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 92,
                        BudgetPositionName = "Sredstva za zaštitu od požara",
                        AccountCategoryID = 25,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 93,
                        BudgetPositionName = "Rashodi po osnovu putovanja i smještaja",
                        AccountCategoryID = 25,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 94,
                        BudgetPositionName = "Sredstva za zaštitu okoliša",
                        AccountCategoryID = 25,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 95,
                        BudgetPositionName = "Ostali rashodi",
                        AccountCategoryID = 25,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 96,
                        BudgetPositionName = "Održavanje cesta i puteva",
                        AccountCategoryID = 26,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 97,
                        BudgetPositionName = "Javna rasvjeta",
                        AccountCategoryID = 26,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 98,
                        BudgetPositionName = "Održavanje zelenih površina",
                        AccountCategoryID = 26,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 99,
                        BudgetPositionName = "Rad zimske službe",
                        AccountCategoryID = 26,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 100,
                        BudgetPositionName = "Održavanje i saniranje vodovoda i kanalizacije",
                        AccountCategoryID = 26,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 101,
                        BudgetPositionName = "Zbrinjavanje pasa lutalica",
                        AccountCategoryID = 26,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 102,
                        BudgetPositionName = "Ostalo",
                        AccountCategoryID = 26,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 103,
                        BudgetPositionName = "Subvencije javnim nefinansijskim subjektima",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 104,
                        BudgetPositionName = "Izdaci za sportske aktivnosti",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 105,
                        BudgetPositionName = "Izdaci za kulturu",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 106,
                        BudgetPositionName = "Troškovi prevoza učenika",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 107,
                        BudgetPositionName = "Socijalna davanja",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 108,
                        BudgetPositionName = "Stipendije učenicima i sportistima",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 109,
                        BudgetPositionName = "Subvencije za poljoprivredu",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 110,
                        BudgetPositionName = "Subvencije za razvoj malog biznisa i preduzetništva",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 111,
                        BudgetPositionName = "Transferi nevladinim organizacijama",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 112,
                        BudgetPositionName = "Subvencije za porodilje",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 113,
                        BudgetPositionName = "Transferi boračkoj populaciji",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 114,
                        BudgetPositionName = "Transferi za omladinske aktivnosti",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 115,
                        BudgetPositionName = "Ostali grantovi, transferi, subvencije",
                        AccountCategoryID = 27,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 116,
                        BudgetPositionName = "Kapitalni grantovi i doznake",
                        AccountCategoryID = 28,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 117,
                        BudgetPositionName = "Izdaci za nabavku postojenja i opreme za obrazovanje, nauku, kulturu i sport",
                        AccountCategoryID = 29,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 118,
                        BudgetPositionName = "Izdaci za nabavku prevoznih sredstava",
                        AccountCategoryID = 29,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 119,
                        BudgetPositionName = "Izdaci za izgradnju i pribavljanje stambenih objekata",
                        AccountCategoryID = 29,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 120,
                        BudgetPositionName = "Izgradnja i održavanje vodovodne i kanalizacione infrastrukture",
                        AccountCategoryID = 29,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 121,
                        BudgetPositionName = "Izgradnja i održavanje saobraćajnih objekata",
                        AccountCategoryID = 29,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 122,
                        BudgetPositionName = "Izgradnja i održavanje sportskih i rekreativnih objekata",
                        AccountCategoryID = 29,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 123,
                        BudgetPositionName = "Izgradnja i održavanje objekata od kulturno-historijskog značaja",
                        AccountCategoryID = 29,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 124,
                        BudgetPositionName = "Izgradnja i održavanje javne rasvjete",
                        AccountCategoryID = 29,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 125,
                        BudgetPositionName = "Izgradnja i proširenje grobalja",
                        AccountCategoryID = 29,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 126,
                        BudgetPositionName = "Ostali nefinansijski izdaci",
                        AccountCategoryID = 29,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 127,
                        BudgetPositionName = "Izdaci za finansijsku imovinu i otplate dugova",
                        AccountCategoryID = 30,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 128,
                        BudgetPositionName = "Budžetska rezerva",
                        AccountCategoryID = 31,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 129,
                        BudgetPositionName = "Raspored akumulisanog suficita",
                        AccountCategoryID = 32,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 132,
                        BudgetPositionName = "Ostalo",
                        AccountCategoryID = 11,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    },
                    new BudgetPosition()
                    {
                        BudgetPositionID = 133,
                        BudgetPositionName = "Ostalo",
                        AccountCategoryID = 13,
                        Archived = false,
                        SysCreatedByUserID = defaultUserId,
                        SysCreatedDate = defaultCreateDate,
                        Retired = false
                    }
                );
            #endregion

            #region Municipalities
            builder.Entity<Municipality>().HasData(
                    new Municipality()
                    {
                        MunicipalityID = 1,
                        EntityID = 2,
                        Slug = "trebinje",
                        MunicipalityName = "Trebinje",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 2,
                        EntityID = 2,
                        Slug = "bileca",
                        MunicipalityName = "Bileća",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 3,
                        EntityID = 2,
                        Slug = "ljubinje",
                        MunicipalityName = "Ljubinje",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 4,
                        EntityID = 2,
                        Slug = "berkovici",
                        MunicipalityName = "Berkovići",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 5,
                        EntityID = 2,
                        Slug = "gacko",
                        MunicipalityName = "Gacko",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 6,
                        EntityID = 2,
                        Slug = "nevesinje",
                        MunicipalityName = "Nevesinje",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 7,
                        EntityID = 2,
                        Slug = "istocni-mostar",
                        MunicipalityName = "Istočni Mostar",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 8,
                        EntityID = 2,
                        Slug = "foca",
                        MunicipalityName = "Foča",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 9,
                        EntityID = 2,
                        Slug = "cajnice",
                        MunicipalityName = "Čajniče",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 10,
                        EntityID = 2,
                        Slug = "milici",
                        MunicipalityName = "Milići",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 11,
                        EntityID = 2,
                        Slug = "srebrenica",
                        MunicipalityName = "Srebrenica",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 12,
                        EntityID = 2,
                        Slug = "bratunac",
                        MunicipalityName = "Bratunac",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 13,
                        EntityID = 2,
                        Slug = "vlasenica",
                        MunicipalityName = "Vlasenica",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 14,
                        EntityID = 2,
                        Slug = "sekovici",
                        MunicipalityName = "Šekovići",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 15,
                        EntityID = 2,
                        Slug = "osmaci",
                        MunicipalityName = "Osmaci",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 16,
                        EntityID = 2,
                        Slug = "zvornik",
                        MunicipalityName = "Zvornik",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 17,
                        EntityID = 2,
                        Slug = "lopare",
                        MunicipalityName = "Lopare",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = false
                    },
                    new Municipality()
                    {
                        MunicipalityID = 18,
                        EntityID = 2,
                        Slug = "ugljevik",
                        MunicipalityName = "Ugljevik",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 19,
                        EntityID = 2,
                        Slug = "bijeljina",
                        MunicipalityName = "Bijeljina",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 20,
                        EntityID = 2,
                        Slug = "srbac",
                        MunicipalityName = "Srbac",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 21,
                        EntityID = 2,
                        Slug = "prnjavor",
                        MunicipalityName = "Prnjavor",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 22,
                        EntityID = 2,
                        Slug = "laktasi",
                        MunicipalityName = "Laktaši",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 23,
                        EntityID = 2,
                        Slug = "teslic",
                        MunicipalityName = "Teslić",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = false
                    },
                    new Municipality()
                    {
                        MunicipalityID = 24,
                        EntityID = 2,
                        Slug = "celinac",
                        MunicipalityName = "Čelinac",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 25,
                        EntityID = 2,
                        Slug = "kotor-varos",
                        MunicipalityName = "Kotor Varoš",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 26,
                        EntityID = 2,
                        Slug = "knezevo",
                        MunicipalityName = "Kneževo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 27,
                        EntityID = 2,
                        Slug = "kupres-rs",
                        MunicipalityName = "Kupres",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 28,
                        EntityID = 2,
                        Slug = "sipovo",
                        MunicipalityName = "Šipovo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 29,
                        EntityID = 2,
                        Slug = "jezero",
                        MunicipalityName = "Jezero",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 30,
                        EntityID = 2,
                        Slug = "mrkonjic-grad",
                        MunicipalityName = "Mrkonjić Grad",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 31,
                        EntityID = 2,
                        Slug = "istocni-drvar",
                        MunicipalityName = "Istočni Drvar",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 32,
                        EntityID = 2,
                        Slug = "petrovac",
                        MunicipalityName = "Petrovac",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 33,
                        EntityID = 2,
                        Slug = "ribnik",
                        MunicipalityName = "Ribnik",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 34,
                        EntityID = 2,
                        Slug = "banja-luka",
                        MunicipalityName = "Banja Luka",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 35,
                        EntityID = 2,
                        Slug = "gradiska",
                        MunicipalityName = "Gradiška",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 36,
                        EntityID = 2,
                        Slug = "kozarska-dubica",
                        MunicipalityName = "Kozarska Dubica",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 37,
                        EntityID = 2,
                        Slug = "kostajnica",
                        MunicipalityName = "Kostajnica",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 38,
                        EntityID = 2,
                        Slug = "krupa-na-uni",
                        MunicipalityName = "Krupa na Uni",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 39,
                        EntityID = 2,
                        Slug = "novi-grad-rs",
                        MunicipalityName = "Novi Grad",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 40,
                        EntityID = 2,
                        Slug = "prijedor",
                        MunicipalityName = "Prijedor",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 41,
                        EntityID = 2,
                        Slug = "ostra-luka",
                        MunicipalityName = "Oštra Luka",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 42,
                        EntityID = 2,
                        Slug = "kalinovik",
                        MunicipalityName = "Kalinovik",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 43,
                        EntityID = 2,
                        Slug = "ustipraca",
                        MunicipalityName = "Ustiprača",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 44,
                        EntityID = 2,
                        Slug = "istocna-ilidza",
                        MunicipalityName = "Istočna Ilidža",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 45,
                        EntityID = 2,
                        Slug = "istocno-novo-sarajevo",
                        MunicipalityName = "Istočno Novo Sarajevo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 46,
                        EntityID = 2,
                        Slug = "trnovo-rs",
                        MunicipalityName = "Trnovo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 47,
                        EntityID = 2,
                        Slug = "pale",
                        MunicipalityName = "Pale",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 48,
                        EntityID = 2,
                        Slug = "rogatica",
                        MunicipalityName = "Rogatica",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 49,
                        EntityID = 2,
                        Slug = "istocni-stari-grad",
                        MunicipalityName = "Istočni Stari Grad",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 50,
                        EntityID = 2,
                        Slug = "sokolac",
                        MunicipalityName = "Sokolac",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 51,
                        EntityID = 2,
                        Slug = "han-pijesak",
                        MunicipalityName = "Han Pijesak",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 52,
                        EntityID = 2,
                        Slug = "rudo",
                        MunicipalityName = "Rudo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 53,
                        EntityID = 2,
                        Slug = "visegrad",
                        MunicipalityName = "Višegrad",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 54,
                        EntityID = 2,
                        Slug = "samac",
                        MunicipalityName = "Šamac",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = false
                    },
                    new Municipality()
                    {
                        MunicipalityID = 55,
                        EntityID = 2,
                        Slug = "petrovo",
                        MunicipalityName = "Petrovo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 56,
                        EntityID = 2,
                        Slug = "doboj",
                        MunicipalityName = "Doboj",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 57,
                        EntityID = 2,
                        Slug = "brod",
                        MunicipalityName = "Brod",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 58,
                        EntityID = 2,
                        Slug = "derventa",
                        MunicipalityName = "Derventa",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 59,
                        EntityID = 2,
                        Slug = "pelagicevo",
                        MunicipalityName = "Pelagićevo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 60,
                        EntityID = 2,
                        Slug = "donji-zabar",
                        MunicipalityName = "Donji Žabar",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 61,
                        EntityID = 2,
                        Slug = "vukosavlje",
                        MunicipalityName = "Vukosavlje",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 62,
                        EntityID = 2,
                        Slug = "modrica",
                        MunicipalityName = "Modriča",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 63,
                        EntityID = 1,
                        Slug = "foca-ustikolina",
                        MunicipalityName = "Foča-Ustikolina",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 64,
                        EntityID = 1,
                        Slug = "gorazde",
                        MunicipalityName = "Goražde",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 65,
                        EntityID = 1,
                        Slug = "pale-praca",
                        MunicipalityName = "Pale-Prača",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 66,
                        EntityID = 1,
                        Slug = "stari-grad",
                        MunicipalityName = "Stari Grad Sarajevo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 67,
                        EntityID = 1,
                        Slug = "centar",
                        MunicipalityName = "Centar Sarajevo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 68,
                        EntityID = 1,
                        Slug = "novo-sarajevo",
                        MunicipalityName = "Novo Sarajevo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 69,
                        EntityID = 1,
                        Slug = "novi-grad",
                        MunicipalityName = "Novi Grad Sarajevo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 70,
                        EntityID = 1,
                        Slug = "trnovo-fbih",
                        MunicipalityName = "Trnovo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 71,
                        EntityID = 1,
                        Slug = "ilijas",
                        MunicipalityName = "Ilijaš",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 72,
                        EntityID = 1,
                        Slug = "hadzici",
                        MunicipalityName = "Hadžići",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 73,
                        EntityID = 1,
                        Slug = "ilidza",
                        MunicipalityName = "Ilidža",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 74,
                        EntityID = 1,
                        Slug = "vogosca",
                        MunicipalityName = "Vogošća",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 75,
                        EntityID = 1,
                        Slug = "gornji-vakuf-uskoplje",
                        MunicipalityName = "Gornji Vakuf-Uskoplje",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 76,
                        EntityID = 1,
                        Slug = "fojnica",
                        MunicipalityName = "Fojnica",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 77,
                        EntityID = 1,
                        Slug = "kresevo",
                        MunicipalityName = "Kreševo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 78,
                        EntityID = 1,
                        Slug = "kiseljak",
                        MunicipalityName = "Kiseljak",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 79,
                        EntityID = 1,
                        Slug = "busovaca",
                        MunicipalityName = "Busovača",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 80,
                        EntityID = 1,
                        Slug = "vitez",
                        MunicipalityName = "Vitez",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 81,
                        EntityID = 1,
                        Slug = "novi-travnik",
                        MunicipalityName = "Novi Travnik",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 82,
                        EntityID = 1,
                        Slug = "bugojno",
                        MunicipalityName = "Bugojno",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 83,
                        EntityID = 1,
                        Slug = "donji-vakuf",
                        MunicipalityName = "Donji Vakuf",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 84,
                        EntityID = 1,
                        Slug = "jajce",
                        MunicipalityName = "Jajce",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 85,
                        EntityID = 1,
                        Slug = "dobretici",
                        MunicipalityName = "Dobretići",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 86,
                        EntityID = 1,
                        Slug = "travnik",
                        MunicipalityName = "Travnik",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 87,
                        EntityID = 1,
                        Slug = "breza",
                        MunicipalityName = "Breza",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 88,
                        EntityID = 1,
                        Slug = "olovo",
                        MunicipalityName = "Olovo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 89,
                        EntityID = 1,
                        Slug = "vares",
                        MunicipalityName = "Vareš",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = false
                    },
                    new Municipality()
                    {
                        MunicipalityID = 90,
                        EntityID = 1,
                        Slug = "visoko",
                        MunicipalityName = "Visoko",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 91,
                        EntityID = 1,
                        Slug = "kakanj",
                        MunicipalityName = "Kakanj",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 92,
                        EntityID = 1,
                        Slug = "zenica",
                        MunicipalityName = "Zenica",
                        LocalGovernmentUnitID = 2,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = false
                    },
                    new Municipality()
                    {
                        MunicipalityID = 93,
                        EntityID = 1,
                        Slug = "zavidovici",
                        MunicipalityName = "Zavidovići",
                        LocalGovernmentUnitID = 2,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = false
                    },
                    new Municipality()
                    {
                        MunicipalityID = 94,
                        EntityID = 1,
                        Slug = "zepce",
                        MunicipalityName = "Žepče",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = false
                    },
                    new Municipality()
                    {
                        MunicipalityID = 95,
                        EntityID = 1,
                        Slug = "maglaj",
                        MunicipalityName = "Maglaj",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 96,
                        EntityID = 1,
                        Slug = "tesanj",
                        MunicipalityName = "Tešanj",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 97,
                        EntityID = 1,
                        Slug = "doboj-jug",
                        MunicipalityName = "Doboj-Jug",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 98,
                        EntityID = 1,
                        Slug = "usora",
                        MunicipalityName = "Usora",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 99,
                        EntityID = 1,
                        Slug = "ljubuski",
                        MunicipalityName = "Ljubuški",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 100,
                        EntityID = 1,
                        Slug = "grude",
                        MunicipalityName = "Grude",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 101,
                        EntityID = 1,
                        Slug = "siroki-brijeg",
                        MunicipalityName = "Široki Brijeg",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 102,
                        EntityID = 1,
                        Slug = "posusje",
                        MunicipalityName = "Posušje",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 103,
                        EntityID = 1,
                        Slug = "neum",
                        MunicipalityName = "Neum",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 104,
                        EntityID = 1,
                        Slug = "ravno",
                        MunicipalityName = "Ravno",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 105,
                        EntityID = 1,
                        Slug = "stolac",
                        MunicipalityName = "Stolac",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 106,
                        EntityID = 1,
                        Slug = "mostar",
                        MunicipalityName = "Mostar",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 107,
                        EntityID = 1,
                        Slug = "konjic",
                        MunicipalityName = "Konjic",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 108,
                        EntityID = 1,
                        Slug = "capljina",
                        MunicipalityName = "Čapljina",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 109,
                        EntityID = 1,
                        Slug = "citluk",
                        MunicipalityName = "Čitluk",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 110,
                        EntityID = 1,
                        Slug = "jablanica",
                        MunicipalityName = "Jablanica",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 111,
                        EntityID = 1,
                        Slug = "prozor-rama",
                        MunicipalityName = "Prozor-Rama",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 112,
                        EntityID = 1,
                        Slug = "tomislavgrad",
                        MunicipalityName = "Tomislavgrad",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 113,
                        EntityID = 1,
                        Slug = "kupres",
                        MunicipalityName = "Kupres",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 114,
                        EntityID = 1,
                        Slug = "livno",
                        MunicipalityName = "Livno",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 115,
                        EntityID = 1,
                        Slug = "glamoc",
                        MunicipalityName = "Glamoč",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 116,
                        EntityID = 1,
                        Slug = "bosansko-grahovo",
                        MunicipalityName = "Bosansko Grahovo",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 117,
                        EntityID = 1,
                        Slug = "drvar",
                        MunicipalityName = "Drvar",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 118,
                        EntityID = 1,
                        Slug = "kladanj",
                        MunicipalityName = "Kladanj",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 119,
                        EntityID = 1,
                        Slug = "banovici",
                        MunicipalityName = "Banovići",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 120,
                        EntityID = 1,
                        Slug = "zivinice",
                        MunicipalityName = "Živinice",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 121,
                        EntityID = 1,
                        Slug = "lukavac",
                        MunicipalityName = "Lukavac",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 122,
                        EntityID = 1,
                        Slug = "kalesija",
                        MunicipalityName = "Kalesija",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 123,
                        EntityID = 1,
                        Slug = "sapna",
                        MunicipalityName = "Sapna",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 124,
                        EntityID = 1,
                        Slug = "teocak",
                        MunicipalityName = "Teočak",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 125,
                        EntityID = 1,
                        Slug = "tuzla",
                        MunicipalityName = "Tuzla",
                        LocalGovernmentUnitID = 2,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = false
                    },
                    new Municipality()
                    {
                        MunicipalityID = 126,
                        EntityID = 1,
                        Slug = "celic",
                        MunicipalityName = "Čelić",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 127,
                        EntityID = 1,
                        Slug = "srebrenik",
                        MunicipalityName = "Srebrenik",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 128,
                        EntityID = 1,
                        Slug = "doboj-istok",
                        MunicipalityName = "Doboj-Istok",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 129,
                        EntityID = 1,
                        Slug = "gracanica",
                        MunicipalityName = "Gračanica",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 130,
                        EntityID = 1,
                        Slug = "gradacac",
                        MunicipalityName = "Gradačac",
                        LocalGovernmentUnitID = 2,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = false
                    },
                    new Municipality()
                    {
                        MunicipalityID = 131,
                        EntityID = 1,
                        Slug = "kljuc",
                        MunicipalityName = "Ključ",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 132,
                        EntityID = 1,
                        Slug = "sanski-most",
                        MunicipalityName = "Sanski Most",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 133,
                        EntityID = 1,
                        Slug = "bosanski-petrovac",
                        MunicipalityName = "Bosanski Petrovac",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 134,
                        EntityID = 1,
                        Slug = "bihac",
                        MunicipalityName = "Bihać",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 135,
                        EntityID = 1,
                        Slug = "cazin",
                        MunicipalityName = "Cazin",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 136,
                        EntityID = 1,
                        Slug = "buzim",
                        MunicipalityName = "Bužim",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 137,
                        EntityID = 1,
                        Slug = "bosanska-krupa",
                        MunicipalityName = "Bosanska Krupa",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 138,
                        EntityID = 1,
                        Slug = "velika-kladusa",
                        MunicipalityName = "Velika Kladuša",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 139,
                        EntityID = 1,
                        Slug = "orasje",
                        MunicipalityName = "Orašje",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 140,
                        EntityID = 1,
                        Slug = "odzak",
                        MunicipalityName = "Odžak",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 141,
                        EntityID = 1,
                        Slug = "domaljevac-samac",
                        MunicipalityName = "Domaljevac-Šamac",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 142,
                        EntityID = 1,
                        Slug = "brcko",
                        MunicipalityName = "Brčko",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    },
                    new Municipality()
                    {
                        MunicipalityID = 143,
                        EntityID = 2,
                        Slug = "stanari",
                        MunicipalityName = "Stanari",
                        LocalGovernmentUnitID = 1,
                        SysCreatedByUserID = new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"),
                        SysCreatedDate = currentDate,
                        Retired = true
                    }
                );
            #endregion
        }
    }
}