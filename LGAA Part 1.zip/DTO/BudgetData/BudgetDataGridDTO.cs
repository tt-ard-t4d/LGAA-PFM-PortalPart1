﻿using PFMPortal.Domain.Entities.App;

namespace PFMPortal.DTO.BudgetData
{
    public class BudgetDataGridDTO
    {        
        public string MunicipalityName { get; set; }
        public string LGUStatus { get; set; }
        public int AccountCategoryID { get; set; }
        public string AccountCategoryName { get; set; } = string.Empty;
        public string AccountCategoryHelperName { get; set; } = string.Empty;
        public byte AccountTypeID { get; set; }
        public int BudgetPositionID { get; set; }
        public string BudgetPositionName { get; set; } = string.Empty;
        public int BudgetDataID { get; set; }
        public int Year { get; set; }
        public int MunicipalityID { get; set; }
        public decimal? PlannedValue { get; set; }
        public decimal? FinalValue { get; set; }
        public string? Comment { get; set; } = string.Empty;
        public string Information { get; set; } = string.Empty;
    }
}
