﻿
using Domain.Contracts;
using Domain.Entities.Utils;
using DTO.Utils;
using Infrastructure.Helpers;
using Infrastructure.Models.Utils.Email;
using Infrastructure.Settings.Utils;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using MimeKit;
using PFMPortal.Domain.Entities;
using PFMPortal.DTO.Admin;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace Infrastructure.Core
{
    public class EmailService
    {
        private readonly IEmailNotificationRepository _emailNotificationRep;
        private readonly IHttpContextAccessor _httpContextAccessor;
        MailSettings _emailSettings = null;
        private readonly IConfiguration _configuration;

        public EmailService(IOptions<MailSettings> options, IEmailNotificationRepository emailNotificationRep,
            IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
        {
            _emailNotificationRep = emailNotificationRep;
            _emailSettings = options.Value;
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
        }


        #region <-- Private -->

        private void ActionSendEmail(int databaseId, List<string> addressTo, int caseId, string partyName = "", string email = "")
        {
            List<EmailData> emailNotificationItems = new List<EmailData>();
            EmailData emailData = new EmailData();
            var scheme = _httpContextAccessor.HttpContext?.Request.Scheme;
            var host = _httpContextAccessor.HttpContext?.Request.Host.Value;

            emailData.ItemData.Add("Link", $"{scheme}://{host}/Case/Edit?id={caseId}");
            if (!String.IsNullOrEmpty(partyName))
            {
                emailData.ItemData.Add("PartyName", partyName);
            }

            if (!String.IsNullOrEmpty(email))
            {
                emailData.ItemData.Add("SpecifiedEmail", email);
            }

            // where we want to send email
            emailData.To = addressTo;

            emailNotificationItems.Add(emailData);
            SendEmailNotification(databaseId, emailNotificationItems);
        }


        private void SendEmailNotification(int emailEnumeration, List<EmailData> emailNotificationItems)
        {
            var emailNot = _emailNotificationRep.GetEmailNotificationItem(emailEnumeration);
            if (emailNot is not null && emailNot.EmailNotificationID > 0)
            {
                foreach (var item in emailNotificationItems)
                {
                    SendEmail(item, emailNot);
                }
            }
        }

        private bool SendEmail(EmailData emailData, EmailNotificationDTO emailNot)
        {
            var htmlTemplate = emailNot.EmailText;
            var subTemplate = emailNot.EmailSubject;
            var statusEmail = emailNot.EmailStatus;

            subTemplate = subTemplate.Replace('\r', ' ').Replace('\n', ' ');

            foreach (var item in emailData.ItemData)
            {
                var key = '<' + item.Key + '>';

                if (!String.IsNullOrEmpty(htmlTemplate))
                    htmlTemplate = htmlTemplate.Replace(key, item.Value.ToString());

                if (!String.IsNullOrEmpty(subTemplate))
                    subTemplate = subTemplate.Replace(key, item.Value.ToString());

            }

            try
            {
                MimeMessage emailMessage = new MimeMessage();
                MailboxAddress emailFrom = new MailboxAddress(_emailSettings.Name, _emailSettings.EmailId);
                emailMessage.From.Add(emailFrom);

                GetToEmailAddress(ref emailMessage, emailData, statusEmail);
                //MailboxAddress emailTo = new MailboxAddress("amar", "amar@finit.ba");
                //emailMessage.To.Add(emailTo);

                emailMessage.Subject = subTemplate;

                BodyBuilder emailBodyBuilder = new BodyBuilder();
                emailBodyBuilder.HtmlBody = htmlTemplate;
                emailMessage.Body = emailBodyBuilder.ToMessageBody();

                SmtpClient emailClient = new SmtpClient();
                emailClient.Connect(_emailSettings.Host, _emailSettings.Port, SecureSocketOptions.StartTls);
                emailClient.Authenticate(_emailSettings.EmailId, _emailSettings.Password);
                emailClient.Send(emailMessage);
                emailClient.Disconnect(true);
                emailClient.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                //Log Exception Details
                return false;
            }
        }

        private void GetToEmailAddress(ref MimeMessage message, EmailData emailNotification, int? statusEmail)
        {
            if (statusEmail == 1) // Test salje se na developer
            {
                GetDevEmails(message);
            }
            if (statusEmail == 2) // Aktivan na stvarne
            {

                if (_httpContextAccessor.HttpContext.Request.Host.Value.Contains(_configuration.GetValue<String>("AppIdentitySettings:AppLink")))
                {
                    GetDevEmails(message);
                }
                else
                {
                    InternetAddressList list = new InternetAddressList();
                    foreach (var item in emailNotification.To)
                    {
                        if (!String.IsNullOrEmpty(item))
                        {
                            list.Add(new MailboxAddress("", item.Replace(" ", string.Empty)));
                        }
                    }

                    message.To.AddRange(list);

                    if (emailNotification.Cc.Count() > 0)
                    {
                        InternetAddressList listCC = new InternetAddressList();
                        foreach (var item in emailNotification.Cc)
                        {
                            if (!String.IsNullOrEmpty(item))
                            {
                                listCC.Add(new MailboxAddress("", item.Replace(" ", string.Empty)));
                                message.Cc.AddRange(listCC);
                            }
                        }
                    }

                    if (emailNotification.Bcc.Count() > 0)
                    {
                        InternetAddressList listBcc = new InternetAddressList();
                        foreach (var item in emailNotification.Bcc)
                        {
                            if (!String.IsNullOrEmpty(item))
                            {
                                listBcc.Add(new MailboxAddress("", item.Replace(" ", string.Empty)));
                                message.Bcc.AddRange(listBcc);
                            }
                        }
                    }
                }
            }
        }

        private void GetDevEmails(MimeMessage message)
        {
            var strTo = _configuration.GetValue<String>("AppIdentitySettings:DevEmails")?.Split(";")
                .Select(r => r.Replace(" ", string.Empty))
                .ToList();

            if (strTo == null || strTo.Count == 0) return;

            InternetAddressList list = new InternetAddressList();
            foreach (var item in strTo)
            {
                if (!String.IsNullOrEmpty(item))
                {
                    list.Add(new MailboxAddress("", item));
                }
            }
            message.To.AddRange(list);
        }

        #endregion

        #region <!-- Emails -->
        public void SendEmailPasswordSetup01(UserDTO user)
        {
            List<EmailNotification> emailNotificationItems = new List<EmailNotification>();
            EmailNotification emailNotification = new EmailNotification();
            EmailData emailData = new EmailData();

            var scheme = _httpContextAccessor.HttpContext?.Request.Scheme;
            var host = _httpContextAccessor.HttpContext?.Request.Host.Value;

            //emailData.ItemData.Add("Logo", htmllogo);
            emailData.ItemData.Add("Name", user.FirstName + " " + user.LastName);
            emailData.ItemData.Add("Username", user.UserName);
            emailData.ItemData.Add("ConfirmationLink", $"{scheme}://{host}/Login/PasswordReset?verificationCode={user.EmailCode}");

            emailNotificationItems.Add(emailNotification);

            List<string> emails = new List<string>() { user.Email };
            emailData.To = emails;
            emailData.Cc.Add("");
            emailData.Bcc.Add("");

            List<EmailData> data = new List<EmailData>
            {
                emailData
            };

            SendEmailNotification((int)GlobalEnum.Email.EmailPasswordSetup, data);
        }

        public void SendEmailPasswordReset02(UserDTO user)
        {
            List<EmailNotification> emailNotificationItems = new List<EmailNotification>();
            EmailNotification emailNotification = new EmailNotification();
            EmailData emailData = new EmailData();

            var scheme = _httpContextAccessor.HttpContext?.Request.Scheme;
            var host = _httpContextAccessor.HttpContext?.Request.Host.Value;

            emailData.ItemData.Add("Name", user.FirstName + " " + user.LastName);
            emailData.ItemData.Add("Username", user.UserName);
            emailData.ItemData.Add("ConfirmationLink", $"{scheme}://{host}/Login/PasswordReset?verificationCode={user.EmailCode}");

            emailNotificationItems.Add(emailNotification);

            List<string> emails = new List<string>() { user.Email };
            emailData.To = emails;
            emailData.Cc.Add("");
            emailData.Bcc.Add("");

            List<EmailData> data = new List<EmailData>
            {
                emailData
            };

            SendEmailNotification((int)GlobalEnum.Email.EmailPasswordReset, data);
        }

        #endregion 
    }
}
