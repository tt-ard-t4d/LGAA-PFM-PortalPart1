﻿var app = app || {};

app.BudgetData = function () {
    let focused = 0;
    let saveClicked = false;
    //EDIT VIEW

    var initEdit = function () {
        $('#btn-save').click(function () {
            if ($('.k-tooltip-error').length) {
                return;
            }
            if ($('.k-dirty-cell').length) {
                saveClicked = true;
                app.utility.showLoader();
            }
            $('.k-grid-save-changes').click();
        });
        $('#btn-cancel').click(function () {
            $('.k-grid-cancel-changes').click();
        });

        app.selectPicker.addPickers({
            search: true,
            multiple: false,
            clear: false,
            selectAll: false,
        });

        window.addEventListener('beforeunload', function (e) {
            let dirtyCells = $('.k-dirty-cell');
            if (dirtyCells[0] && !saveClicked) {
                e.preventDefault();
                e.returnValue = '';
            }
        });

    }

    var inputFocus = function (item) {
        if (focused == 0) {
            focused = 1;
            $(item).click().focus();
        }
    }

    var resetFocus = function () {
        focused = 0;
    }

    //INDEX VIEW

    var initBudgetDataIndexForm = function () {
        $('.municipality-selector').each(
            function () {
                $(this).click(
                    function () {
                        $('#MunicipalityID').val($(this).data('id'));
                        app.utility.showLoader('body');
                        $('#BudgetDataInitForm').submit();
                    })
            });
    }

    return {
        initEdit: initEdit,
        inputFocus: inputFocus,
        resetFocus: resetFocus,
        initBudgetDataIndexForm: initBudgetDataIndexForm
    };
}();