﻿using Infrastructure.Helpers;
using PFMPortal.Domain.Entities;
using PFMPortal.DTO.Admin;
using PFMPortal.DTO.Utils;

namespace PFMPortal.Infrastructure.Mappings.Admin
{
    using Action = Domain.Entities.Action;
    public class ActionMapper
    {
        public ActionDTO Map(Action? entity)
        {
            if (entity == null)
            {
                return new ActionDTO(); 
            }

            return new ActionDTO()
            {
                ActionID = entity.ActionID,
                ActionEnumerationName = entity.ActionEnumerationName,
                ActionName = entity.ActionName,
                Description = entity.Description
            };
        }

        public Action Map(ActionDTO model, GlobalEnum.CrudOperation operation, Guid loggedUserId)
        {
            var entity = new Action()
            {
                ActionID = model.ActionID,
                ActionEnumerationName = model.ActionEnumerationName,
                ActionName = model.ActionName,
                Description = model.Description,
                Retired = false
            };

            if (operation == GlobalEnum.CrudOperation.Add)
            {
                entity.SysCreatedByUserID = loggedUserId;
                entity.SysCreatedDate = DateTime.Now;
            }
            else if (operation == GlobalEnum.CrudOperation.Edit)
            {
                entity.SysLastModifiedByUserID = loggedUserId;
                entity.SysLastModifiedDate = DateTime.Now;
            }

            return entity;
        }

        public ActionGridDTO Map(Action entity, int totalNumberOfRows)
        {
            if (entity == null)
            {
                return new ActionGridDTO();
            }

            return new ActionGridDTO()
            {
                ActionID = entity.ActionID,
                ActionName = entity.ActionName,
                ActionEnumerationName = entity.ActionEnumerationName,
                Description = entity.Description,
                SysLastModifiedDate = entity.SysLastModifiedDate,
                Total = totalNumberOfRows
            };
        }

        public ActionGridDTO MapHistory(ActionHistory entity, int totalNumberOfRows)
        {
            if (entity == null)
            {
                return new ActionGridDTO();
            }

            return new ActionGridDTO()
            {
                ActionID = entity.ActionID,
                ActionName = entity.ActionName,
                ActionEnumerationName = entity.ActionEnumerationName,
                Description = entity.Description,
                SysLastModifiedDate = entity.SysLastModifiedDate,
                SysLastModifiedByUserID = entity.SysLastModifiedByUserID,
                StatusName = entity.StatusName,
                SysEntryTime = entity.SysEntryTime,
                Total = totalNumberOfRows
            };
        }
    }
}
