﻿namespace PFMPortal.Domain.Entities.App
{
    public class AccountCategory : SysEntity
    {
        public int AccountCategoryID { get; set; }
        public string AccountCategoryName { get; set; } = string.Empty;
        public string Information { get; set; } = string.Empty;
        public byte AccountTypeID { get; set; }
        public byte EntityID { get; set; }
        public virtual AccountType AccountType { get; set; }
        public virtual ICollection<BudgetPosition> BudgetPositions { get; set; }
        public virtual ICollection<AccountCategoryData> AccountCategoryData { get; set; }
    }
}
