﻿namespace PFMPortal.DTO.BudgetData
{
    public class GroupedBudgetDataDTO
    {
    }
}
