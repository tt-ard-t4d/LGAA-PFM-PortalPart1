﻿namespace PFMPortal.Domain.Contracts.Utils
{
    public interface IReportingRepository
    {

    }
}
