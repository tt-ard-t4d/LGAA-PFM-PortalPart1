﻿using Domain.Entities.Utils;
using DTO.Utils;
using Infrastructure.Data;
using Infrastructure.Mappings.Utils;
using Microsoft.EntityFrameworkCore;
using PFMPortal.Domain.Contracts.Utils;
using PFMPortal.Domain.Entities;

namespace PFMPortal.Infrastructure.Data.Repositories.Utils
{
    public class DropDownRepository : IDropDownRepository
    {
        private readonly DatabaseContext _dc;

        public DropDownRepository(DatabaseContext dc)
        {
            _dc = dc;          
        }

        public IQueryable<UserGroup> GetUserGroups()
        {
            return _dc.UserGroups.Where(r => r.Retired == false).AsNoTracking();
        }

        public IQueryable<Domain.Entities.Action> GetActions()
        {
            return _dc.Actions.Where(r => r.Retired == false).AsNoTracking();
        }

        public IQueryable<User> GetUsers()
        {
            return _dc.Users.Where(r => r.Retired == false).AsNoTracking();
        }

        /// <summary>
        /// Get item from AuditLogEnumeration
        /// </summary>
        /// <returns>Mapped List AuditLogEnumeration items</returns>
        public List<AuditLogEnumerationDTO> GetAllAuditLogsEnumeration()
        {
            List<AuditLogEnumerationDTO> auditlogenumNew = new List<AuditLogEnumerationDTO>();
            var audlogenumMapper = new AuditLogEnumerationMapper();

            List<AuditLogEnumeration> auditlogenum = _dc.AuditLogEnumerations.AsNoTracking().ToList();

            if (auditlogenum != null)
            {
                foreach (var item in auditlogenum)
                {
                    auditlogenumNew.Add(audlogenumMapper.MapAuditLogEnumeration(item));
                }
            }

            return auditlogenumNew;

        }
    }
}
