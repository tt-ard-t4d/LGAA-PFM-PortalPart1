﻿namespace PFMPortal.Infrastructure.Helpers
{
    public class SessionConstants
    {
        public static readonly string UserGroups = "userGroups";
        public static readonly string Actions = "actions";
        public static readonly string LoggedIn = "loggedIn";
    }
}
