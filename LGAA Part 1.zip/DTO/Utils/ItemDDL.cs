﻿namespace PFMPortal.DTO.Utils
{
    public class ItemDDL
    {
        public int Id { get; set; }
        public Guid Guid { get; set; }
        public string Code { get; set; }
        public string Value { get; set; }
        public short LanguageID { get; set; }
    }
}
