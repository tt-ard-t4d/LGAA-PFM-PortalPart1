﻿using ClosedXML.Excel;
using System.ComponentModel;
using System.Reflection;

namespace PFMPortal.Infrastructure.Helpers
{
    public class ReportHelper
    {
        public static void CreateHeader<T>(ref IXLWorksheet ws, List<T> source) where T : class, new()
        {
            PropertyInfo[] properties = Activator.CreateInstance<T>().GetType().GetProperties();
            List<string> headerNames = new List<string>();
            foreach (var property in properties)
            {
                try
                {
                    var attribute = property.GetCustomAttributes(typeof(DisplayNameAttribute), true).Cast<DisplayNameAttribute>().Single();
                    headerNames.Add(attribute.DisplayName);
                }
                catch (Exception)
                {
                    headerNames.Add(property.Name);
                }
            }
            // ADD NAMES for headers
            for (int i = 0; i < headerNames.Count; i++)
            {
                ws.Cell(1, i + 1).Value = headerNames[i];
                ws.Cell(1, i + 1).Style.Font.Bold = true;
            }
        }

        public static void CreateRows<T>(ref IXLWorksheet ws, List<T> data, int startRow = 2) where T : class, new()
        {
            PropertyInfo[] properties = Activator.CreateInstance<T>().GetType().GetProperties();
            foreach (var item in data)
            {
                for (int i = 1; i <= properties.Length; i++)
                {
                    ws.Cell(startRow, i).Value = XLCellValue.FromObject(properties[i - 1].GetValue(item));
                    if (properties[i - 1].PropertyType == typeof(decimal) || properties[i - 1].PropertyType == typeof(decimal?))
                    {
                        ws.Cell(startRow, i).Style.NumberFormat.Format = "#,##0.00";
                    }
                    else if (properties[i - 1].PropertyType == typeof(DateTime) || properties[i - 1].PropertyType == typeof(DateTime?))
                    {
                        ws.Cell(startRow, i).Style.DateFormat.Format = "dd.MM.yyyy.";
                    }
                }

                startRow++;
            }
        }
    }
}
