﻿namespace PFMPortal.Infrastructure.Extensions
{
    public static class PagingExtension
    {
        public static IEnumerable<T> Page<T>(this IEnumerable<T> en, int numberOfObjectsPerPage, int pageNumber)
        {
            return en.Skip((pageNumber - 1) * numberOfObjectsPerPage).Take(numberOfObjectsPerPage);
        }
        public static IQueryable<T> Page<T>(this IQueryable<T> en, int numberOfObjectsPerPage, int pageNumber)
        {
            return en.Skip((pageNumber - 1) * numberOfObjectsPerPage).Take(numberOfObjectsPerPage);
        }
    }
}
