﻿using Infrastructure.Models;
using PFMPortal.Infrastructure.Extensions;

namespace PFMPortal.Infrastructure.Helpers
{
    public static class SessionHelper
    {
        public static void SetUserData(this ISession session, UserData user)
        {
            session.SetValue(SessionConstants.Actions, user.UserActions);
            session.SetValue(SessionConstants.UserGroups, user.UserGroups);
            session.SetValue(SessionConstants.LoggedIn, true);
        }
    }
}
