﻿namespace PFMPortal.Startup
{
    public static partial class EndpointMapper
    {
        public static WebApplication RegisterEndpoints(this WebApplication app)
        {
            app.MapEndpoints();

            return app;
        }

        private static WebApplication MapEndpoints(this WebApplication app)
        {
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}"
            );

            app.MapControllerRoute(
                name: "opcina",
                pattern: "{MunicipalityName}",
                defaults: new { controller = "BudgetDataPublic", action = "Index" }
            );

            app.MapControllerRoute(
                name: "opcina",
                pattern: "{MunicipalityName}/tabela",
                defaults: new { controller = "BudgetDataPublic", action = "IndexTable" }
            );

            app.MapControllerRoute(
                name: "opcina",
                pattern: "{MunicipalityName}/dokumenti",
                defaults: new { controller = "BudgetDataPublic", action = "IndexDocument" }
            );

            return app;
        }
    }
}