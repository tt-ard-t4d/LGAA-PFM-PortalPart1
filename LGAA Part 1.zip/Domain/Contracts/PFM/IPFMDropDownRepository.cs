﻿using PFMPortal.Domain.Entities.App;

namespace PFMPortal.Domain.Contracts.PFM
{
    public interface IPFMDropDownRepository
    {
        public IQueryable<Entity> GetEntities();
        public IQueryable<Municipality> GetMunicipalitiesForUser(Guid userId);
        public IQueryable<Municipality> GetAllMunicipalities();
        public IQueryable<AccountType> GetAccountTypes();
    }
}
