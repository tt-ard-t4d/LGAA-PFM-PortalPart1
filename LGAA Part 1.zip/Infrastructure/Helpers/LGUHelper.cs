﻿namespace PFMPortal.Infrastructure.Helpers
{
    public static class LGUHelper
    {
        public static string GetLGUType(byte entityID, byte localGovernmentUnitID)
        {
            if (localGovernmentUnitID == 2)
                return "Grad";
            if (entityID == 1) return "Općina";
            return "Opština";
        }
    }
}
