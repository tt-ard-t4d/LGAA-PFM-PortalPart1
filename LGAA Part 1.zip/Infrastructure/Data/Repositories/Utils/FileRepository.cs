﻿using Infrastructure.Data;
using PFMPortal.Domain.Contracts.Utils;
using PFMPortal.Domain.Entities.Utils;
using PFMPortal.Infrastructure.Models;

namespace PFMPortal.Infrastructure.Data.Repositories.Utils
{
    public class FileRepository : IFileRepository
    {
        private DatabaseContext _dc;

        public FileRepository(DatabaseContext dc)
        {
            _dc = dc;           
        }

        public List<FormFiles> GetFileFromDB(int id, short typeId, string fileName)
        {
            return _dc.FormFiles.Where(r => r.Retired == false && r.FormID == id && r.FileTypeID == typeId && r.Name == fileName).ToList();
        }

        public List<FormFiles> GetFilesFromDB(int id, short typeId)
        {
            return _dc.FormFiles.Where(r => r.Retired == false && r.FormID == id && r.FileTypeID == typeId).ToList();
        }

        public RetValue Save(FormFiles entity)
        {
            _dc.FormFiles.Add(entity);

            try
            {
                _dc.SaveChanges();
            }
            catch (Exception ex)
            {
                // TODO: add elmach here
                return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
            }
            return new RetValue() { Id = entity.FormFileID };
        }

        public RetValue UpdateFilesFromDB(IEnumerable<int> ids, int id)
        {
            var res = _dc.FormFiles.Where(r => ids.Contains(r.FormFileID) && r.FormID == null).ToList();
            if (res.Count > 0)
            {
                res.ForEach(r => r.FormID = id);
                
                try
                {
                    _dc.SaveChanges();
                }
                catch (Exception ex)
                {
                    // TODO: add elmach here
                    return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
                }
            }
            return new RetValue() { };
        }


        public RetValue DeleteFile(int id)
        {
            var item = _dc.FormFiles.Where(r => r.FormFileID == id).FirstOrDefault();

            if (item is not null)
            {
                item.Retired = true;

                try
                {
                    _dc.SaveChanges();
                }
                catch (Exception ex)
                {
                    return new RetValue() { IsError = true, ErrorMessage = ex.Message, Exception = ex };
                }
                return new RetValue() { Id = item.FormFileID };
            }
            return new RetValue() { };
        }
    }
}
