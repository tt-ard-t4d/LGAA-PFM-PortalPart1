﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PFMPortal.Migrations
{
    /// <inheritdoc />
    public partial class InitialMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "pfm");

            migrationBuilder.EnsureSchema(
                name: "dbo");

            migrationBuilder.CreateTable(
                name: "AccountTypes",
                schema: "pfm",
                columns: table => new
                {
                    AccountTypeID = table.Column<byte>(type: "tinyint", nullable: false),
                    AccountTypeName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AccountTypes", x => x.AccountTypeID);
                });

            migrationBuilder.CreateTable(
                name: "Actions",
                schema: "dbo",
                columns: table => new
                {
                    ActionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActionName = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ActionEnumerationName = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Actions", x => x.ActionID);
                });

            migrationBuilder.CreateTable(
                name: "ActionsHistory",
                schema: "dbo",
                columns: table => new
                {
                    HistoryID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActionID = table.Column<int>(type: "int", nullable: false),
                    ActionName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ActionEnumerationName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Retired = table.Column<bool>(type: "bit", nullable: false),
                    Status = table.Column<short>(type: "smallint", nullable: true),
                    StatusName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SysEntryTime = table.Column<DateTime>(type: "datetime", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActionsHistory", x => x.HistoryID);
                });

            migrationBuilder.CreateTable(
                name: "AuditLogEnumerations",
                schema: "dbo",
                columns: table => new
                {
                    AuditLogEnumerationID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AuditLogEnumerationDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AuditLogEnumerationText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditLogEnumerations", x => x.AuditLogEnumerationID);
                });

            migrationBuilder.CreateTable(
                name: "AuditLogs",
                schema: "dbo",
                columns: table => new
                {
                    AuditLogID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AuditLogText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SysCreatedByUserID = table.Column<int>(type: "int", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<int>(type: "int", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    RelatedItemID = table.Column<long>(type: "bigint", nullable: true),
                    AuditLogEnumerationID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditLogs", x => x.AuditLogID);
                });

            migrationBuilder.CreateTable(
                name: "EmailNotifications",
                schema: "dbo",
                columns: table => new
                {
                    EmailNotificationID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmailDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailSubject = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SysDateCreated = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysDateLastModified = table.Column<DateTime>(type: "datetime", nullable: true),
                    SysCreatedByUserID = table.Column<int>(type: "int", nullable: false),
                    SysModifiedByUserID = table.Column<int>(type: "int", nullable: true),
                    EmailStatus = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmailNotifications", x => x.EmailNotificationID);
                });

            migrationBuilder.CreateTable(
                name: "Entities",
                schema: "pfm",
                columns: table => new
                {
                    EntityID = table.Column<byte>(type: "tinyint", nullable: false),
                    EntityName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Entities", x => x.EntityID);
                });

            migrationBuilder.CreateTable(
                name: "FormFiles",
                schema: "dbo",
                columns: table => new
                {
                    FormFileID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FormID = table.Column<int>(type: "int", nullable: true),
                    FileGuidID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    Extension = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Title = table.Column<string>(type: "nvarchar(1500)", maxLength: 1500, nullable: false),
                    Size = table.Column<long>(type: "bigint", nullable: true),
                    FileTypeID = table.Column<short>(type: "smallint", nullable: false),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FormFiles", x => x.FormFileID);
                });

            migrationBuilder.CreateTable(
                name: "LocalGovernmentUnits",
                schema: "pfm",
                columns: table => new
                {
                    LocalGovernmentUnitID = table.Column<byte>(type: "tinyint", nullable: false),
                    LocalGovernmentUnitName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LocalGovernmentUnits", x => x.LocalGovernmentUnitID);
                });

            migrationBuilder.CreateTable(
                name: "UserGroups",
                schema: "dbo",
                columns: table => new
                {
                    UserGroupID = table.Column<short>(type: "smallint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserGroups", x => x.UserGroupID);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                schema: "dbo",
                columns: table => new
                {
                    UserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false, defaultValueSql: "NEWID()"),
                    ValidFrom = table.Column<DateTime>(type: "datetime", nullable: false),
                    ValidTo = table.Column<DateTime>(type: "datetime", nullable: false),
                    FirstNameEnc = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastNameEnc = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailEnc = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserNameEnc = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PasswordSalt = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailCode = table.Column<Guid>(type: "uniqueidentifier", nullable: false, defaultValueSql: "NEWID()"),
                    LanguageId = table.Column<int>(type: "int", nullable: false),
                    IsDirectoryUser = table.Column<bool>(type: "bit", nullable: false),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserID);
                });

            migrationBuilder.CreateTable(
                name: "AccountCategories",
                schema: "pfm",
                columns: table => new
                {
                    AccountCategoryID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AccountCategoryName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Information = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AccountTypeID = table.Column<byte>(type: "tinyint", nullable: false),
                    EntityID = table.Column<byte>(type: "tinyint", nullable: false),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AccountCategories", x => x.AccountCategoryID);
                    table.ForeignKey(
                        name: "FK_AccountCategories_AccountTypes_AccountTypeID",
                        column: x => x.AccountTypeID,
                        principalSchema: "pfm",
                        principalTable: "AccountTypes",
                        principalColumn: "AccountTypeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Municipalities",
                schema: "pfm",
                columns: table => new
                {
                    MunicipalityID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EntityID = table.Column<byte>(type: "tinyint", nullable: false),
                    Slug = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    MunicipalityName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LocalGovernmentUnitID = table.Column<byte>(type: "tinyint", nullable: false),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Municipalities", x => x.MunicipalityID);
                    table.ForeignKey(
                        name: "FK_Municipalities_Entities_EntityID",
                        column: x => x.EntityID,
                        principalSchema: "pfm",
                        principalTable: "Entities",
                        principalColumn: "EntityID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Municipalities_LocalGovernmentUnits_LocalGovernmentUnitID",
                        column: x => x.LocalGovernmentUnitID,
                        principalSchema: "pfm",
                        principalTable: "LocalGovernmentUnits",
                        principalColumn: "LocalGovernmentUnitID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserGroupActionRel",
                schema: "dbo",
                columns: table => new
                {
                    UserGroupAndActionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserGroupID = table.Column<short>(type: "smallint", nullable: false),
                    ActionID = table.Column<int>(type: "int", nullable: false),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserGroupActionRel", x => x.UserGroupAndActionID);
                    table.ForeignKey(
                        name: "FK_UserGroupActionRel_Actions_ActionID",
                        column: x => x.ActionID,
                        principalSchema: "dbo",
                        principalTable: "Actions",
                        principalColumn: "ActionID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_UserGroupActionRel_UserGroups_UserGroupID",
                        column: x => x.UserGroupID,
                        principalSchema: "dbo",
                        principalTable: "UserGroups",
                        principalColumn: "UserGroupID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserActionRel",
                schema: "dbo",
                columns: table => new
                {
                    UserAndActionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ActionID = table.Column<int>(type: "int", nullable: false),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserActionRel", x => x.UserAndActionID);
                    table.ForeignKey(
                        name: "FK_UserActionRel_Actions_ActionID",
                        column: x => x.ActionID,
                        principalSchema: "dbo",
                        principalTable: "Actions",
                        principalColumn: "ActionID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_UserActionRel_Users_UserID",
                        column: x => x.UserID,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "UserID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserGroupUserRel",
                schema: "dbo",
                columns: table => new
                {
                    UserAndGroupID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserGroupID = table.Column<short>(type: "smallint", nullable: false),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserGroupUserRel", x => x.UserAndGroupID);
                    table.ForeignKey(
                        name: "FK_UserGroupUserRel_UserGroups_UserGroupID",
                        column: x => x.UserGroupID,
                        principalSchema: "dbo",
                        principalTable: "UserGroups",
                        principalColumn: "UserGroupID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_UserGroupUserRel_Users_UserID",
                        column: x => x.UserID,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "UserID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BudgetPositions",
                schema: "pfm",
                columns: table => new
                {
                    BudgetPositionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BudgetPositionName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AccountCategoryID = table.Column<int>(type: "int", nullable: false),
                    Archived = table.Column<bool>(type: "bit", nullable: false),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BudgetPositions", x => x.BudgetPositionID);
                    table.ForeignKey(
                        name: "FK_BudgetPositions_AccountCategories_AccountCategoryID",
                        column: x => x.AccountCategoryID,
                        principalSchema: "pfm",
                        principalTable: "AccountCategories",
                        principalColumn: "AccountCategoryID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "AccountCategoryData",
                schema: "pfm",
                columns: table => new
                {
                    AccountCategoryDataID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AccountCategoryID = table.Column<int>(type: "int", nullable: false),
                    MunicipalityID = table.Column<int>(type: "int", nullable: false),
                    Year = table.Column<int>(type: "int", nullable: false),
                    TotalPlannedValue = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    TotalFinalValue = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AccountCategoryData", x => x.AccountCategoryDataID);
                    table.ForeignKey(
                        name: "FK_AccountCategoryData_AccountCategories_AccountCategoryID",
                        column: x => x.AccountCategoryID,
                        principalSchema: "pfm",
                        principalTable: "AccountCategories",
                        principalColumn: "AccountCategoryID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_AccountCategoryData_Municipalities_MunicipalityID",
                        column: x => x.MunicipalityID,
                        principalSchema: "pfm",
                        principalTable: "Municipalities",
                        principalColumn: "MunicipalityID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserMunicipalityRel",
                schema: "pfm",
                columns: table => new
                {
                    UserAndMunicipalityID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    MunicipalityID = table.Column<int>(type: "int", nullable: false),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserMunicipalityRel", x => x.UserAndMunicipalityID);
                    table.ForeignKey(
                        name: "FK_UserMunicipalityRel_Municipalities_MunicipalityID",
                        column: x => x.MunicipalityID,
                        principalSchema: "pfm",
                        principalTable: "Municipalities",
                        principalColumn: "MunicipalityID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_UserMunicipalityRel_Users_UserID",
                        column: x => x.UserID,
                        principalSchema: "dbo",
                        principalTable: "Users",
                        principalColumn: "UserID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "BudgetData",
                schema: "pfm",
                columns: table => new
                {
                    BudgetDataID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Year = table.Column<int>(type: "int", nullable: false),
                    MunicipalityID = table.Column<int>(type: "int", nullable: false),
                    BudgetPositionID = table.Column<int>(type: "int", nullable: false),
                    PlannedValue = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    FinalValue = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SysCreatedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SysCreatedDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    SysLastModifiedByUserID = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SysLastModifiedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Retired = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BudgetData", x => x.BudgetDataID);
                    table.ForeignKey(
                        name: "FK_BudgetData_BudgetPositions_BudgetPositionID",
                        column: x => x.BudgetPositionID,
                        principalSchema: "pfm",
                        principalTable: "BudgetPositions",
                        principalColumn: "BudgetPositionID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BudgetData_Municipalities_MunicipalityID",
                        column: x => x.MunicipalityID,
                        principalSchema: "pfm",
                        principalTable: "Municipalities",
                        principalColumn: "MunicipalityID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                schema: "pfm",
                table: "AccountTypes",
                columns: new[] { "AccountTypeID", "AccountTypeName", "Retired" },
                values: new object[,]
                {
                    { (byte)1, "Budžetski prihodi", false },
                    { (byte)2, "Budžetski rashodi", false }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "Actions",
                columns: new[] { "ActionID", "ActionEnumerationName", "ActionName", "Description", "Retired", "SysCreatedByUserID", "SysCreatedDate", "SysLastModifiedByUserID", "SysLastModifiedDate" },
                values: new object[,]
                {
                    { 1, "ADMIN_USER_CREATE", "Create User", "", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3402), null, null },
                    { 2, "ADMIN_USER_READ", "View User", "", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3404), null, null },
                    { 3, "ADMIN_USER_EDIT", "Edit User", "", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3407), null, null },
                    { 4, "ADMIN_USER_DELETE", "Delete User", "", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3409), null, null },
                    { 5, "ADMIN_USERS_OVERVIEW", "Users Overview", "", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3411), null, null }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "AuditLogEnumerations",
                columns: new[] { "AuditLogEnumerationID", "AuditLogEnumerationDescription", "AuditLogEnumerationText", "Retired", "SysCreatedByUserID", "SysCreatedDate", "SysLastModifiedByUserID", "SysLastModifiedDate" },
                values: new object[,]
                {
                    { 1, "Log-in", "User <username> logged in.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3533), null, null },
                    { 2, "Log-out", "User <username> logged out.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3536), null, null },
                    { 3, "User registration", "User <username> has been registered.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3539), null, null },
                    { 4, "User creation", "User <username> has been created.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3541), null, null },
                    { 5, "Email notifications sent", "Email notification <emailNotificationName> has been sent to <username>.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3543), null, null },
                    { 6, "Forgotten password reset", "User <username> requested password reset.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3545), null, null }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "EmailNotifications",
                columns: new[] { "EmailNotificationID", "EmailDescription", "EmailStatus", "EmailSubject", "EmailText", "SysCreatedByUserID", "SysDateCreated", "SysDateLastModified", "SysModifiedByUserID" },
                values: new object[,]
                {
                    { 1, "EmailPasswordSetup", 1, "Setup your password", "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n        /* Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Dear <Name> ,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    You have been added as user on the system. \r\n                                                    <br>\r\n                                                    Your username is: <b> <Username> </b> .\r\n                                                    \r\n                                                    <br>\r\n                                                    <br>\r\n                                                    We kindly ask you that by clicking on the following link <ConfirmationLink> , you choose the password for using the system.\r\n                                                    <br>\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>", 1, new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3521), null, null },
                    { 2, "EmailPasswordReset", 1, "Reset your password", "<!DOCTYPE html>\r\n<html lang=\"en\">\r\n\r\n<head>\r\n\r\n    <title>Salted | A Responsive Email Template</title>\r\n    <meta charset=\"utf-8\" />\r\n    <meta name=\"viewport\" content=\"width=device-width\" />\r\n    <style type=\"text/css\">\r\n        /* CLIENT-SPECIFIC STYLES */\r\n\r\n        #outlook a {\r\n            padding: 0;\r\n        }\r\n        /* Force Outlook to provide a \"view in browser\" message */\r\n        .ReadMsgBody {\r\n            width: 100%;\r\n        }\r\n\r\n        .ExternalClass {\r\n            width: 100%;\r\n        }\r\n            /*\r\n                                  Force Hotmail to display emails at full width */\r\n            .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {\r\n                line-height: 100%;\r\n            }\r\n        /* Force Hotmail to display normal line spacing */\r\n\r\n        body, table, td, a {\r\n            -webkit-text-size-adjust: 100%;\r\n            -ms-text-size-adjust: 100%;\r\n        }\r\n        /* Prevent WebKit and Windows mobile changing default text sizes */\r\n\r\n        table, td {\r\n            mso-table-lspace: 0pt;\r\n            mso-table-rspace: 0pt;\r\n        }\r\n        /* Remove spacing between tables in Outlook 2007 and up */\r\n\r\n        img {\r\n            -ms-interpolation-mode: bicubic;\r\n        }\r\n        /* Allow smoother rendering of resized image in Internet Explorer */ /* RESET STYLES */\r\n\r\n        body {\r\n            margin: 0;\r\n            padding: 0;\r\n        }\r\n\r\n        img {\r\n            border: 0;\r\n            height: auto;\r\n            line-height: 100%;\r\n            outline: none;\r\n            text-decoration: none;\r\n        }\r\n\r\n        table {\r\n            border-collapse: collapse !important;\r\n        }\r\n\r\n        body {\r\n            height: 100% !important;\r\n            margin: 0;\r\n            padding: 0;\r\n            width: 100% !important;\r\n        }\r\n        /* iOS BLUE LINKS */\r\n\r\n        .appleBody a {\r\n            color: #68440a;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .appleFooter a {\r\n            color: #999999;\r\n            text-decoration: none;\r\n        }\r\n        /* MOBILE STYLES */\r\n\r\n        @media screen and (max-width: 525px) { /* ALLOWS FOR FLUID TABLES */\r\n\r\n            table[class=\"wrapper\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* ADJUSTS LAYOUT OF LOGO IMAGE */\r\n\r\n            td[class=\"logo\"] {\r\n                text-align: left;\r\n                padding: 20px 0 20px 0 !important;\r\n            }\r\n\r\n                td[class=\"logo\"] img {\r\n                    margin: 0 auto !important;\r\n                }\r\n            /* USE THESE CLASSES TO HIDE CONTENT ON MOBILE */\r\n\r\n            td[class=\"mobile-hide\"] {\r\n                display: none;\r\n            }\r\n\r\n            img[class=\"mobile-hide\"] {\r\n                display: none !important;\r\n            }\r\n\r\n            img[class=\"img-max\"] {\r\n                max-width: 100% !important;\r\n                height: auto !important;\r\n            }\r\n            /* FULL-WIDTH TABLES */\r\n\r\n            table[class=\"responsive-table\"] {\r\n                width: 100% !important;\r\n            }\r\n            /* UTILITY CLASSES FOR ADJUSTING PADDING ON MOBILE */\r\n\r\n            td[class=\"padding\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            td[class=\"padding-copy\"] {\r\n                padding: 10px 5% 10px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"padding-meta\"] {\r\n                padding: 30px 5% 0px 5% !important;\r\n                text-align: center;\r\n            }\r\n\r\n            td[class=\"no-pad\"] {\r\n                padding: 0 0 20px 0 !important;\r\n            }\r\n\r\n            td[class=\"no-padding\"] {\r\n                padding: 0 !important;\r\n            }\r\n\r\n            td[class=\"section-padding\"] {\r\n                padding: 50px 15px 50px 15px !important;\r\n            }\r\n\r\n            td[class=\"section-padding-bottom-image\"] {\r\n                padding: 50px 15px 0 15px !important;\r\n            }\r\n            /* ADJUST BUTTONS ON MOBILE */\r\n\r\n            td[class=\"mobile-wrapper\"] {\r\n                padding: 10px 5% 15px 5% !important;\r\n            }\r\n\r\n            table[class=\"mobile-button-container\"] {\r\n                margin: 0 auto;\r\n                width: 100% !important;\r\n            }\r\n\r\n            a[class=\"mobile-button\"] {\r\n                width: 80% !important;\r\n                padding: 15px !important;\r\n                border: 0 !important;\r\n                font-size: 16px !important;\r\n            }\r\n        }\r\n    </style>\r\n</head>\r\n\r\n<body style=\"margin: 0; padding: 0;\">\r\n    <header>\r\n        <nav class=\"navbar sticky-top navbar-expand-lg header-cefta\">\r\n            <div class=\"container-fluid\">\r\n                <div class=\"collapse navbar-collapse\" id=\"navbarNavAltMarkup\">\r\n                    <Logo1>\r\n                        <div style=\"float:left; margin-left:13px; \">\r\n                            <img src=\"\">\r\n                        </div>\r\n                </div>\r\n            </div>\r\n        </nav>\r\n\r\n    </header>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\">\r\n                <div align=\"left\" style=\"padding: 0px 15px 0px 15px;\">\r\n                    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"wrapper\">\r\n                        <tr>\r\n                            <td style=\"padding: 20px 0px 30px 0px;\">\r\n\r\n                                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n                                    <tr>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"left\" style=\"font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\">\r\n                                        </td>\r\n                                        <td bgcolor=\"#ffffff\" width=\"500\" align=\"right\" class=\"mobile-hide\">\r\n                                            <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n                                                <tr>\r\n                                                    <td align=\"right\" style=\"padding: 0 0 5px 0; font-size: 12px; font-family: Arial, sans-serif; color: #666666; text-decoration: none;\"><span style=\"color: #666666; text-decoration: none;\"></span></td>\r\n                                                </tr>\r\n                                            </table>\r\n                                        </td>\r\n                                    </tr>\r\n                                </table>\r\n                            </td>\r\n                        </tr>\r\n                    </table>\r\n                </div>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n        <tr>\r\n            <td bgcolor=\"#ffffff\" align=\"left\" style=\"padding: 0px 15px 20px 15px;\" class=\"section-padding\">\r\n                <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\" class=\"responsive-table\">\r\n                    <tr>\r\n                        <td>\r\n                            <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                <tr>\r\n                                    <td>\r\n                                        <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n                                            <tr>\r\n                                                <td align=\"left\" style=\"font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #333333;\" class=\"padding-copy\">\r\n\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    Dear <Name> ,\r\n                                                    <br>\r\n                                                    <br>\r\n                                                    To change your password, click on the following link: <ConfirmationLink>\r\n                                                    <br>\r\n                                                    Your username is: <Username> .\r\n                                                    <br>\r\n                                                </td>\r\n                                            </tr>\r\n                                        </table>\r\n                                    </td>\r\n                                </tr>\r\n                                <tr> <td> <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"mobile-button-container\"> <tr> <td align=\"left\" style=\"padding: 25px 0 0 0;\" class=\"padding-copy\"> <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"responsive-table\"> <tr> <td align=\"left\"></td></tr></table> </td></tr></table> </td></tr>\r\n                            </table>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n            </td>\r\n        </tr>\r\n    </table>\r\n</body>\r\n</html>", 1, new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3523), null, null }
                });

            migrationBuilder.InsertData(
                schema: "pfm",
                table: "Entities",
                columns: new[] { "EntityID", "EntityName", "Retired" },
                values: new object[,]
                {
                    { (byte)1, "Federacija Bosne i Hercegovine", false },
                    { (byte)2, "Republika Srpska", false }
                });

            migrationBuilder.InsertData(
                schema: "pfm",
                table: "LocalGovernmentUnits",
                columns: new[] { "LocalGovernmentUnitID", "LocalGovernmentUnitName" },
                values: new object[,]
                {
                    { (byte)1, "Općina" },
                    { (byte)2, "Grad" }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "UserGroups",
                columns: new[] { "UserGroupID", "Name", "Retired", "SysCreatedByUserID", "SysCreatedDate", "SysLastModifiedByUserID", "SysLastModifiedDate" },
                values: new object[,]
                {
                    { (short)1, "System Administrator", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3196), null, null },
                    { (short)2, "LGU Administrator", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3261), null, null }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "Users",
                columns: new[] { "UserID", "EmailCode", "EmailEnc", "FirstNameEnc", "IsDirectoryUser", "LanguageId", "LastNameEnc", "PasswordHash", "PasswordSalt", "Retired", "SysCreatedByUserID", "SysCreatedDate", "SysLastModifiedByUserID", "SysLastModifiedDate", "UserNameEnc", "ValidFrom", "ValidTo" },
                values: new object[] { new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new Guid("208e1ebf-2468-4302-b177-0b25e73ed482"), "St6/v49lrqKXW5W7ytqLHA==", "vOIUBnFT5Y809QUJqH4AzQ==", false, 1, "vOIUBnFT5Y809QUJqH4AzQ==", "B93ACCB02E0366BFF97B511D7816AC2D731709E826AFCB1055EAFE8A147F6A903A8AE9D53BFC22BD30A30D0510221B2F70F46EF0960BB51F7CF12D2B59A818D3", "kfOdYzluTdhj0qr452F0eyDISySC70ef7jLPEt8ZI5OFQEHTkY12cKZC7go71lYkRcJbV/jEWKGVpQJCsWWk/A==", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3492), null, null, "1/ZVbp32LhD77H7MGNgKmw==", new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3494), new DateTime(2297, 7, 26, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3495) });

            migrationBuilder.InsertData(
                schema: "pfm",
                table: "AccountCategories",
                columns: new[] { "AccountCategoryID", "AccountCategoryName", "AccountTypeID", "EntityID", "Information", "Retired", "SysCreatedByUserID", "SysCreatedDate", "SysLastModifiedByUserID", "SysLastModifiedDate" },
                values: new object[,]
                {
                    { 1, "Prihodi od poreza", (byte)1, (byte)1, "Čine ih prihodi na dobit i dohodak od pojedinca i preduzeća koji posluju na teritoriji lokalne uprave, porez na imovinu, te indirektni porezi koji pripadaju lokalnoj upravi", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 2, "Neporezni prihodi", (byte)1, (byte)1, "Najčešće se sastoje od administrativnih taksi i naknada na lokalnom nivou, komunalnih taksi i naknada, naknada za date koncesije na području lokalne uprave, naknada od rente, naknada od prometa šumom, prihoda od davanja prava na eksploataciji prirodnih resursa, vodne naknade, naknada za zaštitu prirodnih i drugih nesreća, novčanih kaznih, naknada za upotrebu cesta za vozila, sredstava za finansiranje požara, prihoda od pružanja usluga i slično.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 3, "Tekući transferi i donacije", (byte)1, (byte)1, "Uključuju novčane transfere sa viših nivoa vlasti vezano za različita davanja pojedincima, javnim ustanovama, neprofitnim i nevladinim organizacijama i udruženjima registrovanim na području lokalne uprave.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 4, "Kapitalni transferi", (byte)1, (byte)1, "Novčane pomoći sa viših nivoa vlasti vezani za dugoročne/ višegodišnje projekte i davanja na području lokalne uprave.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 5, "Kapitalni primici", (byte)1, (byte)1, "Sredstva dobijena prodajom stalne imovine kao što je zemljište, stambeni objekti i finansijska imovina.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 6, "Krediti", (byte)1, (byte)1, "Sredstva iz finansijskih zaduživanja.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 7, "Suficit prethodnih godina", (byte)1, (byte)1, "Ukoliko postoje, ovo su neutrošena sredstva iz prethodnih godina koja se prenose u tekuću budžetsku godinu, te time povećavaju prihodovnu stranu budžeta.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 8, "Plate i naknade zaposlenih", (byte)2, (byte)1, "Sredstva za plate, naknade, doprinose zaposlenih u lokalnim upravama i organima javnih institucija na području lokalne uprave.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 9, "Materijalni troškovi", (byte)2, (byte)1, "Najčešće se sastoje od administrativnih taksi i naknada, izdataka za energiju, prevoz i komunikaciju, troškova održavanja, troškova učešća u zajedničkim projektima od značaja za lokalnu upravu, sredstava za zaštitu od prirodnih i drugih nesreća, nakada za rad mjesnih zajednica, sredstava za zaštitu od požara, rashodi po osnovu putovanja i smještaja i slično.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 10, "Komunalne usluge", (byte)2, (byte)1, "Sredstva za održavanje cesta i puteva, javne rasvjete, zelenih površina, rada zimske službe, održavanje i sanacije vodovodne i kanalizacione mreže, zbrinjavanja pasa lutalica, i slično.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 11, "Tekući transferi", (byte)2, (byte)1, "Pokrivaju jednokratna davanja javnim ustanovama na području lokalne uprave, izdatke za sport i kulturu, troškove prevoza učenika, različita socijalna davanja, stipendije nadarenim učenicima i sportistima, subvencije poljoprivredi, malom biznisu i poduzetništvu, transfere nevladinom sektoru, boračkoj populaciji i projektima od važnosti za mlade.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 12, "Kapitalni transferi", (byte)2, (byte)1, "Odnose se na kapitalne doznake i pomoći lokalnoj upravi, neprofitnim organizacijama i pojedincima, te javnim preduzećima.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 13, "Kapitalni izdaci", (byte)2, (byte)1, "Sredstva za izgradnju putne, vodovodne i kanalizacione infrastrukture, izgradnje objekata od važnosti za funkcionisanje lokalne uprave, sportsko-rekreativnih kapaciteta, objekata od kulturno-historijskog značaja, unapređenja javne rasvjete, izgradnju grobalja, poslovnih zona i slično.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 14, "Otplate duga", (byte)2, (byte)1, "Otplata duga jedinice lokalne samouprave", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 15, "Tekuća rezerva", (byte)2, (byte)1, "Tekuća rezerva jedinice lokalne samouprave", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 16, "Raspored akumulisanog suficita", (byte)2, (byte)1, "Suficit (neutrošena sredstva) jedinice lokalne samouprave", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 17, "Prihodi od poreza", (byte)1, (byte)2, "Čine ih prihodi na dobit i dohodak od pojedinca i preduzeća koji posluju na teritoriji lokalne uprave, porez na imovinu, te indirektni porezi koji pripadaju lokalnoj upravi.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 18, "Neporeski prihodi", (byte)1, (byte)2, "Najčešće se sastoje od administrativnih taksi i naknada na lokalnom nivou, komunalnih taksi i naknada, naknada za date koncesije na području lokalne uprave, naknada od rente, naknada od prometa šumom, prihoda od davanja prava na eksploataciji prirodnih resursa, vodne naknade, naknada za zaštitu prirodnih i drugih nesreća, novčanih kaznih, naknada za upotrebu cesta za vozila, sredstava za finansiranje požara, prihoda od pružanja usluga i slično.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 19, "Grantovi i transferi", (byte)1, (byte)2, "Uključuju novčane transfere sa viših nivoa vlasti vezano za različita davanja pojedincima, javnim ustanovama, neprofitnim i nevladinim organizacijama i udruženjima registrovanim na području lokalne uprave.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 20, "Kapitalni grantovi", (byte)1, (byte)2, "Novčane pomoći sa viših nivoa vlasti vezani za dugoročne/ višegodišnje projekte i davanja na području lokalne uprave.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 21, "Finansiranje", (byte)1, (byte)2, "Sredstva dobijena prodajom stalne imovine kao što je zemljište, stambeni objekti i finansijska imovina", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 22, "Primici od finansijske imovine i zaduživanja", (byte)1, (byte)2, "Sredstva iz finansijskih zaduživanja.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 23, "Raspodjela suficita iz prethodnih godina", (byte)1, (byte)2, "Ukoliko postoje, ovo su neutrošena sredstva iz prethodnih godina koja se prenose u tekuću budžetsku godinu, te time povećavaju prihodovnu stranu budžeta.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 24, "Rashodi na lična primanja", (byte)2, (byte)2, "Sredstva za plate, naknade, doprinose zaposlenih u lokalnim upravama i organima javnih institucija na području lokalne uprave.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 25, "Rashodi po osnovu korištenja roba i usluga", (byte)2, (byte)2, "Najčešće se sastoje od administrativnih taksi i naknada, izdataka za energiju, prevoz i komunikaciju, troškova održavanja, troškova učešća u zajedničkim projektima od značaja za lokalnu upravu, sredstava za zaštitu od prirodnih i drugih nesreća, nakada za rad mjesnih zajednica, sredstava za zaštitu od požara, rashodi po osnovu putovanja i smještaja i slično.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 26, "Komunalne usluge", (byte)2, (byte)2, "Sredstva za održavanje cesta i puteva, javne rasvjete, zelenih površina, rada zimske službe, održavanje i sanacije vodovodne i kanalizacione mreže, zbrinjavanja pasa lutalica, i slično.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 27, "Tekući grantovi, subvencije i transferi", (byte)2, (byte)2, "Pokrivaju jednokratna davanja javnim ustanovama na području lokalne uprave, izdatke za sport i kulturu, troškove prevoza učenika, različita socijalna davanja, stipendije nadarenim učenicima i sportistima, subvencije poljoprivredi, malom biznisu i poduzetništvu, transfere nevladinom sektoru, boračkoj populaciji i projektima od važnosti za mlade.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 28, "Kapitalni grantovi i doznake", (byte)2, (byte)2, "Odnose se na kapitalne doznake i pomoći lokalnoj upravi, neprofitnim organizacijama i pojedincima, te javnim preduzećima.", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 29, "Izdaci za nefinansijsku imovinu", (byte)2, (byte)2, "Sredstva za izgradnju putne, vodovodne i kanalizacione infrastrukture, izgradnje objekata od važnosti za funkcionisanje lokalne uprave, sportsko-rekreativnih kapaciteta, objekata od kulturno-historijskog značaja, unapređenja javne rasvjete, izgradnju grobalja, poslovnih zona i slično", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 30, "Izdaci za finansijsku imovinu i otplate dugova", (byte)2, (byte)2, "Izdaci za finansijsku imovinu i otplate dugova jedinice lokalne samopurave", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 31, "Budžetska rezerva", (byte)2, (byte)2, "Budžetska rezerva jedinice lokalne samopurave", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 32, "Raspored akumulisanog suficita", (byte)2, (byte)2, "Suficit (neutrošena sredstva) jedinice lokalne samopurave", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null }
                });

            migrationBuilder.InsertData(
                schema: "pfm",
                table: "Municipalities",
                columns: new[] { "MunicipalityID", "EntityID", "LocalGovernmentUnitID", "MunicipalityName", "Retired", "Slug", "SysCreatedByUserID", "SysCreatedDate", "SysLastModifiedByUserID", "SysLastModifiedDate" },
                values: new object[,]
                {
                    { 1, (byte)2, (byte)1, "Trebinje", true, "trebinje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3907), null, null },
                    { 2, (byte)2, (byte)1, "Bileća", true, "bileca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3910), null, null },
                    { 3, (byte)2, (byte)1, "Ljubinje", true, "ljubinje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3913), null, null },
                    { 4, (byte)2, (byte)1, "Berkovići", true, "berkovici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3915), null, null },
                    { 5, (byte)2, (byte)1, "Gacko", true, "gacko", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3917), null, null },
                    { 6, (byte)2, (byte)1, "Nevesinje", true, "nevesinje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3920), null, null },
                    { 7, (byte)2, (byte)1, "Istočni Mostar", true, "istocni-mostar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3922), null, null },
                    { 8, (byte)2, (byte)1, "Foča", true, "foca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3924), null, null },
                    { 9, (byte)2, (byte)1, "Čajniče", true, "cajnice", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3926), null, null },
                    { 10, (byte)2, (byte)1, "Milići", true, "milici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3929), null, null },
                    { 11, (byte)2, (byte)1, "Srebrenica", true, "srebrenica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3931), null, null },
                    { 12, (byte)2, (byte)1, "Bratunac", true, "bratunac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3933), null, null },
                    { 13, (byte)2, (byte)1, "Vlasenica", true, "vlasenica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3935), null, null },
                    { 14, (byte)2, (byte)1, "Šekovići", true, "sekovici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3937), null, null },
                    { 15, (byte)2, (byte)1, "Osmaci", true, "osmaci", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3940), null, null },
                    { 16, (byte)2, (byte)1, "Zvornik", true, "zvornik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3942), null, null },
                    { 17, (byte)2, (byte)1, "Lopare", false, "lopare", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3944), null, null },
                    { 18, (byte)2, (byte)1, "Ugljevik", true, "ugljevik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3946), null, null },
                    { 19, (byte)2, (byte)1, "Bijeljina", true, "bijeljina", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3948), null, null },
                    { 20, (byte)2, (byte)1, "Srbac", true, "srbac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3951), null, null },
                    { 21, (byte)2, (byte)1, "Prnjavor", true, "prnjavor", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3953), null, null },
                    { 22, (byte)2, (byte)1, "Laktaši", true, "laktasi", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3956), null, null },
                    { 23, (byte)2, (byte)1, "Teslić", false, "teslic", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3959), null, null },
                    { 24, (byte)2, (byte)1, "Čelinac", true, "celinac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3961), null, null },
                    { 25, (byte)2, (byte)1, "Kotor Varoš", true, "kotor-varos", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3963), null, null },
                    { 26, (byte)2, (byte)1, "Kneževo", true, "knezevo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3965), null, null },
                    { 27, (byte)2, (byte)1, "Kupres", true, "kupres-rs", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3989), null, null },
                    { 28, (byte)2, (byte)1, "Šipovo", true, "sipovo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3992), null, null },
                    { 29, (byte)2, (byte)1, "Jezero", true, "jezero", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3994), null, null },
                    { 30, (byte)2, (byte)1, "Mrkonjić Grad", true, "mrkonjic-grad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3996), null, null },
                    { 31, (byte)2, (byte)1, "Istočni Drvar", true, "istocni-drvar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3998), null, null },
                    { 32, (byte)2, (byte)1, "Petrovac", true, "petrovac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4001), null, null },
                    { 33, (byte)2, (byte)1, "Ribnik", true, "ribnik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4004), null, null },
                    { 34, (byte)2, (byte)1, "Banja Luka", true, "banja-luka", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4008), null, null },
                    { 35, (byte)2, (byte)1, "Gradiška", true, "gradiska", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4010), null, null },
                    { 36, (byte)2, (byte)1, "Kozarska Dubica", true, "kozarska-dubica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4012), null, null },
                    { 37, (byte)2, (byte)1, "Kostajnica", true, "kostajnica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4015), null, null },
                    { 38, (byte)2, (byte)1, "Krupa na Uni", true, "krupa-na-uni", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4018), null, null },
                    { 39, (byte)2, (byte)1, "Novi Grad", true, "novi-grad-rs", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4022), null, null },
                    { 40, (byte)2, (byte)1, "Prijedor", true, "prijedor", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4024), null, null },
                    { 41, (byte)2, (byte)1, "Oštra Luka", true, "ostra-luka", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4028), null, null },
                    { 42, (byte)2, (byte)1, "Kalinovik", true, "kalinovik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4030), null, null },
                    { 43, (byte)2, (byte)1, "Ustiprača", true, "ustipraca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4032), null, null },
                    { 44, (byte)2, (byte)1, "Istočna Ilidža", true, "istocna-ilidza", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4034), null, null },
                    { 45, (byte)2, (byte)1, "Istočno Novo Sarajevo", true, "istocno-novo-sarajevo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4037), null, null },
                    { 46, (byte)2, (byte)1, "Trnovo", true, "trnovo-rs", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4040), null, null },
                    { 47, (byte)2, (byte)1, "Pale", true, "pale", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4044), null, null },
                    { 48, (byte)2, (byte)1, "Rogatica", true, "rogatica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4046), null, null },
                    { 49, (byte)2, (byte)1, "Istočni Stari Grad", true, "istocni-stari-grad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4048), null, null },
                    { 50, (byte)2, (byte)1, "Sokolac", true, "sokolac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4050), null, null },
                    { 51, (byte)2, (byte)1, "Han Pijesak", true, "han-pijesak", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4053), null, null },
                    { 52, (byte)2, (byte)1, "Rudo", true, "rudo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4055), null, null },
                    { 53, (byte)2, (byte)1, "Višegrad", true, "visegrad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4057), null, null },
                    { 54, (byte)2, (byte)1, "Šamac", false, "samac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4059), null, null },
                    { 55, (byte)2, (byte)1, "Petrovo", true, "petrovo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4061), null, null },
                    { 56, (byte)2, (byte)1, "Doboj", true, "doboj", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4063), null, null },
                    { 57, (byte)2, (byte)1, "Brod", true, "brod", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4066), null, null },
                    { 58, (byte)2, (byte)1, "Derventa", true, "derventa", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4069), null, null },
                    { 59, (byte)2, (byte)1, "Pelagićevo", true, "pelagicevo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4071), null, null },
                    { 60, (byte)2, (byte)1, "Donji Žabar", true, "donji-zabar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4073), null, null },
                    { 61, (byte)2, (byte)1, "Vukosavlje", true, "vukosavlje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4075), null, null },
                    { 62, (byte)2, (byte)1, "Modriča", true, "modrica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4077), null, null },
                    { 63, (byte)1, (byte)1, "Foča-Ustikolina", true, "foca-ustikolina", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4080), null, null },
                    { 64, (byte)1, (byte)1, "Goražde", true, "gorazde", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4082), null, null },
                    { 65, (byte)1, (byte)1, "Pale-Prača", true, "pale-praca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4084), null, null },
                    { 66, (byte)1, (byte)1, "Stari Grad Sarajevo", true, "stari-grad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4086), null, null },
                    { 67, (byte)1, (byte)1, "Centar Sarajevo", true, "centar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4088), null, null },
                    { 68, (byte)1, (byte)1, "Novo Sarajevo", true, "novo-sarajevo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4090), null, null },
                    { 69, (byte)1, (byte)1, "Novi Grad Sarajevo", true, "novi-grad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4092), null, null },
                    { 70, (byte)1, (byte)1, "Trnovo", true, "trnovo-fbih", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4096), null, null },
                    { 71, (byte)1, (byte)1, "Ilijaš", true, "ilijas", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4098), null, null },
                    { 72, (byte)1, (byte)1, "Hadžići", true, "hadzici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4100), null, null },
                    { 73, (byte)1, (byte)1, "Ilidža", true, "ilidza", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4102), null, null },
                    { 74, (byte)1, (byte)1, "Vogošća", true, "vogosca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4104), null, null },
                    { 75, (byte)1, (byte)1, "Gornji Vakuf-Uskoplje", true, "gornji-vakuf-uskoplje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4106), null, null },
                    { 76, (byte)1, (byte)1, "Fojnica", true, "fojnica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4109), null, null },
                    { 77, (byte)1, (byte)1, "Kreševo", true, "kresevo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4111), null, null },
                    { 78, (byte)1, (byte)1, "Kiseljak", true, "kiseljak", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4113), null, null },
                    { 79, (byte)1, (byte)1, "Busovača", true, "busovaca", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4115), null, null },
                    { 80, (byte)1, (byte)1, "Vitez", true, "vitez", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4117), null, null },
                    { 81, (byte)1, (byte)1, "Novi Travnik", true, "novi-travnik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4142), null, null },
                    { 82, (byte)1, (byte)1, "Bugojno", true, "bugojno", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4145), null, null },
                    { 83, (byte)1, (byte)1, "Donji Vakuf", true, "donji-vakuf", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4148), null, null },
                    { 84, (byte)1, (byte)1, "Jajce", true, "jajce", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4150), null, null },
                    { 85, (byte)1, (byte)1, "Dobretići", true, "dobretici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4153), null, null },
                    { 86, (byte)1, (byte)1, "Travnik", true, "travnik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4155), null, null },
                    { 87, (byte)1, (byte)1, "Breza", true, "breza", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4157), null, null },
                    { 88, (byte)1, (byte)1, "Olovo", true, "olovo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4159), null, null },
                    { 89, (byte)1, (byte)1, "Vareš", false, "vares", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4161), null, null },
                    { 90, (byte)1, (byte)1, "Visoko", true, "visoko", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4164), null, null },
                    { 91, (byte)1, (byte)1, "Kakanj", true, "kakanj", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4166), null, null },
                    { 92, (byte)1, (byte)2, "Zenica", false, "zenica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4168), null, null },
                    { 93, (byte)1, (byte)2, "Zavidovići", false, "zavidovici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4170), null, null },
                    { 94, (byte)1, (byte)1, "Žepče", false, "zepce", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4173), null, null },
                    { 95, (byte)1, (byte)1, "Maglaj", true, "maglaj", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4175), null, null },
                    { 96, (byte)1, (byte)1, "Tešanj", true, "tesanj", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4178), null, null },
                    { 97, (byte)1, (byte)1, "Doboj-Jug", true, "doboj-jug", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4180), null, null },
                    { 98, (byte)1, (byte)1, "Usora", true, "usora", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4182), null, null },
                    { 99, (byte)1, (byte)1, "Ljubuški", true, "ljubuski", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4184), null, null },
                    { 100, (byte)1, (byte)1, "Grude", true, "grude", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4186), null, null },
                    { 101, (byte)1, (byte)1, "Široki Brijeg", true, "siroki-brijeg", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4188), null, null },
                    { 102, (byte)1, (byte)1, "Posušje", true, "posusje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4190), null, null },
                    { 103, (byte)1, (byte)1, "Neum", true, "neum", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4192), null, null },
                    { 104, (byte)1, (byte)1, "Ravno", true, "ravno", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4195), null, null },
                    { 105, (byte)1, (byte)1, "Stolac", true, "stolac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4197), null, null },
                    { 106, (byte)1, (byte)1, "Mostar", true, "mostar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4200), null, null },
                    { 107, (byte)1, (byte)1, "Konjic", true, "konjic", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4202), null, null },
                    { 108, (byte)1, (byte)1, "Čapljina", true, "capljina", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4205), null, null },
                    { 109, (byte)1, (byte)1, "Čitluk", true, "citluk", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4207), null, null },
                    { 110, (byte)1, (byte)1, "Jablanica", true, "jablanica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4209), null, null },
                    { 111, (byte)1, (byte)1, "Prozor-Rama", true, "prozor-rama", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4211), null, null },
                    { 112, (byte)1, (byte)1, "Tomislavgrad", true, "tomislavgrad", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4213), null, null },
                    { 113, (byte)1, (byte)1, "Kupres", true, "kupres", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4215), null, null },
                    { 114, (byte)1, (byte)1, "Livno", true, "livno", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4218), null, null },
                    { 115, (byte)1, (byte)1, "Glamoč", true, "glamoc", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4220), null, null },
                    { 116, (byte)1, (byte)1, "Bosansko Grahovo", true, "bosansko-grahovo", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4222), null, null },
                    { 117, (byte)1, (byte)1, "Drvar", true, "drvar", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4224), null, null },
                    { 118, (byte)1, (byte)1, "Kladanj", true, "kladanj", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4227), null, null },
                    { 119, (byte)1, (byte)1, "Banovići", true, "banovici", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4229), null, null },
                    { 120, (byte)1, (byte)1, "Živinice", true, "zivinice", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4232), null, null },
                    { 121, (byte)1, (byte)1, "Lukavac", true, "lukavac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4234), null, null },
                    { 122, (byte)1, (byte)1, "Kalesija", true, "kalesija", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4236), null, null },
                    { 123, (byte)1, (byte)1, "Sapna", true, "sapna", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4238), null, null },
                    { 124, (byte)1, (byte)1, "Teočak", true, "teocak", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4240), null, null },
                    { 125, (byte)1, (byte)2, "Tuzla", false, "tuzla", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4242), null, null },
                    { 126, (byte)1, (byte)1, "Čelić", true, "celic", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4245), null, null },
                    { 127, (byte)1, (byte)1, "Srebrenik", true, "srebrenik", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4247), null, null },
                    { 128, (byte)1, (byte)1, "Doboj-Istok", true, "doboj-istok", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4249), null, null },
                    { 129, (byte)1, (byte)1, "Gračanica", true, "gracanica", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4251), null, null },
                    { 130, (byte)1, (byte)2, "Gradačac", false, "gradacac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4254), null, null },
                    { 131, (byte)1, (byte)1, "Ključ", true, "kljuc", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4256), null, null },
                    { 132, (byte)1, (byte)1, "Sanski Most", true, "sanski-most", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4258), null, null },
                    { 133, (byte)1, (byte)1, "Bosanski Petrovac", true, "bosanski-petrovac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4261), null, null },
                    { 134, (byte)1, (byte)1, "Bihać", true, "bihac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4263), null, null },
                    { 135, (byte)1, (byte)1, "Cazin", true, "cazin", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4288), null, null },
                    { 136, (byte)1, (byte)1, "Bužim", true, "buzim", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4290), null, null },
                    { 137, (byte)1, (byte)1, "Bosanska Krupa", true, "bosanska-krupa", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4293), null, null },
                    { 138, (byte)1, (byte)1, "Velika Kladuša", true, "velika-kladusa", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4295), null, null },
                    { 139, (byte)1, (byte)1, "Orašje", true, "orasje", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4297), null, null },
                    { 140, (byte)1, (byte)1, "Odžak", true, "odzak", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4299), null, null },
                    { 141, (byte)1, (byte)1, "Domaljevac-Šamac", true, "domaljevac-samac", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4302), null, null },
                    { 142, (byte)1, (byte)1, "Brčko", true, "brcko", new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(4304), null, null }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "UserActionRel",
                columns: new[] { "UserAndActionID", "ActionID", "Retired", "UserID" },
                values: new object[,]
                {
                    { 1, 5, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f") },
                    { 2, 4, false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f") }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "UserGroupActionRel",
                columns: new[] { "UserGroupAndActionID", "ActionID", "Retired", "UserGroupID" },
                values: new object[,]
                {
                    { 1, 1, false, (short)1 },
                    { 2, 2, false, (short)1 },
                    { 3, 3, false, (short)1 },
                    { 4, 4, false, (short)1 },
                    { 5, 5, false, (short)1 }
                });

            migrationBuilder.InsertData(
                schema: "dbo",
                table: "UserGroupUserRel",
                columns: new[] { "UserAndGroupID", "Retired", "UserGroupID", "UserID" },
                values: new object[] { 1, false, (short)1, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f") });

            migrationBuilder.InsertData(
                schema: "pfm",
                table: "BudgetPositions",
                columns: new[] { "BudgetPositionID", "AccountCategoryID", "Archived", "BudgetPositionName", "Retired", "SysCreatedByUserID", "SysCreatedDate", "SysLastModifiedByUserID", "SysLastModifiedDate" },
                values: new object[,]
                {
                    { 1, 1, false, "Porez na dobit i dohodak", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 2, 1, false, "Porez na imovinu", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 3, 1, false, "Indirektni porezi", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 4, 2, false, "Administrativne takse i naknade", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 5, 2, false, "Komunalne takse i naknade", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 6, 2, false, "Naknade na date koncesije", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 7, 2, false, "Naknade od rente", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 8, 2, false, "Naknada na promet šuma", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 9, 2, false, "Prihodi od davanja prava na eksploataciju prirodnih resursa, patenata i autorskih prava", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 10, 2, false, "Naknada za zaštitu od prirodnih i drugih nesreća", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 11, 2, false, "Novčane kazne", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 12, 2, false, "Naknade za upotrebu cesta za vozila građana", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 13, 2, false, "Sredstva za finansiranje zaštite od požara", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 14, 2, false, "Prihodi od pružanja javnih usluga", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 15, 2, false, "Ostalo", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 16, 3, false, "Tekući transferi i donacije", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 17, 4, false, "Kapitalni transferi", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 18, 5, false, "Primici od prodaje stalnih sredstava", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 19, 5, false, "Ostali kapitalni primici", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 20, 6, false, "Krediti", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 21, 7, false, "Suficit prethodnih godina", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 22, 8, false, "Plate i naknade zaposlenih", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 23, 9, false, "Administrativne takse i naknade", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 24, 9, false, "Izdaci za enargiju, prevoz i komunikaciju", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 25, 9, false, "Troškovi održavanja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 26, 9, false, "Učešće u zajedničkim projektima", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 27, 9, false, "Sredstva za zaštitu od prirodnih i drugih nepogoda", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 28, 9, false, "Nakade radu MZ", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 29, 9, false, "Sredstva za zaštitu od požara", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 30, 9, false, "Sredstva za zaštitu okoliša", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 31, 9, false, "Ostali materijalni troškovi", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 32, 10, false, "Održavanje cesta i puteva", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 33, 10, false, "Javna rasvjeta", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 34, 10, false, "Održavanje zelenih površina", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 35, 10, false, "Rad zimske službe", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 36, 10, false, "Održavanje i saniranje vodovoda i kanalizacije", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 37, 10, false, "Zbrinjavanje pasa lutalica", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 38, 10, false, "Ostalo", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 39, 11, false, "Tekući transferi javnim ustanovama i javnim preduzećima", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 40, 11, false, "Izdaci za sportske aktivnosti", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 41, 11, false, "Izdaci za kulturu", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 42, 11, false, "Troškovi prevoza učenika", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 43, 11, false, "Socijalna davanja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 44, 11, false, "Stipendije učenicima i sportistima", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 45, 11, false, "Poticaji poljoprivrede", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 46, 11, false, "Poticaj razvoja malog biznisa i poduzetništva", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 47, 11, false, "Transferi za OCD", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 48, 11, false, "Naknade za porodilje", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 49, 11, false, "Transferi boračkoj populaciji", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 50, 11, false, "Transferi za omladinske aktivnosti", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 51, 12, false, "Kapitalni transferi", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 52, 13, false, "Izgradnja putne infrastrukture", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 53, 13, false, "Izgradnja vodovodne i kanalizacione infrastrukture", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 54, 13, false, "Izgradnja objekata od važnosti za rad JLU", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 55, 13, false, "Izgradnja sportskih i rekreativnih objekata", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 56, 13, false, "Izgradnja objekata od kulturno-historijskog značaja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 57, 13, false, "Izgradnja javne rasvjete", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 58, 13, false, "Izgradnja i proširenje grobalja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 59, 13, false, "Izgradnja poslovnih zona", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 60, 14, false, "Otplate duga", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 61, 15, false, "Tekuća rezerva", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 62, 16, false, "Raspored akumulisanog suficita", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 63, 17, false, "Porez na dohodak, dobit i lična primanja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 64, 17, false, "Porez na imovinu", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 65, 17, false, "Indirektni porezi doznačeni od UIO", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 66, 17, false, "Ostali poreski prihodi", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 67, 18, false, "Opštinske administrativne takse", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 68, 18, false, "Komunalne takse", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 69, 18, false, "Naknada za uređenje građevinskog zemljišta", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 70, 18, false, "Naknade za razvoj nerazvijenih dijelova opštine", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 71, 18, false, "Nakada za promet šuma", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 72, 18, false, "Prihodi od davanja prava na eksploataciju prirodnih resursa, patenata i autorskih prava", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 73, 18, false, "Naknada za zaštitu od prirodnih i drugih nesreća", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 74, 18, false, "Novčane kazne", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 75, 18, false, "Naknade za korištenje puteva", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 76, 18, false, "Sredstva za finansiranje zaštite od požara", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 77, 18, false, "Naknade za vodu", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 78, 18, false, "Prihodi od pružanja javnih usluga", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 79, 18, false, "Ostali neporeski prihodi", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 80, 19, false, "Grantovi i transferi", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 81, 20, false, "Kapitalni grantovi", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 82, 21, false, "Primici od prodaje stalne imovine", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 83, 21, false, "Ostali primici", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 84, 22, false, "Primici od finansijske imovine i zaduživanja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 85, 23, false, "Raspodjela suficita iz prethodnih godina", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 86, 24, false, "Rashodi na lična primanja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 87, 25, false, "Rashodi po osnovu zakupa", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 88, 25, false, "Izdaci za energiju, prevoz i komunikaciju", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 89, 25, false, "Troškovi održavanja - režije", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 90, 25, false, "Sredstva za održavanje životne sredine", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 91, 25, false, "Nakade radu MZ", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 92, 25, false, "Sredstva za zaštitu od požara", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 93, 25, false, "Rashodi po osnovu putovanja i smještaja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 94, 25, false, "Sredstva za zaštitu okoliša", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 95, 25, false, "Ostali rashodi", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 96, 26, false, "Održavanje cesta i puteva", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 97, 26, false, "Javna rasvjeta", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 98, 26, false, "Održavanje zelenih površina", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 99, 26, false, "Rad zimske službe", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 100, 26, false, "Održavanje i saniranje vodovoda i kanalizacije", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 101, 26, false, "Zbrinjavanje pasa lutalica", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 102, 26, false, "Ostalo", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 103, 27, false, "Subvencije javnim nefinansijskim subjektima", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 104, 27, false, "Izdaci za sportske aktivnosti", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 105, 27, false, "Izdaci za kulturu", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 106, 27, false, "Troškovi prevoza učenika", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 107, 27, false, "Socijalna davanja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 108, 27, false, "Stipendije učenicima i sportistima", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 109, 27, false, "Subvencije za poljoprivredu", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 110, 27, false, "Subvencije za razvoj malog biznisa i preduzetništva", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 111, 27, false, "Transferi nevladinim organizacijama", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 112, 27, false, "Subvencije za porodilje", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 113, 27, false, "Transferi boračkoj populaciji", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 114, 27, false, "Transferi za omladinske aktivnosti", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 115, 27, false, "Ostali grantovi, transferi, subvencije", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 116, 28, false, "Kapitalni grantovi i doznake", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 117, 29, false, "Izdaci za nabavku postojenja i opreme za obrazovanje, nauku, kulturu i sport", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 118, 29, false, "Izdaci za nabavku prevoznih sredstava", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 119, 29, false, "Izdaci za izgradnju i pribavljanje stambenih objekata", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 120, 29, false, "Izgradnja i održavanje vodovodne i kanalizacione infrastrukture", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 121, 29, false, "Izgradnja i održavanje saobraćajnih objekata", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 122, 29, false, "Izgradnja i održavanje sportskih i rekreativnih objekata", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 123, 29, false, "Izgradnja i održavanje objekata od kulturno-historijskog značaja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 124, 29, false, "Izgradnja i održavanje javne rasvjete", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 125, 29, false, "Izgradnja i proširenje grobalja", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 126, 29, false, "Ostali nefinansijski izdaci", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 127, 30, false, "Izdaci za finansijsku imovinu i otplate dugova", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 128, 31, false, "Budžetska rezerva", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 129, 32, false, "Raspored akumulisanog suficita", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null },
                    { 130, 1, false, "Zaostale uplate poreza", false, new Guid("cea53208-ddc0-49f5-8b9d-824365d03c4f"), new DateTime(2023, 10, 11, 14, 57, 32, 83, DateTimeKind.Local).AddTicks(3560), null, null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_AccountCategories_AccountTypeID",
                schema: "pfm",
                table: "AccountCategories",
                column: "AccountTypeID");

            migrationBuilder.CreateIndex(
                name: "IX_AccountCategoryData_AccountCategoryID",
                schema: "pfm",
                table: "AccountCategoryData",
                column: "AccountCategoryID");

            migrationBuilder.CreateIndex(
                name: "IX_AccountCategoryData_MunicipalityID",
                schema: "pfm",
                table: "AccountCategoryData",
                column: "MunicipalityID");

            migrationBuilder.CreateIndex(
                name: "IX_Actions_ActionEnumerationName",
                schema: "dbo",
                table: "Actions",
                column: "ActionEnumerationName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Actions_ActionName",
                schema: "dbo",
                table: "Actions",
                column: "ActionName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_BudgetData_BudgetPositionID",
                schema: "pfm",
                table: "BudgetData",
                column: "BudgetPositionID");

            migrationBuilder.CreateIndex(
                name: "IX_BudgetData_MunicipalityID",
                schema: "pfm",
                table: "BudgetData",
                column: "MunicipalityID");

            migrationBuilder.CreateIndex(
                name: "IX_BudgetPositions_AccountCategoryID",
                schema: "pfm",
                table: "BudgetPositions",
                column: "AccountCategoryID");

            migrationBuilder.CreateIndex(
                name: "IX_Municipalities_EntityID",
                schema: "pfm",
                table: "Municipalities",
                column: "EntityID");

            migrationBuilder.CreateIndex(
                name: "IX_Municipalities_LocalGovernmentUnitID",
                schema: "pfm",
                table: "Municipalities",
                column: "LocalGovernmentUnitID");

            migrationBuilder.CreateIndex(
                name: "IX_Municipalities_Slug",
                schema: "pfm",
                table: "Municipalities",
                column: "Slug",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserActionRel_ActionID",
                schema: "dbo",
                table: "UserActionRel",
                column: "ActionID");

            migrationBuilder.CreateIndex(
                name: "IX_UserActionRel_UserID",
                schema: "dbo",
                table: "UserActionRel",
                column: "UserID");

            migrationBuilder.CreateIndex(
                name: "IX_UserGroupActionRel_ActionID",
                schema: "dbo",
                table: "UserGroupActionRel",
                column: "ActionID");

            migrationBuilder.CreateIndex(
                name: "IX_UserGroupActionRel_UserGroupID",
                schema: "dbo",
                table: "UserGroupActionRel",
                column: "UserGroupID");

            migrationBuilder.CreateIndex(
                name: "IX_UserGroupUserRel_UserGroupID",
                schema: "dbo",
                table: "UserGroupUserRel",
                column: "UserGroupID");

            migrationBuilder.CreateIndex(
                name: "IX_UserGroupUserRel_UserID",
                schema: "dbo",
                table: "UserGroupUserRel",
                column: "UserID");

            migrationBuilder.CreateIndex(
                name: "IX_UserMunicipalityRel_MunicipalityID",
                schema: "pfm",
                table: "UserMunicipalityRel",
                column: "MunicipalityID");

            migrationBuilder.CreateIndex(
                name: "IX_UserMunicipalityRel_UserID",
                schema: "pfm",
                table: "UserMunicipalityRel",
                column: "UserID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AccountCategoryData",
                schema: "pfm");

            migrationBuilder.DropTable(
                name: "ActionsHistory",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "AuditLogEnumerations",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "AuditLogs",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "BudgetData",
                schema: "pfm");

            migrationBuilder.DropTable(
                name: "EmailNotifications",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "FormFiles",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserActionRel",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserGroupActionRel",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserGroupUserRel",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserMunicipalityRel",
                schema: "pfm");

            migrationBuilder.DropTable(
                name: "BudgetPositions",
                schema: "pfm");

            migrationBuilder.DropTable(
                name: "Actions",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "UserGroups",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "Municipalities",
                schema: "pfm");

            migrationBuilder.DropTable(
                name: "Users",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "AccountCategories",
                schema: "pfm");

            migrationBuilder.DropTable(
                name: "Entities",
                schema: "pfm");

            migrationBuilder.DropTable(
                name: "LocalGovernmentUnits",
                schema: "pfm");

            migrationBuilder.DropTable(
                name: "AccountTypes",
                schema: "pfm");
        }
    }
}
