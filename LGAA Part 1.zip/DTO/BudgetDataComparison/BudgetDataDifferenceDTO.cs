﻿using PFMPortal.DTO.BudgetData;

namespace PFMPortal.DTO.BudgetDataComparison
{
    public class AccountCategoryDifferenceDataDTO
    {
        public int AccountCategoryID { get; set; }
        public string AccountCategoryName { get; set; } = string.Empty;
        public decimal PlannedValueTotal { get; set; }
        public decimal FinalValueTotal { get; set; }
    }

    public class BudgetDataDifferenceDTO
    {
        public string MunicipalityName { get; set; } = string.Empty;
        public int MunicipalityID { get; set; }
        public List<AccountCategoryDifferenceDataDTO>? Data { get; set; }
    }
}
