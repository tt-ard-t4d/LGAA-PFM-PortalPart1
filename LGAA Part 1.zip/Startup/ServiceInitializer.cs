﻿using Azure.Storage.Blobs;
using Infrastructure.Core;
using Infrastructure.Data;
using Infrastructure.Settings.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PFMPortal.Infrastructure.Core.Admin;
using PFMPortal.Infrastructure.Core.Utils;
using PFMPortal.Infrastructure.Core;
using Microsoft.AspNetCore.Authentication.Cookies;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Binders.Providers;
using Microsoft.AspNetCore.Mvc.Razor;
using PFMPortal.Infrastructure.Core.PFM;

namespace PFMPortal.Startup
{
    public static partial class ServiceInitializer
    {
        public static IServiceCollection RegisterApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<DatabaseContext>(
                opts => opts.UseSqlServer(configuration.GetConnectionString("DevConnection"))
            );


            services.ConfigureLocalization();

            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(20);
                options.Cookie.HttpOnly = true;
                options.Cookie.SameSite = SameSiteMode.Strict;
                options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
            });

            // cookie auth.
            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(option =>
            {
                option.LoginPath = "/login/login";
                option.AccessDeniedPath = "/login/denied";
                option.Cookie.HttpOnly = true;
                option.Cookie.SameSite = SameSiteMode.Strict;
                option.ExpireTimeSpan = TimeSpan.FromMinutes(20);
            });

            //Strict-Transport-Security header
            services.AddHsts(options =>
            {
                options.Preload = true;
                options.IncludeSubDomains = true;
                options.MaxAge = TimeSpan.FromDays(365);
            });

            services.AddMvc(options =>
            {
                //Add automatic antiforgery token validation for every request excluding GET, HEAD, OPTIONS, and TRACE
                options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
                //String model binder for input sanitizing
                options.ModelBinderProviders.Insert(0, new StringModelBinderProvider());
                //DateTime model binder for dates from query string
                options.ModelBinderProviders.Insert(1, new DateTimeModelBinderProvider());
            });

            services.AddKendo();

            RegisterCustomDependencies(services, configuration);

            ConfigurationHelper.Initialize(configuration);

            return services;
        }

        private static void RegisterCustomDependencies(IServiceCollection services, IConfiguration configuration)
        {
            //Register repositories before adding services
            services.RegisterRepositories();

            services.AddTransient<UserService>();
            services.AddTransient<AuditLogService>();
            services.AddTransient<EmailService>();
            services.AddTransient<FileUploadService>();
            services.AddTransient<LoginService>();
            services.AddTransient<DropDownService>();
            services.AddTransient<ActionManagementService>();
            services.AddTransient<LoginImpersonateService>();
            services.AddTransient<ReportingService>();
            services.AddTransient<FileManagementService>();
            services.AddTransient<SessionService>();

            //PFM
            services.AddTransient<PFMDropDownService>();
            services.AddTransient<MunicipalityService>();
            services.AddTransient<BudgetDataService>();
            services.AddTransient<BudgetDataReportService>();
            services.AddTransient<AccountCategoryDataService>();

            // BLOB
            services.AddScoped(_ =>
            {
                return new BlobServiceClient(configuration.GetConnectionString("AzureBlobStorage"));
            });

            services.Configure<MailSettings>(configuration.GetSection("MailSettings"));
        }
    }
}
