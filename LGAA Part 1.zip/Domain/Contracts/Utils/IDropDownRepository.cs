﻿using DTO.Utils;
using PFMPortal.Domain.Entities;

namespace PFMPortal.Domain.Contracts.Utils
{
    public interface IDropDownRepository
    {
        public IQueryable<UserGroup> GetUserGroups();
        public IQueryable<Entities.Action> GetActions();
        public IQueryable<User> GetUsers();
        List<AuditLogEnumerationDTO> GetAllAuditLogsEnumeration();
    }
}
