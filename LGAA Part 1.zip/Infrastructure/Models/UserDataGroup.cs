﻿namespace PFMPortal.Infrastructure.Models
{
    public class UserDataGroup
    {
        public int UserGroupID { get; set; }
        public string UserGroupName { get; set; }
    }
}