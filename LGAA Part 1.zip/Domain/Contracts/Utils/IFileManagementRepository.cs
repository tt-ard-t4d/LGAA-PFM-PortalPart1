﻿using PFMPortal.Domain.Entities.Utils;
using PFMPortal.DTO.BudgetData;
using PFMPortal.DTO.Utils;

namespace PFMPortal.Domain.Contracts.Utils
{
    public interface IFileManagementRepository
    {
        public (IQueryable<FormFiles>, int) GetFileGrid(SearchBudgetDataDTO args);
    }
}
