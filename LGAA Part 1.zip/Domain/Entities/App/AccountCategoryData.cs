﻿namespace PFMPortal.Domain.Entities.App
{
    public class AccountCategoryData : SysEntity
    {
        public int AccountCategoryDataID { get; set; }
        public int AccountCategoryID { get; set; }
        public virtual AccountCategory AccountCategory { get; set; }
        public int MunicipalityID { get; set; }
        public virtual Municipality Municipality { get; set; }
        public int Year { get; set; }
        public decimal? TotalPlannedValue { get; set; }
        public decimal? TotalFinalValue { get; set; }
    }
}
