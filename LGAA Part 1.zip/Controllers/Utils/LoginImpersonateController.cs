﻿using Authorization;
using Infrastructure.Helpers;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Core;
using PFMPortal.Infrastructure.Core.Admin;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Resources;
using PFMPortal.Infrastructure.Utility;
using System.Security.Claims;

namespace PFMPortal.Controllers.Utils
{
    /// <summary>
    /// IMPORTANT: 
    /// RedirectToAction() must happen after HttpContext.SignInAsync and HttpContext.SignOutAsync
    /// 
    /// </summary>
    [PowerAdminAuthorize]
    public class LoginImpersonateController : Controller
    {
        private readonly LoginImpersonateService _loginImpersonateService;
        private readonly UserService _userService;
        private readonly IConfiguration _configuration;
        public LoginImpersonateController(LoginImpersonateService loginImpersonateService, UserService userService, IConfiguration configuration)
        {
            _loginImpersonateService = loginImpersonateService;
            _userService = userService;
            _configuration = configuration;
        }

        [HttpPost]
        public async Task<IActionResult> Login(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                TempData["info-message"] = MessageRes.ChooseUserEmail;
                return RedirectToAction("Index", "Home");
            }

            var emailEnc = SEDManager.Protect(email, _configuration);
            var user = _userService.GetUserDataByEmailEnc(emailEnc);

            if (user.UserID != Guid.Empty)
            {
                //Power admin
                var currentUser = User;
                //Set user groups and actions
                HttpContext.Session.SetUserData(user);
                //Set user claims
                var userPrincipal = _loginImpersonateService.AddClaims(user, currentUser);

                await HttpContext.SignInAsync(userPrincipal);

                return RedirectToAction("Index", "Home");
            }

            TempData["error-message"] = MessageRes.LoginError;
            return RedirectToAction("Index", "Home");
        }

        public async Task<IActionResult> ResetLogin()
        {
            var impersonatedUserEmail = User.Identity.GetImpersonatedUserEmail();

            var emailEnc = SEDManager.Protect(impersonatedUserEmail, _configuration);

            var user = _userService.GetUserDataByEmailEnc(emailEnc);
            var currentUser = User;
            var identityPrincipal = _loginImpersonateService.AddClaims(user, currentUser);

            HttpContext.Session.Clear();
            await HttpContext.SignInAsync(identityPrincipal);
            HttpContext.Session.SetUserData(user);

            return RedirectToAction("Index", "Home");
        }

        public List<ItemDDL> GetUsers()
        {
            var impersonatedUserId = User.GetImpersonatedUserId();
            var users = _userService.GetUserEmails(impersonatedUserId);

            return users.Select(r => new ItemDDL() { Guid = r.UserID, Value = r.Email }).ToList();
        }
    }
}
