﻿using PFMPortal.Domain.Entities.App;

namespace PFMPortal.DTO.BudgetData
{
    public class BudgetPositionDTO
    {
        public int BudgetPositionID { get; set; }
        public string BudgetPositionName { get; set; } = string.Empty;
        public int AccountCategoryID { get; set; }
        public BudgetDataDTO BudgetData { get; set; } = new BudgetDataDTO();

        public string Information { get; set; } = string.Empty;
    }
}
