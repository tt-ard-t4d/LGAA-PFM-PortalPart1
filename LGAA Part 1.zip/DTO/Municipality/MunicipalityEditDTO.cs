﻿using PFMPortal.DTO.Utils;

namespace PFMPortal.DTO.Municipality
{
    public class MunicipalityEditDTO
    {
        public int MunicipalityID { get; set; }
        public List<ItemDDL> Municipalities { get; set; } = new();
    }
}
