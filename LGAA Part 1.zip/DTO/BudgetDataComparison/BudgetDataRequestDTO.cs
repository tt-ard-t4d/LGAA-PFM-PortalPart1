﻿using static PFMPortal.Infrastructure.Helpers.PFMEnum;

namespace PFMPortal.DTO.BudgetDataComparison
{
    public class BudgetDataRequestDTO
    {
        public List<int> MunicipalityIDs { get; set; } = new List<int>();
        public int Year { get; set; }
        public GraphType GraphType { get; set; }
        public short AccountType { get; set; }
    }
}
