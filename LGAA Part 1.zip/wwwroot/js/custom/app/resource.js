﻿var app = app || {};

app.resource = function () {

    var dateFormat = ''

    var init = function () {
        $.ajax({
            type: "GET",
            url: '/Resource',
            contentType: 'application/json; charset=UTF-8',
            success: function (data) {
                if (!localStorage.getItem('resources')) {
                    localStorage.setItem('resources', JSON.stringify(data));
                }
            },
            error: function (xhr, ajaxOptions, thrownError) {

            }
        });
    };

    var initSpecificResource = function (name, onLoadCallback) {
        handleResourceAjaxCall(name, onLoadCallback);
    };

    var initSpecificResources = function (names, onLoadCallback) {
        var p = $.when();
        names.reduce(function (p, name) {
            return p.then(function () {
                return handleResourceAjaxCall(name, (names[names.length - 1] == name ? onLoadCallback : null));
            });
        }, $.when());
    };

    var handleResourceAjaxCall = function (name, onLoadCallback, isDebt = false) {
        if (name) {
            let url = '/Resource/GetSpecific?name=' + name

            return $.ajax({
                type: "GET",
                url: url,
                contentType: 'application/json; charset=UTF-8',
                success: function (data) {
                    localStorage.setItem('resources_' + name, JSON.stringify(data));
                    if (onLoadCallback) {
                        onLoadCallback(name);
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {

                }
            });
        }

        return null;
    };

    var getByGroupAndKey = function (group, key) {
        if (localStorage.getItem('resources')) {
            var obj = JSON.parse(localStorage.getItem('resources'));
            return JSON.parse(obj[group])['Texts'].filter(t => t.id == key)[0].text;
        }
    };

    var getByResourceGroupAndKey = function (resource, key) {
        if (localStorage.getItem('resources_' + resource)) {
            var obj = JSON.parse(localStorage.getItem('resources_' + resource));
            return JSON.parse(obj['name'])['Texts'].filter(t => t.id == key)[0].text;
        }
    };

    var getDateFormat = function () {
        return dateFormat;
    };

    var initDefaultDateFormat = function () {
        dateFormat = "D.M.Y";
        let url = '/Resource/GetDateFormat';
        $.ajax({
            type: "GET",
            url: url,
            dataType: 'json',
            success: function (data) {
                dateFormat = data.dateFormat.toUpperCase();
            },
            error: function (xhr, ajaxOptions, thrownError) {

            }
        });
    };

    initDefaultDateFormat();

    return {
        init: init,
        initSpecificResource: initSpecificResource,
        initSpecificResources: initSpecificResources,
        getDateFormat: getDateFormat,
        getByGroupAndKey: getByGroupAndKey,
        getByResourceGroupAndKey: getByResourceGroupAndKey,
    };
}();


