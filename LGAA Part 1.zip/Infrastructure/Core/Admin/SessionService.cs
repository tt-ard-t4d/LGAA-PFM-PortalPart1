﻿using Infrastructure.Models;
using PFMPortal.Domain.Contracts.Admin;
using PFMPortal.DTO.Admin;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.Infrastructure.Helpers;

namespace PFMPortal.Infrastructure.Core.Admin
{
    public class SessionService
    {
        private readonly UserService _userService;

        public SessionService(UserService userService)
        {
            _userService = userService;            
        }

        public void SessionUpdateOnGroupActionUpdate(HttpContext httpContext, ActionAssignmentDTO model)
        {
            bool loggedUserInGroup = httpContext.Session.CheckIsInUserGroup(model.UserGroupID);
            var loggedUserId = httpContext.User.Identity.GetLoggedUserId();

            if (loggedUserInGroup)
            {
                UserData userData = _userService.GetUserDataByUserId(loggedUserId);
                httpContext.Session.SetUserData(userData);
            }
        }

        public void SessionUpdateOnUserActionUpdate(HttpContext httpContext, ActionAssignmentDTO model)
        {
            var loggedUserId = httpContext.User.Identity.GetLoggedUserId();

            if (loggedUserId != model.UserID) return;

            UserData userData = _userService.GetUserDataByUserId(loggedUserId);
            httpContext.Session.SetUserData(userData);
        }

        public void SessionUpdateOnUserUpdate(HttpContext httpContext, Guid userId)
        {
            var loggedUserId = httpContext.User.Identity.GetLoggedUserId();

            if (userId != loggedUserId) return;

            UserData userData = _userService.GetUserDataByUserId(loggedUserId);
            httpContext.Session.SetUserData(userData);
        }
    }
}
