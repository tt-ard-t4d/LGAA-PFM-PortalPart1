﻿var app = app || {};

app.graphSettings = function () {
    function getBarGraphOptions(title, unit = null) {
        return {
            title: {
                text: title,
                align: 'center',
                margin: 10,
                offsetX: 0,
                offsetY: 0,
                floating: false,
                style: {
                    fontSize: '18px',
                    fontWeight: 'bold',
                    fontFamily: undefined,
                    color: '#263238'
                },
            },
            amounts: null,
            series: [
            ],
            colors: ["#f25840", "#eb9100", "#4e7733", "#db91be", "#37c0c7", "#793b7d", "#0084bc", "#586F7C", "#104F55"],
            chart: {
                sparkline: {
                    enabled: false,
                },
                type: "bar",
                width: "100%",
                height: 600,
                toolbar: {
                    show: false,
                }
            },
            fill: {
                opacity: 1,
            },
            plotOptions: {
                bar: {
                    horizontal: true,
                    hideZeroBarsWhenGrouped: false,
                    columnWidth: "100%",
                    borderRadiusApplication: "end",
                    borderRadius: 6,
                    dataLabels: {
                        position: "top",
                    },
                },
            },
            legend: {
                show: true,
                position: "bottom",
            },
            dataLabels: {
                enabled: false,
            },
            tooltip: {
                shared: true,
                intersect: false,
                formatter: function (value) {
                    return "$" + value
                }
            },
            xaxis: {
                labels: {
                    show: true,
                    style: {
                        fontFamily: "Inter, sans-serif",
                        cssClass: 'text-xs font-normal fill-gray-500'
                    },
                    formatter: function (value) {
                        return `${value}${unit || ' KM'}`
                    }
                },
                categories: [],
                axisTicks: {
                    show: false,
                },
                axisBorder: {
                    show: false,
                },
            },
            yaxis: {
                labels: {
                    show: true,
                    style: {
                        fontFamily: "Inter, sans-serif",
                        cssClass: 'text-xs font-normal fill-gray-500'
                    }
                }
            },
            grid: {
                show: true,
                strokeDashArray: 4,
                padding: {
                    left: 2,
                    right: 2,
                    top: -20
                },
            },
            fill: {
                opacity: 1,
            },
            tooltip: {
                shared: true,
                intersect: false,
                followCursor: true,
                y: {
                    formatter: function (value, { series, seriesIndex, dataPointIndex, w }) {
                        if (w.config.series[seriesIndex].aditionalData == null)
                        {
                            return `${value.toLocaleString('de-DE', { minimumFractionDigits: 2 })}${unit || ' KM'}`;
                        }
                        else {
                            const currencyAmount = w.config.series[seriesIndex].aditionalData[dataPointIndex];
                            const roundedPercentage = Math.round((value + Number.EPSILON) * 100) / 100;
                            const currencyAmountLocalizedString = currencyAmount.toLocaleString('de-DE', { minimumFractionDigits: 2 });
                            const roundedPercentageLocalizedString = roundedPercentage.toLocaleString('de-DE', { minimumFractionDigits: 2 });
                            return `${roundedPercentageLocalizedString.toLocaleString('de-DE', { minimumFractionDigits: 2 })}${unit} (${currencyAmountLocalizedString} KM)`;
                        }
                    }
                },
                fixed: {
                    offsetX: 20,
                    offsetY: 0,
                },

            },
            responsive: [{
                breakpoint: 600,
                options: {
                    xaxis: {
                        labels: {
                            show: false,
                        }
                    },
                },
            },
            ],
        }
    }

    function getDonutChartOptions(item) {

        return {
            total: item.totalAmount,
            series: [item.amount, item.totalAmount - item.amount],
            colors: ["#f25840", "#f6d9d1"],
            chart: {
                height: 420,
                width: "100%",
                type: "donut",
                toolbar: {
                    show: true,
                    offsetX: 0,
                    offsetY: 0,
                    tools: {
                        download: true,
                    },
                    export: {
                        csv: {
                            columnDelimiter: ',',
                            headerCategory: 'Budžetska linija',
                            headerValue: 'Kolicina (BAM)',
                        },
                        svg: {
                        },
                        png: {
                        }
                    },
                    autoSelected: 'zoom'
                },
            },
            stroke: {
                colors: ["transparent"],
                lineCap: "",
            },
            plotOptions: {
                pie: {
                    expandOnClick: false,
                    donut: {
                        expandOnClick: false,
                        labels: {
                            show: true,
                            color: '#f25840',
                            name: {
                                show: false,
                                color: '#f25840',
                                fontFamily: "Inter, sans-serif",
                                offsetY: 20,
                            },
                            total: {
                                showAlways: true,
                                show: true,
                                color: '#f25840',
                                fontSize: "2rem",
                                fontFamily: "Inter, sans-serif",
                                formatter: function (w) {
                                    return `${Math.round(w.globals.seriesPercent[0] * 100) / 100}%`
                                },
                            },
                        },
                        size: "80%",
                    },
                },
            },
            title: {
                text: item.budgetPositionName,
                align: 'bottom',
                style: {
                    fontSize: '18px',
                    fontWeight: '400',
                    fontFamily: "Source Sans 3",
                    color: "rgb(17, 24, 39)"
                },
            },

            subtitle: {
                text: `${item.amount.toLocaleString('de-DE', { minimumFractionDigits: 2, })} KM`,
                align: 'bottom',
                margin: 10,
                offsetX: 0,
                offsetY: 30,
                floating: false,
                style: {
                    fontSize: '24px',
                    fontWeight: '400',
                    fontFamily: "Source Sans 3",
                    color: 'rgb(242, 88, 64)'
                },
            },

            labels: [item.label, "Ostalo"],
            dataLabels: {
                enabled: false,
            },
            legend: {
                show: false,
            },
            tooltip: {
                enabled: false,
            },
            states: {
                hover: {
                    filter: {
                        type: 'none',
                    }
                },
                active: {
                    filter: {
                        type: 'none',
                    }
                },
            },
            responsive: [{
                breakpoint: 600,
                options: {
                    chart: {
                        height: 240,
                    },
                },
            },
            ],
        }
    }


    function getPieChartOptions(data) {
        const series = data.map(function (item) {
            return item.amount;
        });

        const labels = data.map(function (item) {
            return item.label;
        });

        const descriptions = data.map(function (item) {
            return item.description;
        });

        const ids = data.map(function (item) {
            return item.id;
        });

        let sum = series.reduce((a, b) => a + b, 0);
        return {
            descriptions: descriptions,
            sum: sum,
            series: series,
            ids: ids,
            colors: ["#f25840", "#eb9100", "#4e7733", "#db91be", "#37c0c7", "#793b7d", "#0084bc", "#586F7C", "#104F55"],
            chart: {
                events: {
                    dataPointSelection: (event, chartContext, config) => {
                        app.BudgetDataPublic.updateDonutCharts(config.w.config.ids[config.dataPointIndex], config.w.config.labels[config.dataPointIndex], config.w.config.descriptions[config.dataPointIndex])
                    }
                },
                height: 600,
                width: "100%",
                type: "pie",
                toolbar: {
                    show: true,
                    offsetX: 0,
                    offsetY: 0,
                    tools: {
                        download: true,
                    },
                    export: {
                        csv: {
                            columnDelimiter: ',',
                            headerCategory: 'Budžetska linija',
                            headerValue: 'Procenat',
                        },
                        svg: {
                        },
                        png: {
                        }
                    },
                    autoSelected: 'zoom'
                },
            },
            stroke: {
                colors: ["white"],
                lineCap: "",
            },
            plotOptions: {
                pie: {
                    labels: {
                        show: true,
                    },
                    size: "100%",
                    dataLabels: {
                        offset: -25,

                    },
                    expandOnClick: false

                },
            },
            labels: labels,
            dataLabels: {
                enabled: true,
                formatter: function (val, { seriesIndex, dataPointIndex, w }) {
                    return Math.round(val * 100) / 100 + "%";
                },
                style: {
                    fontFamily: 'Helvetica, Arial, sans-serif',
                    fontWeight: 'bold',
                },
            },
            legend: {
                position: "bottom",
                horizontalAlign: 'left',
                fontSize: '18px',
                fontFamily: "Inter, sans-serif",
            },
            tooltip: {
                custom: function ({ series, seriesIndex, dataPointIndex, w }) {
                    return `<div class='px-3 py-2 text-sm font-medium text-lg text-gray-900 bg-white border border-gray-200 shadow-sm'>
                                <p> <span class="font-bold">${w.config.labels[seriesIndex]}: </span> ${Math.round(w.globals.seriesPercent[seriesIndex] * 100) / 100}%</p>
                                <p><span class="font-bold">Iznos:</span> ${series[seriesIndex].toLocaleString('de-DE', {
                        minimumFractionDigits: 2,
                    })} KM</p>
                            </div>`
                }
            },

        }
    }

    function prepareDataForComparisonChart(originalArray) {
        let height = 0;
        const goalName = 'Planirani budžet';
        const transformedArray = [];
        let municipalityNames = [];
        let colors = ["#f25840", "#eb9100", "#4e7733", "#db91be", "#37c0c7", "#793b7d", "#0084bc", "#586F7C", "#104F55"];
        originalArray.forEach((municipality) => {
            const municipalityName = municipality.municipalityName;
            const data = municipality.data;
            municipalityNames.push(municipalityName);
            const municipalityObject = {
                name: 'Izvršeni budžet',
                data: [],
            };
            data.forEach((item) => {
                const dataPoint = {
                    x: item.accountCategoryName,
                    y: item.finalValueTotal,
                    goals: [
                        {
                            name: goalName,
                            value: item.plannedValueTotal,
                            strokeWidth: (item.plannedValueTotal > 0) ? 5 : 0,
                            strokeHeight: (item.plannedValueTotal > 0) ? 10 : 0,
                            strokeLineCap: 'round',
                            strokeColor: "#000",
                        },
                    ],
                };
                municipalityObject.data.push(dataPoint);
                height += 50;
            });
            transformedArray.push(municipalityObject);
        }); 

        colors = colors.slice(0, municipalityNames.length)
        colors.push("#000");
        municipalityNames.push('Planirani iznos');
        return {
            series: transformedArray,
            labels: municipalityNames,
            colors: colors,
            height: height,
        }
    }

    var getBarComparisonGraphOptions = function (data, chartTitle) {
        data = prepareDataForComparisonChart(data);
        var options = {
            series: data.series,
            chart: {
                height: data.height,
                type: 'bar'
            },
            plotOptions: {
                bar: {
                    horizontal: true,
                }
            },
            stroke: {
                show: true,
                width: 1,
                colors: ['#fff']
            },

            dataLabels: {
                formatter: function (val, opt) {
                    const goals =
                        opt.w.config.series[opt.seriesIndex].data[opt.dataPointIndex]
                            .goals

                    if (goals && goals.length && val!=0) {
                        return `${((val / goals[0].value) * 100).toFixed(2)}%`
                    }
                    return "";
                }
            },
            colors: data.colors,
            legend: {
                show: true,
                showForSingleSeries: true,
                customLegendItems: data.labels,
                markers: {
                    fillColors: data.colors,
                }
            },
            tooltip: {
                x: {
                    show: true,
                    formatter: function (value, { series, seriesIndex, dataPointIndex, w }) {
                        return value + " - " + w.config.legend.customLegendItems[seriesIndex];
                    },
                },
                y: {
                    formatter: function (value, { series, seriesIndex, dataPointIndex, w }) {
                        return value.toLocaleString('de-DE', { minimumFractionDigits: 2 }) + " KM";
                    }
                },
            },
            title: {
                text: chartTitle,
                align: 'center',
                margin: 10,
                offsetX: 0,
                offsetY: 0,
                floating: false,
                style: {
                    fontSize: '18px',
                    fontWeight: 'bold',
                    fontFamily: undefined,
                    color: '#263238'
                },
            }

        };
        return options;
    }

    return {
        getBarGraphOptions: getBarGraphOptions,
        getDonutChartOptions: getDonutChartOptions,
        getPieChartOptions: getPieChartOptions,
        getBarComparisonGraphOptions: getBarComparisonGraphOptions,
    }
}();

