﻿namespace PFMPortal.Infrastructure.Models.Cache
{
    public class UserGroupModel
    {
        public int UserID { get; set; }
        public int UserGroupID { get; set; }
    }
}
