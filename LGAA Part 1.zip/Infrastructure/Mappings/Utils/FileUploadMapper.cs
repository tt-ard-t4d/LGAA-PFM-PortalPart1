﻿using PFMPortal.Domain.Entities.Utils;
using PFMPortal.DTO.Utils;

namespace PFMPortal.Infrastructure.Mappings.Utils
{
    public class FileUploadMapper
    {
        public FormFiles Map(IFormFile uploadedFile, Guid fileGuid, short fileTypeId, int formId, Guid loggedUserId)
        {
            return new FormFiles
            {
                FileGuidID = fileGuid,
                Name = Path.GetFileNameWithoutExtension(uploadedFile.FileName),
                Title = uploadedFile.FileName,
                Extension = Path.GetExtension(uploadedFile.FileName),
                Size = uploadedFile.Length,
                FileTypeID = fileTypeId,
                Retired = false,
                FormID = (formId > 0) ? formId : null,
                SysCreatedByUserID = loggedUserId
            };
        }

        public FormFileDTO Map(FormFiles model)
        {
            return new FormFileDTO
            {
                FormFileID = model.FormFileID,
                FileGUID = model.FileGuidID,
                FileName = model.Name,
                FileExtension = model.Extension,
                FileLenght = (model.Size ?? 0) / 1024,
                SysCreatedByUserID = model.SysCreatedByUserID
            };
        }
    }
}
