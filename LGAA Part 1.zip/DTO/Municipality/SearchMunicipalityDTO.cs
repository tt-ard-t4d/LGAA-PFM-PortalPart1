﻿using PFMPortal.DTO.Utils;

namespace PFMPortal.DTO.Municipality
{
    public class SearchMunicipalityDTO : GridArgsDTO
    {
        public string MunicipalityName { get; set; }
        public List<ItemDDL> Entities { get; set; }
        public int EntityID { get; set; }
    }
}
