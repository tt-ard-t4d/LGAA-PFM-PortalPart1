﻿using PFMPortal.DTO.Utils;
using PFMPortal.DTO.BudgetData;
using PFMPortal.Domain.Contracts.PFM;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Domain.Entities.App;
using PFMPortal.Infrastructure.Mappings.PFM;
using static PFMPortal.Infrastructure.Helpers.PFMEnum;
using Infrastructure.Helpers;
using PFMPortal.DTO.Municipality;
using PFMPortal.DTO.BudgetDataComparison;

namespace PFMPortal.Infrastructure.Core.PFM
{
    public class BudgetDataService
    {
        private readonly IBudgetDataRepository _repository;
        private readonly IMunicipalityRepository _municipalityRepository;

        public BudgetDataService(IBudgetDataRepository repository, IMunicipalityRepository municipalityRepository)
        {
            _repository = repository;
            _municipalityRepository = municipalityRepository;
        }

        public RetValue CreateBudgetDataEntry(int year, Guid loggedUserId)
        {
            (IQueryable<Municipality> municipalities, int numberOfMunicipalities) = _municipalityRepository.GetMunicipalitiesWithoutEntries(year);

            return _repository.CreateBudgetDataEntry(year, municipalities.ToList(), loggedUserId);
        }

        public int GetLatestYearForMunicipality(int municipalityId)
        {
            var res = _repository.GetBudgetDataYearsForMunicipality(municipalityId);

            return res.Any() ? res.Max() : 0;
        }

        public MunicipalityDTO GetMunicipalityBySlug(string municipalityName)
        {
            var entity = _municipalityRepository.GetMunicipalityBySlug(municipalityName);
            var map = new MunicipalityMapper();

            return map.Map(entity);
        }
        public GridDTO<BudgetDataGridDTO, SearchBudgetDataDTO> GetBudgetDataReadGrid(SearchBudgetDataDTO args)
        {
            var ret = new GridDTO<BudgetDataGridDTO, SearchBudgetDataDTO>();
            var retVal = _repository.GetBudgetDataGrid(args);

            var map = new BudgetDataMapper();
            var mappedData = retVal.Select(r => map.MapGrid(r, false)).ToList();

            if (args.AccountTypeID > 0)
            {
                mappedData = mappedData.Where(r => r.AccountTypeID == args.AccountTypeID).ToList();
            }

            ret.Data = mappedData;
            ret.Search = args;

            return ret;
        }

        public GridDTO<BudgetDataGridDTO, SearchBudgetDataDTO> GetBudgetDataEditGrid(SearchBudgetDataDTO args)
        {
            var ret = new GridDTO<BudgetDataGridDTO, SearchBudgetDataDTO>();
            var retVal = _repository.GetBudgetDataGrid(args);

            var map = new BudgetDataMapper();
            var mappedData = retVal.Select(r => map.MapGrid(r, true)).ToList();

            if (args.AccountTypeID > 0)
            {
                mappedData = mappedData.Where(r => r.AccountTypeID == args.AccountTypeID).ToList();
            }

            ret.Data = mappedData;
            ret.Search = args;

            return ret;
        }

        public RetValue Save(IEnumerable<BudgetDataGridDTO> items, Guid loggedUserId, BudgetDataValueType dataValueType)
        {
            var map = new BudgetDataMapper();

            var entities = items.Select(r => map.MapGrid(r, GlobalEnum.CrudOperation.Edit, loggedUserId));

            return _repository.Save(entities, dataValueType);
        }

        public BudgetTitleDTO GetBudgetTitle(int yearId, int municipalityId)
        {
            var entity = _repository.GetBudgetTitle(yearId, municipalityId);
            var map = new BudgetDataMapper();
            return map.Map(entity, yearId, municipalityId);
        }

        #region CHARTS

        public List<ChartBudgetTypePieDTO> GetDataForMainPieChart(int municipalityID, int yearID, short accountTypeID, short amountTypeID = (short)GlobalEnum.AmountType.Planned)
        {
            var res = _repository.GetDataForChart(municipalityID, yearID, accountTypeID);
            var grouped = res.GroupBy(r => new { r.BudgetPosition.AccountCategory.AccountCategoryName, r.BudgetPosition.AccountCategory.AccountCategoryID, r.BudgetPosition.AccountCategory.Information });

            var ret = grouped.Select(r => new ChartBudgetTypePieDTO()
            {
                Id = r.Key.AccountCategoryID,
                Label = r.Key.AccountCategoryName,
                Description = r.Key.Information,
                Amount = GetAmountValue(amountTypeID, r.Sum(f => f.PlannedValue), r.Sum(f => f.FinalValue)),
            }).ToList();

            return ret;
        }

        public List<ChartBudgetTypeDonutDTO> GetDataForDonutChart(int accountCategoryID, int municipalityID, int yearID, short accountTypeID, short amountTypeID = (short)GlobalEnum.AmountType.Planned)
        {
            var res = _repository.GetDataForChart(municipalityID, yearID, accountTypeID);
            var grouped = res.Where(r => r.BudgetPosition.AccountCategoryID == accountCategoryID).GroupBy(r => new { r.BudgetPosition.BudgetPositionID, r.BudgetPosition.BudgetPositionName });

            var totalBudgetSum = res
                .GroupBy(r => new { r.BudgetPosition.BudgetPositionID, r.BudgetPosition.BudgetPositionName })
                .Select(r => r.Select(l => ((amountTypeID == (short)GlobalEnum.AmountType.Planned) ? l.PlannedValue : l.FinalValue) ?? 0).Sum()).Sum();


            var ret = grouped.Select(r => new ChartBudgetTypeDonutDTO
            {
                BudgetPositionID = r.Key.BudgetPositionID,
                BudgetPositionName = r.Key.BudgetPositionName,
                AccountCategoryID = r.Max(f => f.BudgetPosition.AccountCategoryID),
                Amount = GetAmountValue(amountTypeID, r.Sum(f => f.PlannedValue), r.Sum(f => f.FinalValue)),
                Label = r.Key.BudgetPositionName.ToString(),
                TotalAmount = totalBudgetSum
            }).ToList();

            // if is execution/Final
            return ret;
        }

        private static decimal GetAmountValue(short amountTypeID, decimal? plannedValue, decimal? finalValue)
        {
            if (amountTypeID == (short)GlobalEnum.AmountType.Planned)
            {
                return plannedValue ?? 0;
            }
            return finalValue ?? 0;
        }

        public List<ChartBudgetTypeBarDTO> GetDataForBarChart(int municipalityID, int yearID)
        {
            var res = _repository.GetDataForChart(municipalityID, yearID, 1);
            res = res.Concat(_repository.GetDataForChart(municipalityID, yearID, 2));
            var grouped = res.GroupBy(r => new { r.BudgetPosition.AccountCategory.AccountCategoryName, r.BudgetPosition.AccountCategory.AccountCategoryID });

            var ret = grouped.Select(r => new ChartBudgetTypeBarDTO()
            {
                Label = r.Key.AccountCategoryName,
                Id = r.Key.AccountCategoryID,
                PlannedAmount = r.Sum(f => f.PlannedValue) ?? 0,
                ExecutedAmount = r.Sum(f => f.FinalValue) ?? 0,
            }).ToList();

            return ret;
        }

        public List<BudgetDataDifferenceDTO> GetBudgetDataDifference(List<int> municipalityIds, int year, int accountTypeId)
        {
            var res = _repository.GetDataForChartMunicipalities(municipalityIds, year, accountTypeId);

            var data = res.GroupBy(r => new { r.MunicipalityID, r.Municipality.MunicipalityName })
                .Select(r => new BudgetDataDifferenceDTO()
                {
                    MunicipalityID = r.Key.MunicipalityID,
                    MunicipalityName = r.Key.MunicipalityName,
                    Data = r.GroupBy(p => new { p.BudgetPosition.AccountCategoryID, p.BudgetPosition.AccountCategory.AccountCategoryName })
                        .Select(p =>
                            new AccountCategoryDifferenceDataDTO()
                            {
                                AccountCategoryID = p.Key.AccountCategoryID,
                                AccountCategoryName = p.Key.AccountCategoryName,
                                PlannedValueTotal = p.Sum(s => s.PlannedValue ?? 0),
                                FinalValueTotal = p.Sum(s => s.FinalValue ?? 0)
                            }
                        ).ToList()
                }).ToList();

            List<int> municipalitiesWithoutEntries = municipalityIds.Where(r => !data.Select(p => p.MunicipalityID).Contains(r)).ToList();

            foreach (var item in data)
            {
                if (item.Data.Select(r => r.PlannedValueTotal).Sum() == 0 || item.Data.Select(r => r.FinalValueTotal).Sum() == 0)
                {
                    item.Data = null;
                }
            }

            data.AddRange(municipalitiesWithoutEntries.Select(r => new BudgetDataDifferenceDTO()
            {
                MunicipalityID = r,
                MunicipalityName = string.Empty,
                Data = null
            }));

            return data;
        }

        public class Test
        {
            public int AccountCategoryID { get; set; }
            public string AccountCategoryName { get; set; } = string.Empty;
        }

        public class AmountDTO
        {
            public string BudgetPositionName { get; set; }
            public int BudgetPositionID { get; set; }
            public decimal? Amount { get; set; }
        }

        public class DataDTO
        {
            public string AccountCategoryName { get; set; }
            public int AccountCategoryID { get; set; }
            public List<AmountDTO> Data { get; set; }
        }

        public class ValuesDTO
        {
            public List<DataDTO> Planned { get; set; }
            public List<DataDTO> Executed { get; set; }
        }

        public ValuesDTO GetData(int municipalityID, int year)
        {
            var search = new SearchBudgetDataDTO()
            {
                Year = year,
                MunicipalityID = municipalityID
            };

            var ret = new ValuesDTO()
            {
                Planned = new List<DataDTO>(),
                Executed = new List<DataDTO>()
            };

            var res = _repository.GetBudgetDataGrid(search);

            var grouped = res.GroupBy(r => new Test { AccountCategoryID = r.BudgetPosition.AccountCategoryID, AccountCategoryName = r.BudgetPosition.AccountCategory.AccountCategoryName });

            foreach (var cat in grouped)
            {
                var plannedData = new DataDTO()
                {
                    AccountCategoryName = cat.Key.AccountCategoryName,
                    AccountCategoryID = cat.Key.AccountCategoryID
                };

                var executedData = new DataDTO()
                {
                    AccountCategoryName = cat.Key.AccountCategoryName,
                    AccountCategoryID = cat.Key.AccountCategoryID
                };

                List<AmountDTO> plannedAmounts = new List<AmountDTO>();
                List<AmountDTO> executedAmounts = new List<AmountDTO>();

                foreach (var pos in cat)
                {
                    plannedAmounts.Add(new AmountDTO()
                    {
                        BudgetPositionID = pos.BudgetPositionID,
                        BudgetPositionName = pos.BudgetPosition.BudgetPositionName,
                        Amount = pos.PlannedValue
                    });

                    executedAmounts.Add(new AmountDTO()
                    {
                        BudgetPositionID = pos.BudgetPositionID,
                        BudgetPositionName = pos.BudgetPosition.BudgetPositionName,
                        Amount = pos.FinalValue
                    });
                }

                plannedData.Data = plannedAmounts;
                executedData.Data = executedAmounts;

                ret.Planned.Add(plannedData);
                ret.Executed.Add(executedData);
            }

            return ret;
        }

        #endregion

        public RetValue SaveBudgetTitle(BudgetTitleDTO model, Guid loggedUserId)
        {
            var map = new BudgetDataMapper();
            var operation = model.BudgetTitleGuid != Guid.Empty ? GlobalEnum.CrudOperation.Edit : GlobalEnum.CrudOperation.Add;
            var entity = map.Map(model, operation, loggedUserId);

            return _repository.SaveBudgetTitle(entity, operation);
        }
    }
}
