﻿

using System.ComponentModel;

namespace Infrastructure.Helpers
{
    /// <summary>
    /// All this must be in synch with database
    /// </summary>
    public class GlobalEnum
    {
        public enum CrudOperation
        {
            Add = 1,
            Edit = 2,
            Delete = 3
        }

        public enum Language
        {
            [Description("sr-Latn-ME")]
            cg = 1,
            [Description("en-US")]
            en = 2
        }

        public enum FormatNumber : short
        {
            [Description("N0")]
            Decimal0 = 1,
            [Description("N2")]
            Decimal2 = 2,
            [Description("N4")]
            Decimal4 = 3
        }

        public enum Email : short
        {
            EmailPasswordSetup = 1,
            EmailPasswordReset = 2
        }

        public enum EmailStatus : short
        {
            Developer = 1,
            Actual = 2
        }

        public enum AmountType : short
        {
            Planned = 1,
            Final = 2
        }
    }
}