﻿var app = app || {};

app.common = function () {

    var addPickers = function () {

        $('select').selectpicker({
            liveSearch: true,
            noneSelectedText: ''
        });

        $('.date-picker').datetimepicker({
            format: app.resource.getDateFormat()
        });
    };

    return {
        addPickers: addPickers,
    }
}();