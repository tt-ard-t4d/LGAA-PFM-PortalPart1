﻿var app = app || {};

app.BudgetDataPublic = function () {
    let piechart = null;
    let donutCharts = [];
    const graphTitles = ["Budžetski prihodi", "Budžetski rashodi", "Razlika planiranog i izvršenog budžeta"];
    const budgetTypeNames = ["planirani", "izvršeni"];
    //FUNKCIJE ZA GRAFOVE
    var initGraphs = function () {
        if (typeof ApexCharts !== 'undefined') {
            var municipalityID = $('#graph-data #MunicipalityID').val();
            var yearID = $('#graph-data #YearID').val();
            var accountTypeID = $('#graph-data #accountTypeID').val(); // 1 - rashodi, 2  - prihodi
            var amountTypeID = $('#graph-data #amountTypeID').val(); // 1 - planirana, 2 - finalna
            makeAjaxGraphDataCall(null, municipalityID, yearID, accountTypeID, amountTypeID, 'MainPieChart', initTopGraphs);
        }
    }

    initTopGraphs = function (data) {
        if (data.length == 0) {
            $('#main-charts').hide();
            addEmptyWarning('#budget-data-graph');
            return;
        }
        else {
            $('#no-data-warning').remove();
        }
        drawProgressBars(data);
        drawPieChart(data);
        drawTotal(data);
    }

    function drawTotal(data) {
        const sum = data.reduce((total, item) => total + item.amount, 0);
        $('#total-budget :last-child').text(sum.toLocaleString('de-DE', {
            minimumFractionDigits: 2,
        }) + " KM");

        const sumTitle = `Ukupni ${budgetTypeNames[$('#amountTypeID').val() - 1]} ${graphTitles[$('#accountTypeID').val() - 1].toLowerCase()}: `;
        $('#total-budget :first-child').text(sumTitle);
    }

    updateTopGraphs = function (data) {
        if (data.length == 0) {
            $('#main-charts').hide();
            addEmptyWarning('#budget-data-graph');
            return;
        }
        else {
            $('#main-charts').show();
            $('#no-data-warning').remove();
        }
        drawProgressBars(data);
        updatePieChart(data);
        drawTotal(data);
    }

    var drawProgressBars = function (data) {
        const $progressChart = $('#progressChart');

        var colors = [
            "red",
            "orange",
            "green",
            "pink",
            "blue",
            "purple",
            "navy",
            "gray",
            "midnight"
        ];

        let sum = data.reduce(function (accumulator, item) {
            return accumulator + item.amount;
        }, 0);
        $progressChart.empty();
        data.forEach(function (item, index) {
            const $div1 = $(`<div class="mb-2 cursor-pointer px-1 rounded-md pb-2 hover:bg-gray-50" onclick='app.BudgetDataPublic.updateDonutCharts(${item.id}, "${item.label}", "${item.description}")'></div>`);
            const $divFlex = $(`<div class="flex justify-between"></div>`)
            const $categoryTitle = $('<div class="mb-1 text-lg font-medium">' + item.label + '</div>');
            const $tooltip = $(`<i class='bi bi-info-circle' id='tooltip-comment-${index}-trigger'></i>
            <div id='tooltip-comment-${index}' role='tooltip' class='absolute z-10 max-w-screen-sm invisible inline-block px-3 py-2 text-sm font-medium text-white transition-opacity duration-300 bg-gray-900 rounded-lg shadow-sm opacity-0 tooltip'>
               ${item.description}
            <div class='tooltip-arrow' data-popper-arrow></div>
            </div>`);
            const $div3 = $(`<div class="w-full h-6 bg-graph-${colors[index]}-secondary rounded-full relative"></div>`);

            // Calculate the width percentage based on the "value" property
            const widthPercentage = (item.amount / sum) * 100;

            const $progressBar = $(`<div class="h-6 bg-graph-${colors[index]} rounded-full text-sm text-center p-0.5 text-white" style="width: ${widthPercentage.toFixed(2)}%"> 
            ${(widthPercentage < 4) ? "<span class='relative flex flex-col justify-center inset-y-0 left-5 text-black'>" : ""} ${widthPercentage.toFixed(2)}% ${(widthPercentage < 4) ? "</span>" : ""}
            </div>`);

            const $div4 = $('<div class="absolute flex flex-col justify-center inset-y-0 right-2 "></div>');
            const $p = $('<p class="text-sm text-gray-800">' + item.amount.toLocaleString('de-DE', { minimumFractionDigits: 2, }) + ' KM</p>');

            $div3.append($progressBar);
            $div3.append($div4);
            $div4.append($p);
            $divFlex.append($categoryTitle);
            $divFlex.append($tooltip);
            $div1.append($divFlex);
            $div1.append($div3);

            $progressChart.append($div1);

            const $triggerEl  = document.getElementById(`tooltip-comment-${index}-trigger`);
            const $targetEl = document.getElementById(`tooltip-comment-${index}`);
           
            const tooltip = new Tooltip($targetEl, $triggerEl);
        });
    }

    var drawPieChart = function (data) {
        const chart = new ApexCharts(document.getElementById("pie-chart"), app.graphSettings.getPieChartOptions(data));
        chart.render();
        piechart = chart;
        $('#pie-chart-loader').remove();
    }

    var updatePieChart = function (data) {
        piechart.updateOptions(app.graphSettings.getPieChartOptions(data))
    }

    var updateGraphs = function () {
        var municipalityID = $('#graph-data #MunicipalityID').val();
        var yearID = $('#graph-data #YearID').val();
        var accountTypeID = $('#graph-data #accountTypeID').val(); // 1 - rashodi, 2  - prihodi
        var amountTypeID = $('#graph-data #amountTypeID').val(); // 1 - planirana, 2 - finalna
        makeAjaxGraphDataCall(null, municipalityID, yearID, accountTypeID, amountTypeID, 'MainPieChart', updateTopGraphs);
    }

    //BAR CHARTS

    function updateOptions(data) {
        if (!data || data.length == 0)
            return null;
        var options = app.graphSettings.getBarGraphOptions();
        const labels = [];
        const plannedValues = [];
        const executedValues = [];

        data.forEach(item => {
            labels.push(item.label);
            plannedValues.push(item.plannedAmount);
            executedValues.push(item.executedAmount);
        });

        if (executedValues.every(value => value === 0)) {
            return null;
        }

        options.series = [{ name: "Izvršeni budžet", data: executedValues }, { name: "Planirani budžet", data: plannedValues }];
        options.xaxis = {
            categories: labels,
        }
        options.colors = ["#f25840", "#f6d9d1"];
        options.tooltip = {
            shared: true,
            intersect: false,
            followCursor: true,

            custom: function ({ series, seriesIndex, dataPointIndex, w }) {
                const percentage = ((series[0][dataPointIndex] / series[1][dataPointIndex]) * 100).toFixed(2);
                return `
                    <div class="px-3 py-2 text-sm font-medium text-lg text-gray-900 bg-white border border-gray-200 shadow-sm rounded-lg">
                        <div class="text-xl font-semibold text-gray-900 border-b border-gray-400">
                            ${w.config.xaxis.categories[dataPointIndex]}
                        </div>
                        <div class="text-md font-normal">
                            <span class="inline-flex items-center justify-center w-2 h-2 text-xs font-semibold text-blue-800 rounded-full" style="background-color:${w.config.colors[0]}"></span>
                            Izvršeni budžet: <span class="font-bold"> ${series[0][dataPointIndex].toLocaleString('de-DE', { minimumFractionDigits: 2 })} KM </span>
                        </div>
                        <div class="text-md font-normal">
                            <span class="inline-flex items-center justify-center w-2 h-2 text-xs font-semibold text-blue-800 rounded-full" style="background-color:${w.config.colors[1]}"></span>
                            Planirani budžet: <span class="font-bold"> ${series[1][dataPointIndex].toLocaleString('de-DE', { minimumFractionDigits: 2 })} KM </span>
                        </div>
                        <div>
                            Procentualno: <span class="font-bold">${isNaN(percentage) ? "-" : percentage + "%"} </span>
                        </div>
                    </div>
                    `
            }
        };
        return options;
    }

    function addComparisonBarChart(data) {
        $('#main-charts').hide();
        const options = updateOptions(data);
        if (options == null) {
            addEmptyWarning('#budget-data-graph');
            return;
        }
        var divToAdd = '<div id="bar-chart"></div>';
        $('#budget-data-graph').append(divToAdd);
        if (document.getElementById("bar-chart") && typeof ApexCharts !== 'undefined') {
            const chart = new ApexCharts(document.getElementById("bar-chart"), options);
            chart.render();
        }
    }

    function initBarChart() {
        var municipalityID = $('#graph-data #MunicipalityID').val();
        var yearID = $('#graph-data #YearID').val();

        makeAjaxGraphDataCall(null, municipalityID, yearID, null, null, "BarChart", addComparisonBarChart)
    }


    //DONUT CHARTS
    function drawDonutChart(item) {
        var newDiv = `
            <div class="w-full shadow-md bg-white rounded-lg md:px-4 py-4 md:p-6 max-w-full mb-2">
                <div class="py-6" id="donut-${item.budgetPositionID}"></div>
            </div>
        `;
        $("#radial-charts").append(newDiv);

        const chart = new ApexCharts(document.getElementById(`donut-${item.budgetPositionID}`), app.graphSettings.getDonutChartOptions(item));
        chart.render();
        donutCharts.push(chart);
    }

    function addDonutCharts(data) {
        if (data.length == 0) {
            addEmptyWarning('#radial-charts');
        }

        data.forEach((item) => drawDonutChart(item));

        $('html, body').animate({
            scrollTop: $("#radial-charts").offset().top
        }, "slow");
    }

    var removeDonutCharts = function () {
        $('#radial-charts').empty();
        $('#donut-container').find('h5').remove();
        donutCharts.forEach((chart) => { chart.destroy(); });
        donutCharts = [];
    }

    var updateDonutCharts = function (id, label, desc) {
        removeDonutCharts();
        var descDiv = `<h5 class="text-xl text-center font-normal leading-none text-gray-500 pr-1 mb-2">${desc}</h5>`;
        $('#donut-container').prepend(descDiv);
        var titleDiv = `<h5 class="text-4xl text-center font-bold leading-none text-gray-900 pr-1 mb-2">${label}</h5>`;
        $('#donut-container').prepend(titleDiv);
        var municipalityID = $('#graph-data #MunicipalityID').val();
        var yearID = $('#graph-data #YearID').val();
        var accountTypeID = $('#graph-data #accountTypeID').val(); // 1 - rashodi, 2  - prihodi
        var amountTypeID = $('#graph-data #amountTypeID').val(); // 1 - planirana, 2 - finalna
        makeAjaxGraphDataCall(id, municipalityID, yearID, accountTypeID, amountTypeID, 'DonutCharts', addDonutCharts);
    }


    //FUNKCIJE ZA NAVIGACIJU

    var applyFilters = function (path) {
        let arr = $('#filter-form').serializeArray();

        let len = arr.length;
        var params = {};
        for (i = 0; i < len; i++) {
            params[arr[i].name] = arr[i].value;
        }

        let mun = params['MunicipalityName']
        if (path != null && path != undefined && path.length > 0) {
            mun += ('/' + path);
        }

        window.location.href = '/' + mun + '?Year=' + params['Year'] + '&AccountTypeID=' + params['AccountTypeID'];
    }

    var changeTab = function (tab) {
        $(`#Tab option:eq(${tab})`).prop('selected', true)
    }

    function toggleGraphButtons(id) {
        $('#accountTypeID').val(id);
        $('#graph-selector>button').removeClass('text-white bg-blue-us border-blue-us');
        $('#graph-selector>button').addClass('text-gray-900 bg-white  border-gray-200 hover:bg-gray-100 hover:text-blue-web focus:text-blue-web');
        $(`#graph-selector>button:nth-child(${id})`).removeClass('text-gray-900 bg-white  border-gray-200 hover:bg-gray-100 hover:text-blue-web focus:text-blue-web').addClass("text-white bg-blue-us border-blue-us");
        $(`#graph-title`).text(graphTitles[id - 1]);
    }

    function toggleBudgetType(id) {
        $('#amountTypeID').val(id);
        $('#budget-type-buttons>button').removeClass('text-white bg-blue-us border-blue-us');
        $('#budget-type-buttons>button').addClass('text-gray-900 bg-white  border-gray-200 hover:bg-gray-100 hover:text-blue-web focus:text-blue-web');
        $(`#budget-type-buttons>button:nth-child(${id})`).removeClass('text-gray-900 bg-white  border-gray-200 hover:bg-gray-100 hover:text-blue-web focus:text-blue-web').addClass("text-white bg-blue-us border-blue-us");
    }

    var changeGraph = function (id) {
        if ($('#accountTypeID').val() == id)
            return;

        toggleGraphButtons(id);
        if (id < 3) {
            $('#budget-type-buttons').show();
            $('#main-charts').show();
            $('#bar-chart').hide();
            removeDonutCharts();
            updateGraphs();
            return;
        }

        if ($('#bar-chart').length) {
            $('#main-charts').hide();
            $('#budget-type-buttons').hide();
            $('#bar-chart').show();
        } else {
            $('#budget-type-buttons').hide();
            initBarChart();
        }
    }

    var changeBudgetType = function (id) {
        if ($('#amountTypeID').val() == id)
            return;
        toggleBudgetType(id);
        removeDonutCharts();
        updateGraphs();
    }

    var changeAccountType = function (type, path) {
        $(`#AccountTypeID option:eq(${type})`).prop('selected', true);
        applyFilters(path);
    }

    var initMunicipalityDropdownSearch = function () {
        $('#input-group-search').on('input', function () {
            var query = $(this).val().toLowerCase();
            $('#dropdownSearch ul li').each(function () {
                var label = $(this).find('label').text().toLowerCase();
                if (label.indexOf(query) === -1) {
                    $(this).hide();
                } else {
                    $(this).show();
                }
            });
        });
    }

    //Pomocne funkcije
    var makeAjaxGraphDataCall = function (accountCategoryID, municipalityID, yearID, accountTypeID, graphType, method, callback) {
        $.ajax({
            url: `/BudgetDataPublic/${method}`,
            type: 'GET',
            data: { accountCategoryID: accountCategoryID, municipalityID: municipalityID, yearID: yearID, accountTypeID: accountTypeID, amountTypeID: graphType },
            dataType: 'json',
            success: function (data) {
                data = data.filter(function (item) {
                    return item.amount !== 0;
                });
                callback(data);
            },
            error: function (error) {
                console.error(error);
            }
        });
    }

    function addEmptyWarning(selector) {
        if ($('#no-data-warning').length) {
            return;
        }
        var newDiv = `
            <div class="w-full mt-6 mb-12 bg-white rounded-lg shadow p-4 md:p-6" id="no-data-warning">
              <div class="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50" role="alert">
                <span class="font-medium"> Podaci o budžetu trenutno nisu dostupni za ovu općinu!</span>
              </div>
            </div>
        `;

        $(`${selector}`).append(newDiv);
    }

    var initPickers = function () {
        app.selectPicker.addPickers({
            search: true,
            multiple: false,
            clear: false,
            selectAll: false,
        });
    }

    var setActiveTab = function (tabId) {
        $(`.tab-link:eq(${tabId - 1})`).removeClass("text-gray-900 border-b-1 border-gray-100").addClass("text-blue-us border-b-2 border-blue-us");
    }

    var downloadJson = function (municipalityID, yearID) {
        var requestData = {
            municipalityID: municipalityID,
            yearID: yearID
        };

        $.ajax({
            url: '/BudgetDataPublic/ExportToJson',
            type: 'GET',
            data: requestData,
            dataType: 'json',
            success: function (data) {
                var json = JSON.stringify(data);
                var blob = new Blob([json]);
                var link = document.createElement('a');
                link.href = window.URL.createObjectURL(blob);
                link.download = "data.json";
                link.click();
            },
            error: function (xhr, status, error) {
                console.error(xhr.responseText);
            }
        });

    }

    return {
        initGraphs: initGraphs,
        applyFilters: applyFilters,
        changeTab: changeTab,
        changeAccountType: changeAccountType,
        changeGraph: changeGraph,
        changeBudgetType: changeBudgetType,
        updateDonutCharts: updateDonutCharts,
        setActiveTab: setActiveTab,
        initPickers: initPickers,
        initMunicipalityDropdownSearch: initMunicipalityDropdownSearch,
        downloadJson: downloadJson,
    };
}();