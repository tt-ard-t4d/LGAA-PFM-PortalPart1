﻿using Authorization;
using DocumentFormat.OpenXml.Bibliography;
using Infrastructure.Helpers;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using PFMPortal.Domain.Entities.App;
using PFMPortal.DTO.BudgetData;
using PFMPortal.DTO.Utils;
using PFMPortal.Infrastructure.Core.PFM;
using PFMPortal.Infrastructure.Core.Utils;
using PFMPortal.Infrastructure.Extensions;
using PFMPortal.Infrastructure.Helpers;
using PFMPortal.Infrastructure.Models;
using PFMPortal.Infrastructure.Resources;
using static PFMPortal.Infrastructure.Helpers.PFMEnum;

namespace PFMPortal.Controllers.PFM
{
    [AuthorizeUserGroups(ActionManagementEnum.UserGroups.LGUAdministrator)]
    public class BudgetDataController : Controller
    {
        private readonly BudgetDataService _service;
        private readonly AccountCategoryDataService _accountCategoryDataService;
        private readonly PFMDropDownService _dropdownService;
        private readonly MunicipalityService _municipalityService;
        private readonly FileManagementService _fileManagementService;

        public BudgetDataController(BudgetDataService service, PFMDropDownService dropdownService, MunicipalityService municipalityService, AccountCategoryDataService accountCategoryDataService, FileManagementService fileManagementService)
        {
            _service = service;
            _dropdownService = dropdownService;
            _municipalityService = municipalityService;
            _accountCategoryDataService = accountCategoryDataService;
            _fileManagementService = fileManagementService;
        }

        public IActionResult Index(SearchBudgetDataDTO args)
        {
            if (!string.IsNullOrEmpty(args.MunicipalityName))
            {
                var res = _service.GetMunicipalityBySlug(args.MunicipalityName);

                if (res.MunicipalityID == 0)
                {
                    TempData["error-message"] = MessageRes.MunicipalityNotFound;
                    return RedirectToAction("Index", "Home");
                }

                args.MunicipalityID = res.MunicipalityID;
            }

            CreateFilterDDLs(ref args);

            var grid = _service.GetBudgetDataReadGrid(args);

            if (args.MunicipalityID > 0 && !grid.Data.Any())
            {
                TempData["error-message"] = MessageRes.BudgetDataMissing;
                return RedirectToAction("Index", "Home");
            }

            return View(grid);
        }


        #region <!--- Budget data --->
        public IActionResult Edit(SearchBudgetDataDTO args)
        {
            CreateFilterDDLs(ref args);
            if (args.Years.IsNullOrEmpty() || args.Municipalities.IsNullOrEmpty())
            {
                TempData["error-message"] = MessageRes.NoData;
                return RedirectToAction("Index");
            }

            var loggedUserId = User.Identity.GetLoggedUserId();
            var userMunicipalities = _municipalityService.GetMunicipalitiesForUser(loggedUserId);

            if (userMunicipalities.Select(r => r.MunicipalityID).Any(r => r == args.MunicipalityID))
            {
                var grid = _service.GetBudgetDataEditGrid(args);
                grid.Description = _service.GetBudgetTitle(args.Year, args.MunicipalityID).Title;
                return View("Edit", grid);

            }
            TempData["error-message"] = MessageRes.Error;
            return RedirectToAction("Index", "Home");
        }

        [HttpPost]
        public IActionResult SavePlannedValues([DataSourceRequest] DataSourceRequest request, [Bind(Prefix = "models")] IEnumerable<BudgetDataGridDTO> items)
        {
            if (items != null && ModelState.IsValid)
            {
                Guid loggedUserId = User.Identity.GetLoggedUserId();
                var res = _service.Save(items, loggedUserId, BudgetDataValueType.Planned);

                if (res.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                }
                else
                {
                    TempData["success-message"] = MessageRes.Success;
                }
            }

            return Json(items.ToDataSourceResult(request, ModelState));
        }

        [HttpPost]
        public IActionResult SaveFinalValues([DataSourceRequest] DataSourceRequest request, [Bind(Prefix = "models")] IEnumerable<BudgetDataGridDTO> items)
        {
            if (items != null && ModelState.IsValid)
            {
                Guid loggedUserId = User.Identity.GetLoggedUserId();
                var res = _service.Save(items, loggedUserId, BudgetDataValueType.Final);

                if (res.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                }
                else
                {
                    TempData["success-message"] = MessageRes.Success;
                }
            }

            return Json(items.ToDataSourceResult(request, ModelState));
        }

        private void CreateFilterDDLs(ref SearchBudgetDataDTO args)
        {
            Guid userId = User.Identity.GetLoggedUserId();

            args.Municipalities = _dropdownService.GetMunicipalitiesForUser(userId);
            args.Years = _dropdownService.GetBudgetDataYears();
            args.ValueTypes = _dropdownService.GetValueTypes();
            args.AccountTypes = _dropdownService.GetAccountTypes();

            if (args.Year == 0)
            {
                args.Year = _service.GetLatestYearForMunicipality(args.MunicipalityID);
            }
        }

        #endregion

        #region Budget title

        public IActionResult EditBudgetTitle(int yearId, int municipalityId)
        {
            var model = _service.GetBudgetTitle(yearId, municipalityId);
            return View(model);
        }

        public IActionResult SaveBudgetTitle(BudgetTitleDTO model)
        {
            if (ModelState.IsValid)
            {
                var save = _service.SaveBudgetTitle(model, User.Identity.GetLoggedUserId());

                if (save.IsError)
                {
                    TempData["error-message"] = MessageRes.Error;
                    return RedirectToAction("Edit", "BudgetData",
                        new { Year = model.Year, MunicipalityID = model.MunicipalityId });
                }

                TempData["success-message"] = MessageRes.Success;
                return RedirectToAction("Edit", "BudgetData",
                    new { Year = model.Year, MunicipalityID = model.MunicipalityId });
            }
            TempData["error-message"] = MessageRes.Error;
            return RedirectToAction("Edit", "BudgetData",
                new { Year = model.Year, MunicipalityID = model.MunicipalityId });
        }

        #endregion

        #region <!--- Account category data --->

        //public IActionResult EditAccountCategoryData(SearchBudgetDataDTO args)
        //{
        //    var loggedUserId = User.Identity.GetLoggedUserId();

        //    var userMunicipalities = _municipalityService.GetMunicipalitiesForUser(loggedUserId);

        //    if (!userMunicipalities.Select(r => r.MunicipalityID).Any(r => r == args.MunicipalityID))
        //    {
        //        TempData["error-message"] = MessageRes.Error;
        //        return RedirectToAction("Index", "Home");
        //    }

        //    var res = _accountCategoryDataService.GetAccountCategoryDataEditGrid(args);

        //    return View("EditAccountCategoryData", res);
        //}

        #endregion

        #region <!--- Total budget --->

        //public IActionResult EditTotalBudget()
        //{
        //    return NoContent();
        //}

        #endregion

        #region <!--- Documents --->


        public IActionResult EditDocument(SearchBudgetDataDTO args)
        {
            var res = _fileManagementService.GetFileGrid(args);
            return View("EditDocument", res);
        }

        #endregion


    }
}
